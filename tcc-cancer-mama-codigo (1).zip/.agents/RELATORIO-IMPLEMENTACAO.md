# Relatório de implementação — MVP do TCC (Grupo 05)

Branch `feat/mvp-alinhado-documentacao`. Classificação de risco de câncer de
mama (benigno/maligno) sobre o *Wisconsin Diagnostic Breast Cancer Dataset*
(WDBC/UCI) — base **tabular** de 30 medidas numéricas extraídas de punção
aspirativa por agulha fina (FNA), **não** imagens de biópsia.

Este documento descreve o que foi efetivamente construído, com os números reais
obtidos nas verificações, e fecha com a lista item por item de **correções que a
equipe precisa aplicar no `.docx` do TCC**.

> **Documentação funcional: [`docs/COMO-FUNCIONA.md`](../docs/COMO-FUNCIONA.md).**
> Explica o que o sistema faz, por que faz assim e onde cada decisão está no
> código (dados, caminho completo de uma classificação, limiar de segurança,
> reprodutibilidade, perfis, as quatro telas, API por fluxo, rastreabilidade e
> limitações). É o documento para quem pergunta "como isso funciona?"; este
> relatório é o "o que foi construído e como foi verificado", e
> `.agents/ESPECIFICACAO-CONSOLIDADA.md` é o contrato.

---

## 1. Estado por requisito

### Requisitos funcionais

| ID | Requisito | Onde foi implementado | Como foi verificado |
|---|---|---|---|
| **RF01** | Formulário aceita e valida as 30 características | `GET /api/v1/features/schema` (`api/routes.py:schema` + `ml/data.py:feature_schema`); validação de servidor em `services/validation.py:validar_caracteristicas`; validação de cliente (faixa ±20%) e formulário agrupado em 10 fieldsets × 3 variações em `frontend/src/pages/ClassificarPage.jsx` | `tests/test_feature_schema.py` (7 testes: 30 campos, aliases `min`/`max`, margem 20%, `label`/`unit`/`exemplo`) e `tests/test_validation.py` (faltando / não numérico / fora de faixa). Rota real respondeu 200 com 30 campos |
| **RF02** | Classifica entre benigno e maligno | `ml/predict.py:predict` (classe por `P(maligno) ≥ limiar`, nunca `.predict()`); `POST /api/v1/predictions` | `tests/test_predict.py` (decisão por limiar, nunca `.predict()`); requisição real devolveu `label=maligno`, `probability≈1.0` para caso maligno do WDBC |
| **RF03** | Exibe grau de confiança | `confidence` (numérico) e `confidence_band` (`alta`/`media`/`baixa`) em `ml/predict.py:faixa_confianca`; exibição com cor + texto + ícone em `frontend/src/components/ui.jsx:ResultBadge` | `tests/test_predict.py` (3 faixas; `media` sem acento em `test_faixa_confianca_media_sem_acento`) |
| **RF04** | Treina e compara Regressão Logística e SVM na mesma base | `ml/train.py:train_and_evaluate` (mesma partição 80/20 estratificada); treino sob demanda em `POST /api/v1/training-runs` (`api/routes.py` + `services/modelos.py`) | `python -m ml.train` treinou os dois modelos; `tests/test_training.py` (POST cria run + trained_models, GridSearchCV executa sem erro) |
| **RF05** | Exibe acurácia, sensibilidade, especificidade e AUC | `ml/train.py:compute_metrics`; `GET /api/v1/models/comparison` (nos dois pontos de operação) e `GET /api/v1/models/export?format=csv` | Métricas em `ml/artifacts/metrics.json`; rota real `comparison` respondeu 200 com os dois modelos |
| **RF06** | Exibe as características mais relevantes do melhor modelo | Importância por permutação em `ml/train.py` (log-loss, 30 repetições); `GET /api/v1/models/features`; gráfico de barras em `frontend/src/pages/ModelosPage.jsx` | `ml/artifacts/feature_importance.json`; rota real respondeu top-N com `metodo="permutação..."` |
| **RF07** | Mantém histórico, sem exigir identificação do paciente | `db/models.py:Evaluation` (imutável); modo anônimo descarta dados de paciente (`services/validation.py:validar_paciente`); `GET /api/v1/predictions` paginado e filtrável; `frontend/src/pages/HistoricoPage.jsx` com filtros na URL | `tests/test_predictions.py` (modo anônimo, paginação, filtro por `label`, imutabilidade por update/delete) |

### Requisitos não funcionais

| ID | Requisito | Onde foi implementado | Como foi verificado |
|---|---|---|---|
| **RNF01** | Aviso de apoio permanente em todas as telas | `disclaimer-bar` com `role="note"` no `app-shell` de `frontend/src/App.jsx`, acima do `<Routes>` | Inspeção visual: aviso idêntico e visível em `/login`, `/classificar`, `/historico` e `/laboratorio` |
| **RNF02** | Classificação em < 2 s; `elapsed_ms` gravado | Medição com `time.perf_counter()` em `api/routes.py:criar_predicao`; estouro de 2 s vira 504 `TIMEOUT` sem gravar; `elapsed_ms` inteiro em `db/models.py:Evaluation` | `tests/test_predictions.py` (`elapsed_ms < 2000`; modelo lento → 504 e nada gravado); medição direta: mediana ≈ 0,14 ms, máximo 13,4 ms (modelo em memória) |
| **RNF03** | Partições, hiperparâmetros, semente e versões versionados | `ml/train.py` grava `split.json`, `train_config.json`, SHA-256 do dataset e dos artefatos, versões das libs e commit do git; exposto em `GET /models/comparison` (`reproducibility`). `ml/artifacts/` é a referência versionada, regerada só por `python -m ml.train`; o treino sob demanda é isolado em `ml/artifacts/runs/{training_run_id}/` (D8, seção 2.5) | Artefatos presentes em `ml/artifacts/`; semente 42 e partição 455/114 confirmadas; teste de hash dos 8 artefatos antes/depois de um `POST /training-runs` com `test_size=0.3` (inalterados) e `git status --porcelain ml/artifacts` vazio após a suíte |
| **RNF04** | Taxa de falsos negativos reportada; limiar de segurança 0,97 | `taxa_falsos_negativos` em `compute_metrics`, propagada a `trained_models.false_negative_rate` e à API; limiar de segurança via out-of-fold em `escolher_limiar_seguranca`; promoção condicionada em `PUT /models/{id}/threshold` | `tests/test_limiar.py` (3 testes); `tests/test_training.py` (promoção abaixo/acima de 0,97); FN reportado nos dois pontos de operação em `metrics.json` |
| **RNF05** | **Alterado por D2** — modo identificado SEM criptografia | `patient_name` / `patient_record` gravados em texto puro em `db/models.py:Evaluation`; `services/avaliacoes.py` não cifra nada; não há `services/crypto.py` nem dependência `cryptography`. Mitigação mínima acrescentada depois da revisão: as rotas de dados exigem sessão válida (D10, seção 2.5) — autenticação, não autorização | `tests/test_predictions.py` confirma que o modo identificado grava texto puro; varredura confirmou ausência de criptografia/JWT/RBAC/auditoria no código; `tests/test_sessao_obrigatoria.py` confirma 401 sem sessão em todas as rotas de dados |

---

## 2. Resultados das verificações

### 2.1 Testes automatizados

```
python -m unittest discover -s tests -t .
Ran 107 tests in ~94 s
OK  (zero falhas, zero erros)
```

107 testes, todos passando (eram 86 antes das correções da seção 2.6, que
acrescentaram 9 testes da invariante das métricas, 8 do endpoint de comparação e
4 da unicidade por execução; e eram 76 antes da seção 2.5).
Cobertura por arquivo: `test_predict.py`,
`test_limiar.py`, `test_validation.py`, `test_feature_schema.py`,
`test_auth.py`, `test_predictions.py`, `test_training.py`,
`test_sessao_obrigatoria.py`, `test_metricas_coerentes.py`,
`test_modelos_comparacao.py`. Os avisos no stderr
(`SECRET_KEY não configurada` em ambiente de teste, `FutureWarning` do
scikit-learn 1.9 sobre `SVC(probability=True)`, `ResourceWarning` de SQLite em
memória) não são falhas.

Build do frontend: `npm run build` conclui limpo (44 módulos, ~6 s). A única
observação não bloqueante é o `npm audit` (4 vulnerabilidades em dependências
transitivas de **desenvolvimento** — `esbuild`/`vite` dev-server e
`react-router`; não afetam o build de produção nem a SPA servida pelo Flask).

### 2.2 Métricas dos modelos (569 casos, split 80/20 estratificado, semente 42: 455 treino / 114 teste, 42 malignos no teste)

> Todos os números desta seção são da **referência versionada 80/20** em
> `ml/artifacts/` (D8), no conjunto de teste de 114 casos (42 malignos). São
> esses os números citados no artigo. Execuções disparadas pela tela do
> Laboratório usam outras partições e **não** são comparáveis com esta tabela —
> ver a seção 2.6, defeito C.

| Modelo | Ponto de operação | Limiar | Acurácia | Sensibilidade | Especificidade | AUC | Taxa de FN |
|---|---|---|---|---|---|---|---|
| **Regressão logística** | padrão | 0,50 | 96,49% | 92,86% | 98,61% | 0,9960 | 7,14% |
| **Regressão logística** | **segurança** | **0,31** | **98,25%** | **97,62%** | 98,61% | 0,9960 | **2,38%** |
| SVM (RBF) | padrão | 0,50 | 97,37% | 92,86% | 100,00% | 0,9927 | 7,14% |
| SVM (RBF) | segurança | 0,38 | 97,37% | 95,24% | 98,61% | 0,9927 | 4,76% |

- **Limiar de segurança calculado**: Regressão logística = **0,31**; SVM = **0,38**.
  Ambos escolhidos a partir das predições out-of-fold do treino (o conjunto de
  teste nunca entra na escolha).
- **Modelo em produção: Regressão logística.** Critério: maior sensibilidade no
  ponto de operação (desempate por AUC e depois especificidade). No ponto de
  segurança a RL atinge **97,62% de sensibilidade** (≥ meta de 97%, RNF04
  cumprida), enquanto o SVM fica em 95,24% — abaixo da meta no conjunto de
  teste. Ou seja: embora o SVM mostre melhor especificidade no limiar padrão
  (100%), ele **não** sustenta a sensibilidade mínima de segurança no teste, e
  por isso não é promovido. A RL reduz a taxa de falsos negativos de 7,14% (0,50)
  para **2,38%** (0,31), que é a métrica prioritária do projeto.
- **Características mais relevantes do melhor modelo** (RF06, permutação sobre a
  RL): `worst_texture`, `worst_symmetry`, `worst_concavity`,
  `worst_concave_points`, `mean_concave_points`, `mean_concavity`.

### 2.3 Tempo de classificação (RNF02)

Limite do requisito: **< 2 s**. Com o modelo carregado em memória, a inferência
mediu **mediana ≈ 0,14 ms** e **máximo 13,4 ms** (primeira chamada, aquecimento),
três ordens de grandeza abaixo do limite. Em requisições HTTP reais o
`elapsed_ms` gravado ficou em torno de 1–18 ms. O caminho de estouro foi
exercitado por teste (modelo artificialmente lento → 504 `TIMEOUT`, nada gravado).

### 2.4 Caminhos de erro verificados

- **503 `MODEL_UNAVAILABLE`** — testado contra o servidor real com os artefatos
  removidos: `POST /predictions`, `GET /models/comparison` e
  `GET /models/export` responderam 503.
- **504 `TIMEOUT`** — teste de integração HTTP contra o handler de produção com
  inferência simulada em 2,1 s; status 504, código `TIMEOUT`, contagem de
  avaliações inalterada.
- **400 `SENSITIVITY_BELOW_TARGET`** — `PUT /models/{id}/threshold` com limiar
  que derruba a sensibilidade abaixo de 0,97 devolveu 400 com `obtained` e
  `required`, sem alterar o banco.
- **400 `VALIDATION_ERROR`**, **401 `UNAUTHENTICATED`**, **404 `NOT_FOUND`** —
  todos confirmados por teste e por requisição real.

### 2.5 Defeitos encontrados na revisão e corrigidos

Dois defeitos foram confirmados por evidência durante a revisão do MVP e
corrigidos nesta etapa. **As métricas das seções 1 e 2 não mudaram**: os
artefatos de referência citados no artigo continuam sendo os do commit
`096bc547` (split 80/20, RL limiar 0,31 / sensibilidade 0,9762 / FN 0,0238;
SVM limiar 0,38 / sensibilidade 0,9524 / acurácia 0,9737).

#### Defeito 1 — o treino sob demanda destruía os artefatos de reprodutibilidade (RNF03)

**Sintoma.** `POST /api/v1/training-runs` gravava em `ml/artifacts/`, o mesmo
diretório dos artefatos versionados.

**Evidência.** Um treino disparado pela API com `test_size=0.3` sobrescreveu a
referência do split 80/20:

| Modelo | Commitado (`test_size=0.2`) | Após o treino pela API (`0.3`) |
|---|---|---|
| `regressao_logistica` | limiar 0,31 · sens 0,9762 · FN 0,0238 | limiar 0,32 · sens 0,9688 · FN 0,0312 |
| `svm` | limiar 0,38 · acurácia 0,9737 | limiar 0,21 · acurácia 0,9591 |

**Causa.** `train_and_evaluate` tem `output_dir=ARTIFACTS_DIR` como default e a
rota não passava `output_dir`; `gerar_figuras()` também regerava
`ml/artifacts/report/`. O efeito era silencioso: bastava alguém disparar um
treino pela tela do Laboratório durante a defesa para os números do artigo
deixarem de corresponder ao repositório.

**Correção (D8).** Diretório por execução, `ml/artifacts/runs/{training_run_id}/`:

- `ml/train.py` ganhou `RUNS_DIR` e `diretorio_execucao(training_run_id)`, e
  `train_and_evaluate` devolve `output_dir`; o docstring do módulo e o
  `__main__` declaram que `ml/artifacts/` é a referência versionada regerada
  **somente** por `python -m ml.train`.
- `api/routes.py:criar_training_run` passa `output_dir=diretorio_execucao(run.id)`
  e chama `gerar_figuras(artifacts_dir=diretorio)` — as figuras/CSV do run vão
  para `runs/{id}/report/`. A resposta 201 traz `artifacts_dir`.
- `services/modelos.py` grava `artifact_path` apontando para o diretório da
  execução e expõe `diretorio_artefatos_do_registro`, usado pela promoção para
  ler o `{modelo}_oof.json` da própria execução.
  > **Nota de 22/10/2026 — encerrada.** Esta correção ficou incompleta: a
  > desduplicação por `artifact_sha256` fazia a execução nova reaproveitar um
  > registro antigo, que mantinha o `artifact_path` da referência. Resolvido em
  > definitivo pela seção 2.6, defeito B (D12 — uma linha por execução).
- `ml/artifacts/runs/` entrou no `.gitignore`; o `tearDown` dos testes remove as
  pastas que criou.
- A inferência (`POST /predictions`) continua usando sempre a referência (D9):
  promover um modelo de execução registra o ponto de operação no banco e no
  Laboratório, mas não troca o artefato que classifica. Para tornar uma execução
  a nova referência, roda-se `python -m ml.train`.

**Como foi verificado.** Teste que compara o SHA-256 dos 8 artefatos de
referência (`metrics.json`, `train_config.json`, `split.json`, `scaler.joblib`,
os dois `.joblib` e os dois `_oof.json`) antes e depois de um
`POST /training-runs` com `test_size=0.3` — iguais; teste que confirma
`test_size=0.3` em `runs/{id}/train_config.json` e `0.2` na referência; teste de
que o `report/metricas.csv` da referência não muda; e `git status --porcelain
ml/artifacts` vazio depois de rodar a suíte inteira.

#### Defeito 2 — as rotas de dados não exigiam autenticação

**Sintoma e evidência.** Requisições reais, sem nenhum cookie de sessão:

```
GET /api/v1/predictions   -> HTTP 200, devolve os dados do histórico
GET /api/v1/auth/me       -> HTTP 401 UNAUTHENTICATED
```

A autenticação funcionava; simplesmente não era exigida nas rotas de dados. O
README afirmava que "qualquer usuário autenticado consegue ler o histórico
identificado inteiro", o que subestimava o problema: nem autenticação era
necessária, e o modo identificado grava nome e prontuário de paciente em texto
(D2).

**Causa.** Nenhuma rota de dados verificava a sessão. Isso **não** era a decisão
D3: D3 removeu a segregação por perfil e a trava de autorização — médico e
pesquisador acessam as mesmas rotas — mas não removeu a necessidade de estar
autenticado, e o fluxo da Figura 3 (Seleção de Perfil) mostra o usuário entrando
antes de qualquer operação.

**Correção (D10).** Decorador `exigir_sessao` em `api/routes.py`, aplicado rota a
rota nas 11 rotas de dados (`/features/schema`, `/predictions` POST e GET,
`/predictions/{id}`, `/models`, `/models/comparison`, `/models/features`,
`/models/export`, `/training-runs` POST, `/training-runs/{id}`,
`/models/{id}/threshold`): sem sessão, **401 `UNAUTHENTICATED`**, no mesmo
envelope de erro que `/auth/me` já devolvia. `/auth/*` e `/health` seguem
públicas. **Continua sem qualquer verificação de perfil** (D3 preservada): um
médico autenticado chama as rotas do pesquisador e vice-versa. É autenticação,
não autorização.

**Como foi verificado.** `tests/test_sessao_obrigatoria.py`: um teste varre
`app.url_map` e exige 401 `UNAUTHENTICATED` em **toda** regra `/api/v1` fora de
`/api/v1/auth` (rede de segurança contra uma rota nova nascer sem o decorador);
um teste confirma que `/auth/*` e `/health` seguem públicas; um teste confirma
200 nas rotas de dados **com** sessão; e dois testes confirmam que médico acessa
rota de pesquisador e vice-versa. Os testes de `predictions` e `training`
passaram a usar `ApiAutenticadoTestCase`, cobrindo o lado autenticado de cada
grupo de rotas.

**Frontend.** Nenhuma mudança foi necessária: `frontend/src/api.js` envia
`credentials: "include"` em todas as chamadas e as telas de dados são montadas
dentro de `RotaProtegida` (`App.jsx`), que não renderiza nada enquanto
`GET /auth/me` está em voo e redireciona para `/login` sem usuário — logo o
`useEffect` com `getFeatureSchema()` da tela Classificar só roda depois de a
sessão estar estabelecida. O link de exportação CSV é um `<a href download>` de
mesma origem, então o cookie viaja automaticamente.

**Sessão expirada (nota de comportamento).** Um 401 em rota de dados aparece
como mensagem de erro da própria tela; o recarregamento leva ao `/login`. Não foi
adicionado interceptador global de 401, para manter a correção mínima.

### 2.6 Defeitos de métricas encontrados na segunda revisão e corrigidos

Três defeitos de métricas foram confirmados por evidência no banco de
demonstração (`.agents/tasks/correcoes-metricas-documentacao/
diagnostico-antes.txt`) e corrigidos nesta etapa. **As métricas das seções 1, 2.1
e 2.2 não mudaram**: os artefatos de referência citados no artigo continuam
sendo os do commit `096bc547` (split 80/20, RL limiar 0,31 / sensibilidade 0,9762
/ FN 0,0238; SVM limiar 0,38 / sensibilidade 0,9524 / acurácia 0,9737). O que
mudou é a semântica das colunas do banco, o corpo de duas rotas e a tela do
Laboratório.

#### Defeito A — `PUT /models/{id}/threshold` deixava a linha internamente inconsistente

**Sintoma.** Ao mudar o limiar, o código gravava na coluna `sensitivity` o valor
recalculado a partir das predições **out-of-fold do treino**, mas não atualizava
`specificity`, `accuracy`, `false_negative_rate` nem `confusion_matrix`, que
continuavam com os valores do **conjunto de teste no limiar antigo**. A linha
passava a misturar dois conjuntos de avaliação diferentes.

**Evidência** (`instance/tcc_cancer_mama.db`, antes da correção):

| id | limiar | `sensitivity` gravada | `confusion_matrix` | sensibilidade real da matriz |
|---|---|---|---|---|
| 2 | 0,32 | 0,9730 | `{vn:71, fp:1, fn:1, vp:41}` | 41/42 = **0,9762** |
| 6 | 0,01 | 0,9941 | `{vn:106, fp:1, fn:2, vp:62}` | 62/64 = **0,9688** |

A linha id=6 é a mais clara: `specificity` **0,9907** gravada num limiar de
**0,01**. Num limiar tão baixo quase todo caso é previsto maligno, então a
especificidade tem de cair muito — aquele 0,9907 era simplesmente o valor do
limiar antigo que ninguém reescreveu.

**Causa.** Um único campo (`trained_models.sensitivity`) usado para dois
significados: o portão de promoção (out-of-fold do treino) e a métrica reportada
(conjunto de teste). `promover_modelo` recebia um só número e gravava-o ali.

**Correção (D11).** As duas grandezas ficaram em campos distintos:

- **Portão do RNF04** — continua sendo a sensibilidade das predições out-of-fold
  do treino no limiar pedido, porque escolher ou validar limiar olhando o
  conjunto de teste vazaria informação. Passou a ter coluna própria:
  `trained_models.train_oof_sensitivity` (Float, nullable). Nome escolhido por
  carregar as duas informações que evitam a confusão — é do **treino** e é
  **out-of-fold**.
- **Métricas reportadas** — `accuracy`, `sensitivity`, `specificity`,
  `false_negative_rate` e `confusion_matrix` são agora sempre do **conjunto de
  teste** da execução daquele modelo, recalculadas **em conjunto** no limiar
  vigente por `services.modelos.metricas_teste_no_limiar`, que reusa
  `ml.train.compute_metrics` — uma única implementação da matriz de confusão e
  das razões em todo o projeto, o que faz a invariante valer por construção.
  `auc` é reescrita com o mesmo valor: depende só das probabilidades.
- O insumo do recálculo é o artefato novo `{modelo}_test_proba.json`
  (`{"y_true","proba"}`), gravado por execução ao lado do já existente
  `{modelo}_oof.json`, com regeneração determinística quando falta (mesmo
  contrato do OOF). Se não houver como obtê-lo, a rota devolve **503
  `MODEL_UNAVAILABLE` sem gravar nada** — uma linha meio atualizada é exatamente
  o defeito.
- O corpo da resposta passou a ser
  `{model, threshold, train_oof_sensitivity, test_metrics{...}}`. A chave
  ambígua `sensitivity` de nível superior saiu: era o portão disfarçado de
  métrica.

**Invariante garantida.** Para qualquer linha de `trained_models`:

```
sensitivity         == vp / (vp + fn)   da própria confusion_matrix
false_negative_rate == fn / (vp + fn)
specificity         == vn / (vn + fp)
accuracy            == (vn + vp) / (vn + fp + fn + vp)
```

**Como foi verificado.** `tests/test_metricas_coerentes.py` varre **todas** as
linhas da tabela após sincronizar a referência, após `POST /training-runs` com
`test_size` 0,2 e 0,3 e após `PUT /threshold` em 0,01, 0,20 e 0,45. Há um teste
de regressão do caso id=6: com limiar 0,01 a especificidade gravada tem de cair
e `fp` tem de aumentar. Em runtime, contra o servidor real:

```
PUT /models/1/threshold {"threshold": 0.01} -> HTTP 200
  train_oof_sensitivity = 0.9941   (portão, treino out-of-fold)
  test_metrics          = sens 1.0000 · esp 0.6806 · acc 0.7982 · FN 0.0000
                          matriz {vn:49, fp:23, fn:0, vp:42}
  auc inalterada: 0.996031746031746
  antes: limiar 0.31 · sens 0.9762 · esp 0.9861 · matriz {vn:71, fp:1, fn:1, vp:41}
```

A especificidade caiu de 0,9861 para 0,6806 e `fp` subiu de 1 para 23, como tem
de ser num limiar de 0,01 — e o portão 0,9941 ficou no seu próprio campo.

#### Defeito B — `artifact_path` apontava para a referência em vez do diretório da execução

**Sintoma.** A desduplicação por `artifact_sha256` reaproveitava um registro
existente quando os bytes do modelo coincidiam, e o registro reaproveitado
mantinha o `artifact_path` antigo, apontando para `ml/artifacts/`, mesmo quando a
execução nova gravou em `ml/artifacts/runs/{id}/`.

**Evidência.** Os modelos id=4, 5, 6 e 7 vieram das execuções 6 e 9
(`test_size=0.3`), mas tinham `artifact_path=ml/artifacts/regressao_logistica.joblib`
e `ml/artifacts/svm.joblib` — que são a referência 80/20.

**Causa.** `artifact_sha256 UNIQUE` é a premissa errada: dois treinos
deterministas com a mesma semente e os mesmos dados produzem legitimamente os
mesmos bytes, e foi o desvio para "reaproveitar o registro" (criado justamente
para não violar a unicidade do hash) que herdou o caminho antigo.

**Correção (D12).** Um registro por execução:

- `artifact_sha256` continua existindo como procedência (RNF03), mas **sem**
  `unique`;
- a unicidade passou a ser
  `UniqueConstraint("training_run_id", "name", name="uq_trained_models_run_name")`
  — uma linha por (execução, modelo), que é o que o domínio diz. Restrição de
  tabela declarada em `__table_args__`, criada igual por `create_all()` em
  **PostgreSQL** e em **SQLite** (nenhum tipo nem sintaxe de dialeto envolvido);
- `concluir_training_run_sucesso` sempre cria registro novo, com
  `artifact_path` do artefato daquela execução;
- `sincronizar_modelos` trocou o critério "falta o hash" por "falta a linha
  desta referência" (mesmo `artifact_path` e mesmo hash), continuando
  idempotente.

**Migração.** O projeto não usa Alembic e a política fechada no design é
recriação de schema, sem migração de linhas (banco de desenvolvimento
descartável) — o que também é o certo aqui, porque as linhas antigas estavam
justamente inconsistentes. SQLite: apagar `instance/tcc_cancer_mama.db`.
PostgreSQL: `DROP SCHEMA public CASCADE; CREATE SCHEMA public;`. Em seguida,
subir a aplicação, que executa `create_all()` + `sincronizar_modelos()`.
Documentado no README (D12) e na especificação (seção 4).

**Como foi verificado.** `tests/test_training.py::TestUmaLinhaPorExecucao`: duas
execuções com os mesmos parâmetros (bytes idênticos, confirmado no teste) criam
**duas** linhas, cada uma com `artifact_path == ml/artifacts/runs/{run_id}/...`;
sincronizar duas vezes não duplica linhas nem cria um segundo run sintético;
duas linhas com o mesmo `(training_run_id, name)` levantam `IntegrityError`. Em
runtime, uma execução `test_size=0.3` disparada pela API resultou em
`artifact_path=ml/artifacts/runs/2/regressao_logistica.joblib`, enquanto o SVM
permaneceu em `ml/artifacts/svm.joblib`.

#### Defeito C — o cabeçalho do Laboratório descrevia outro conjunto de teste

**Sintoma.** A tela exibia o texto fixo "Conjunto de teste (114 casos, 42
malignos)", derivado da referência 80/20, enquanto as linhas da tabela e as
matrizes de confusão podiam vir de execuções com outra partição — somando 171
casos e 64 malignos. Os dois apareciam lado a lado, se contradizendo.

**Causa.** O cabeçalho lia `reproducibility.n_teste` e
`reproducibility.distribuicao_teste`, que descrevem a **referência**, enquanto as
linhas vinham do banco. Em `GET /models/comparison`, o laço ainda era dirigido
pelo `metrics.json` da referência e o registro de cada modelo era escolhido por
`{m.name: m for m in TrainedModel.query.all()}` — "o último do dict", arbitrário.

**Correção.** A composição do teste passou a vir dos dados, por execução:

- a rota é dirigida pelo banco (linha mais recente por nome, com ordenação
  explícita) e expõe por item `test_size` (da execução), `test_set_size` e
  `test_set_malignant` derivados da própria matriz de confusão
  (`vn+fp+fn+vp` e `vp+fn`), mais `train_oof_sensitivity` e
  `gate_meets_sensitivity_target`;
- `default_point`, `cross_validation` e `safety_threshold_reached_target` passam
  a vir do `metrics.json` **da execução daquele registro**, e são `null` quando a
  execução foi descartada — nunca da referência, que é outra partição;
- no topo, `test_partitions_mixed` e `test_partitions` dizem quando a tabela
  mistura execuções;
- na tela, o texto fixo saiu; cada linha mostra a sua composição em "Teste
  (casos)" e "Malignos no teste"; as colunas de métrica passaram a se chamar
  "… (teste)"; a coluna "Sensibilidade OOF treino (portão)" ficou ao lado delas,
  com a `caption` dizendo explicitamente para não reportar uma pela outra; e um
  `Alert` de aviso aparece quando as partições estão misturadas.

**Como foi verificado.** `tests/test_modelos_comparacao.py`: com só a referência,
`test_set_size == 114` e `test_set_malignant == 42` conferem com a matriz de cada
linha e `test_partitions_mixed == false`; depois de uma execução `test_size=0.3`
de **um** modelo, `test_partitions_mixed == true`, com 171/64 numa linha e 114/42
na outra, e o `default_point` vem da partição certa (171 casos). Em runtime:

```
GET /models/comparison  (referência + execução 70/30 de um modelo)
  test_partitions_mixed: True
  regressao_logistica  run 2  teste 171 (64 malignos)  test_size 0.3
                       artefato ml/artifacts/runs/2/regressao_logistica.joblib
  svm                  run 1  teste 114 (42 malignos)  test_size 0.2
                       artefato ml/artifacts/svm.joblib
```

#### Estado do banco de demonstração depois das correções

`instance/tcc_cancer_mama.db` foi recriado do zero (ele acumulara 9 execuções de
verificação e modelos de partições misturadas) e repovoado com
`.agents/preparar_demo.py`:

```
python .agents/diagnostico_metricas.py
=== training_runs ===  run 1: test_size=0.2 grid=0 status=success seed=42
=== trained_models ===
  id=1 regressao_logistica  run=1 prod=True
      limiar=0.31  matriz={vn:71, fp:1, fn:1, vp:41}  total=114  malignos=42
      artifact_path=ml/artifacts/regressao_logistica.joblib
      COERENCIA: -> OK
  id=2 svm                  run=1 prod=False
      limiar=0.38  matriz={vn:71, fp:1, fn:2, vp:40}  total=114  malignos=42
      artifact_path=ml/artifacts/svm.joblib
      COERENCIA: -> OK
```

Nenhuma linha `DIVERGENTE`, nenhum `artifact_path` de execução apontando para a
referência, e os dois usuários de demonstração (`medico@demo.local` e
`pesquisador@demo.local`, senha `demo12345`) com três avaliações de exemplo,
incluindo uma no modo identificado. O bloqueio do RNF04 foi exercitado no mesmo
script: promover o SVM com limiar 0,95 devolveu **400
`SENSITIVITY_BELOW_TARGET`** (`obtained` 0,7353 / `required` 0,97), sem alterar
nada.

#### Como verificar cada defeito, do zero

Qualquer um dos três pode ser conferido sem ler código. Em
`c:\Users\isaiaslm\tcc-cancer-mama`:

```bash
# invariante das métricas em toda linha de trained_models (defeito A)
python -m unittest tests.test_metricas_coerentes -v

# uma linha por execução e artifact_path da própria execução (defeito B)
python -m unittest tests.test_training.TestUmaLinhaPorExecucao -v

# composição do teste por execução e aviso de mistura de partições (defeito C)
python -m unittest tests.test_modelos_comparacao -v

# estado real do banco: coerência linha a linha e procedência dos artefatos
python .agents/diagnostico_metricas.py
```

Leitura do diagnóstico:

- **Defeito A** — toda linha termina em `COERENCIA: ... -> OK`. Uma linha
  `DIVERGENTE` significa `sensitivity` gravada que não bate com a própria
  `confusion_matrix`, que era exatamente o sintoma. O portão aparece separado,
  em `train_oof_sensitivity`, e nunca na coluna `sensitivity`.
- **Defeito B** — nenhuma linha nascida de execução (`run` ≥ 2) pode ter
  `artifact_path=ml/artifacts/{nome}.joblib`. Só as duas linhas de **referência**
  (run sintético 1) apontam para `ml/artifacts/`, que é a procedência correta
  delas; execuções apontam para `ml/artifacts/runs/{id}/`.
- **Defeito C** — na tela do Laboratório, o cabeçalho de "Comparação dos
  classificadores" não cita mais nenhum tamanho de conjunto de teste: a
  composição está por linha, nas colunas "Teste (casos)" e "Malignos no teste",
  e o `Alert` de mistura aparece quando as linhas vêm de partições diferentes.

Também é possível exercitar o defeito A em runtime: suba `python app.py`, faça
login e mande `PUT /api/v1/models/1/threshold` com `{"threshold": 0.01}`. A
resposta tem de trazer `train_oof_sensitivity` e `test_metrics` (sem nenhuma
chave `sensitivity` de nível superior), e a especificidade **tem** de cair
(0,9861 → 0,6806, com `fp` de 1 para 23).

### 2.7 Verificação final da entrega

Rodada de fechamento, na branch `feat/mvp-alinhado-documentacao`, com o banco de
demonstração no estado descrito acima:

```
python -m unittest discover -s tests -t . -v
Ran 107 tests in 58.954s
OK                                 (zero falhas, zero erros)

python .agents/diagnostico_metricas.py
=== training_runs ===  run 1: test_size=0.2 grid=0 status=success seed=42
  id=1 regressao_logistica  run=1 prod=True   limiar=0.31  matriz={vn:71, fp:1, fn:1, vp:41}
       acc=0.9825 sens=0.9762 esp=0.9861 auc=0.9960 fn_rate=0.0238
       artifact_path=ml/artifacts/regressao_logistica.joblib   COERENCIA: -> OK
  id=2 svm                  run=1 prod=False  limiar=0.38  matriz={vn:71, fp:1, fn:2, vp:40}
       acc=0.9737 sens=0.9524 esp=0.9861 auc=0.9927 fn_rate=0.0476
       artifact_path=ml/artifacts/svm.joblib                   COERENCIA: -> OK
(nenhuma linha DIVERGENTE; nenhum artifact_path de execução apontando para a referência)

git status --porcelain ml/artifacts
(vazio)
```

As linhas do banco batem com `ml/artifacts/metrics.json` no limiar de segurança
de cada modelo (RL 0,31 → sens 0,9762 / FN 0,0238; SVM 0,38 → sens 0,9524 /
FN 0,0476), o que fecha o ciclo referência → banco → tela.

A verificação ponta a ponta desta etapa (suíte, `ml.train`, `ml.report`, build do
frontend, requisições reais contra `python app.py`, diagnóstico e as quatro telas
capturadas no navegador) está em
`.agents/tasks/correcoes-metricas-documentacao/relatorio-verificacao.md`, com as
saídas integrais em `runtime-api.txt`, `runtime-mistura.txt`,
`diagnostico-depois.txt` e `diagnostico-depois-demo.txt`. As capturas das quatro
telas estão em `.agents/tasks/correcoes-metricas-documentacao/screenshots/`
(`01-selecao-de-perfil`, `02-triagem-e-classificacao`, `03-historico`,
`04-laboratorio-de-modelos`; o sufixo `-misto` é o estado com partições de teste
diferentes, que é o que faz o aviso do defeito C aparecer).

---

## 3. Como rodar e como demonstrar na defesa

### 3.1 Sequência de comandos

```bash
# 1. Dependências
pip install -r requirements.txt

# 2. Treinar os modelos (regenera a REFERÊNCIA versionada em ml/artifacts/)
python -m ml.train

# 3. Gerar figuras 300 DPI e CSV (ml/artifacts/report/)
python -m ml.report

# 4. Subir a API (porta 5000; cria tabelas e sincroniza os modelos)
python app.py

# 5. Em outro terminal: frontend
cd frontend && npm install && npm run build   # servido pelo Flask em http://localhost:5000
#   (ou `npm run dev` para http://localhost:5173 com proxy)

# 6. Testes (opcional, para mostrar a suíte verde)
python -m unittest discover -s tests -t . -v
```

> A suíte de testes **não** suja mais `ml/artifacts/`: o treino sob demanda
> grava em `ml/artifacts/runs/{training_run_id}/` (D8, seção 2.5) e o `tearDown`
> apaga as pastas criadas. `python -m ml.train` é o caminho para regerar a
> referência versionada, não um reparo pós-testes.

### 3.2 Roteiro de demonstração (≈ 5 min)

1. **Cadastro e seleção de perfil.** Cadastre um usuário **médico** e mostre que
   o menu traz "Classificar" e "Histórico". Cadastre (ou troque para) um
   **pesquisador** e mostre que o menu traz "Laboratório de modelos". Pontue que
   o aviso de apoio (RNF01) está fixo no topo em todas as telas. Lembre que
   **estar logado é obrigatório** para qualquer tela de dados: sem sessão, as
   rotas devolvem 401 `UNAUTHENTICATED` (D10) — ainda sem trava por perfil (D3).
2. **Classificar um caso maligno.** Em "Classificar", use o botão de exemplo
   maligno. O resultado sai como **maligno** com confiança alta — destaque que a
   decisão usa o limiar de segurança 0,31 (prioriza não perder maligno), com cor
   + texto + ícone, nunca só cor.
3. **Classificar um caso benigno.** Use o exemplo benigno; o resultado sai como
   **benigno**. Mostre que, em caso de erro de validação, o formulário não é
   limpo.
4. **Histórico filtrado.** Vá a "Histórico" e filtre por classe (ex.: só
   malignos) e por faixa de confiança. Mostre que os filtros aparecem na URL
   (compartilhável) e a paginação funciona.
5. **Disparar um treino.** No "Laboratório de modelos", dispare um treino dos
   dois modelos (com GridSearchCV). Mostre a tabela comparativa, as curvas ROC
   sobrepostas e a matriz de confusão. Frase de efeito para a banca: o treino
   disparado na tela grava em `ml/artifacts/runs/{training_run_id}/` e **não
   altera os números do artigo** — mostre `git status` limpo depois do treino
   (RNF03, D8).
6. **A regra dos 0,97 bloqueando a promoção.** Use o slider de limiar para
   escolher um ponto em que a sensibilidade cai abaixo de 0,97 e tente promover:
   o sistema **bloqueia** com a mensagem de não conformidade (400
   `SENSITIVITY_BELOW_TARGET`). Depois escolha o limiar de segurança (0,31 para a
   RL) e mostre a promoção bem-sucedida, com o selo "em produção".

---

## 4. Pendências

Nenhuma pendência funcional dos RF/RNF: todos estão implementados (RNF05 por
decisão D2 passou a "sem criptografia", o que é uma pendência **de documento**,
não de código).

- **Correção de documentação (TCC).** Ver seção 5 — é o trabalho que resta para
  a equipe, no `.docx`.
- **Isolamento de testes — ✅ resolvida.** `tests/test_training.py` executava o
  treino sob demanda com `output_dir` padrão, sobrescrevendo `ml/artifacts/`.
  Com o diretório por execução (D8, seção 2.5) e a limpeza no `tearDown` de
  `tests/base.py`, a suíte não toca mais nos artefatos versionados:
  `git status --porcelain ml/artifacts` fica vazio depois de rodar os testes.
- **Coerência das métricas gravadas — ✅ resolvida.** Ver seção 2.6: a invariante
  `sensitivity == vp/(vp+fn)` vale para toda linha de `trained_models` e é
  verificada automaticamente.
- **`artifact_path` apontando para a referência — ✅ resolvida.** Ver seção 2.6,
  defeito B: uma linha por execução, unicidade `(training_run_id, name)`.
- **Migração versionada de schema (Alembic) — fora de escopo.** O projeto nunca
  teve Alembic e a política fechada no design é recriação de schema sem migração
  de linhas (banco de desenvolvimento descartável). A recriação necessária para
  D11/D12 está documentada no README e na especificação, para SQLite e para
  PostgreSQL. Se o avaliador exigir migração versionada, é trabalho novo.
- **`GET /models/comparison` devolve um item por nome de modelo** (o mais
  recente), não um item por execução. Mudar isso seria redesenho da tela, não
  correção de defeito; o aviso `test_partitions_mixed` cobre o risco
  metodológico que resta.
- **`npm audit` (dev).** 4 vulnerabilidades em dependências transitivas de
  desenvolvimento (dev-server do Vite e react-router). Não afetam produção;
  correção só com upgrade breaking da stack travada no design.
- **Fora de escopo por decisão da equipe (D2/D3):** criptografia AES-256-GCM,
  JWT, RBAC e trilha de auditoria **não** foram implementados — removidos a
  pedido, por prazo.

---

## 5. Correções necessárias no documento do TCC (`.docx`)

Esta é a lista pronta para a equipe aplicar. Decorre das decisões D1–D7 e do
feedback do Prof. Nelson Aguiar de 08/10. É a revisão da seção "Pendências de
documentação" da especificação consolidada, confrontada com o que foi
efetivamente construído.

1. **Reescrever o RNF05.** O texto atual promete criptografia dos dados
   identificados, que **não existe no código** (removida por D2). Reescrever
   para refletir a realidade: o modo identificado grava nome e prontuário em
   texto, e a aplicação não deve ser exposta fora de ambiente controlado.
   Sugestão de redação: *"Os dados do modo identificado são armazenados sem
   criptografia nesta versão; a ferramenta é de uso acadêmico e restrita a
   ambiente controlado."*

2. **Capítulo 5 (Arquitetura) — remover RBAC e JWT.** Tirar da Camada de
   Aplicação a menção a "controle de acesso baseado em perfis (RBAC)" e, da seção
   de Banco de dados, "credenciais criptografadas e perfis de acesso". Substituir
   por: cadastro/login simples com perfil **declarado** (sem trava de
   autorização); senha com hash pbkdf2; sessão por cookie, **sem JWT**.

3. **Seção 4.2 — remover auditoria e AES-256-GCM.** Tirar as menções a registro
   de auditoria e à criptografia AES-256-GCM (e a JWT/bcrypt, se citados aqui).
   Nada disso existe no código.

4. **Figura 2 (diagrama de classes) — remover `wandb`.** O `wandb` não é usado e
   foi apontado pelo professor como fora dos requisitos (D7).

5. **Legendas das Figuras 3 a 6 — corrigir.** Hoje as Figuras 3, 4 e 6 repetem o
   título "Diagrama de sequência do Módulo de Autenticação". A ordem real dos
   fluxos nos diagramas de sequência (ver `docs/diagrams.md`) é:
   - **Figura 3** — Seleção de Perfil
   - **Figura 4** — Triagem e Classificação (de biópsia)
   - **Figura 5** — Histórico (consulta e filtragem)
   - **Figura 6** — Laboratório de Modelos (treino, comparação e promoção)

6. **Incluir nos requisitos** (feedback do professor, 08/10):
   - **RF** de cadastro/login com perfil (médico ou pesquisador declarado no
     cadastro).
   - **RF** de histórico com **paginação e filtros** (período, classe, modo,
     faixa de confiança).
   - **RNF** de **meta de sensibilidade ≥ 0,97** como condição de promoção de
     modelo (regra de segurança clínica).
   - **RNF** de banco de dados **PostgreSQL** (com SQLite apenas em
     desenvolvimento).

7. **Backlog (Quadro 11) — incluir HT01 a HT03 e as atividades técnicas.**
   Registrar as histórias técnicas HT01, HT02 e HT03 e as atividades técnicas no
   backlog, conforme pedido.

8. **Base de dados — corrigir a descrição.** Garantir que o documento descreva a
   base como **tabular** (30 medidas numéricas de punção aspirativa por agulha
   fina), **não** como "imagens de biópsia". Usar o nome correto do dataset
   (*Wisconsin Diagnostic Breast Cancer Dataset*), corrigir os exemplos do UC01
   e incluir a fonte do dataset nas Referências.

---

## 6. Estado da branch e commits

Branch: **`feat/mvp-alinhado-documentacao`** — commits apenas locais (sem push,
sem PR; a publicação fica a critério da equipe).

As duas correções pós-revisão descritas na seção 2.5 (isolamento dos artefatos
do treino sob demanda e sessão obrigatória nas rotas de dados) entram nesta
mesma branch, acima de `b96c97c`, em commits `fix:` de código e um commit
`docs:` de documentação. Os três defeitos de métricas da seção 2.6 entram acima
de `1b450f3`, em seis commits (artefato de probabilidades do teste, esquema,
semântica das métricas na API, testes, frontend e documentação), e o fechamento
da entrega em três commits de documentação (documentação funcional, artefatos da
verificação e atualização do README e deste relatório).

Commits desta entrega (do mais recente ao mais antigo, acima de `origin/main`),
incluindo os commits de fechamento da documentação:

```
docs: aponta a documentacao funcional e registra a verificacao final
docs(tasks): registra a verificacao final e as capturas das quatro telas
docs: adiciona a documentacao funcional do sistema
docs(tasks): registra o hash do commit de documentacao no plano
docs: registra os tres defeitos de metricas e a nova semantica
fix(frontend): rotula teste x portao out-of-fold no Laboratorio de Modelos
test: cobre a invariante das metricas e a composicao do teste por execucao
fix(api): recalcula as metricas de teste no limiar vigente (defeitos A, B e C)
fix(db): separa o portao out-of-fold das metricas de teste em trained_models
feat(ml): persiste as probabilidades do conjunto de teste por execucao
fix: isola artefatos por execucao (RNF03) e exige sessao nas rotas de dados
docs: reescreve README, alinha a especificacao e adiciona o relatorio de implementacao
docs(tasks): registra verificacao ponta a ponta do MVP alinhado
docs(tasks): mark FEAT-003 done with verification findings
feat(frontend): login, classify, history and model lab screens
feat(frontend): clinical design system with accessible tokens and shared components
feat(frontend): add react-router-dom, /api/v1 client and app shell with permanent RNF01 banner
docs: registra conclusao da FEAT-002 e artefatos de planejamento
docs: atualiza README e especificacao para o contrato /api/v1 e RNF04
chore: regenera artefatos de treino com vetor out-of-fold persistido
test: suite unittest para predict, limiar, validacao, auth, predictions e treino
feat: rotas de treino sob demanda e promocao de modelo (RNF04)
feat: treino sob demanda com GridSearchCV e persistencia do vetor OOF
refactor: migra o backend para /api/v1, remove a criptografia e adiciona login simples
docs: corrigir 3 achados da revisao 3 no design tecnico
```

Três scripts de apoio continuam **não rastreados**, por decisão: são ferramentas
de inspeção local, não parte do produto —
`.agents/diagnostico_metricas.py` (coerência das linhas de `trained_models` e
procedência dos artefatos), `.agents/comparar_artefatos.py` (artefatos
commitados × árvore de trabalho) e `.agents/preparar_demo.py` (recria o banco de
demonstração). Eles estão no repositório em disco e são usados nos comandos das
seções 2.6 e 2.7; quem clonar o repositório não os recebe.

O banco de demonstração `instance/tcc_cancer_mama.db` também não é versionado
(está no `.gitignore`): ele é recriado por `python app.py` +
`.agents/preparar_demo.py`.
