# Especificação consolidada — TCC Grupo 05

Fonte da verdade para a implementação. Consolida: "Grupo 5 — Documentação de Software"
(cap. 1 a 5), as 4 rodadas de feedback do Prof. Nelson Aguiar, os 6 diagramas UML e as
alterações combinadas por WhatsApp em 09/10/2026.

Onde documento e diagramas divergiam, a decisão tomada está registrada em
"Decisões" abaixo, com a justificativa. **Se uma mudança de código contrariar este
arquivo, este arquivo deve ser atualizado junto.**

---

## 1. Produto

Sistema web de apoio à decisão que classifica uma biópsia mamária entre **benigna** e
**maligna** a partir das 30 características quantitativas do *Wisconsin Diagnostic
Breast Cancer Dataset* (WDBC/UCI), com grau de confiança, histórico das avaliações e
um laboratório de modelos para o pesquisador comparar Regressão Logística e SVM.

Não é ferramenta diagnóstica. Não substitui laudo histopatológico nem avaliação médica.

Dois perfis: **Médico** (triagem) e **Pesquisador** (treino e avaliação dos modelos).

---

## 2. Decisões (resolvem conflitos entre os artefatos)

| # | Conflito | Decisão | Motivo |
|---|----------|---------|--------|
| D1 | Diagramas usam `/api/v1/...` em inglês; código atual usa `/api/avaliacoes` em português | **Seguir os diagramas.** Rotas `/api/v1/...`, tabelas `evaluations` / `training_runs` | Os diagramas são o artefato mais recente e específico, e são o que o professor avalia |
| D2 | RNF05 exige criptografia de dado identificado; WhatsApp 09/10 pede remover o AES-256-GCM | **Remover a criptografia.** Modo identificado continua existindo, gravando `patient_name` / `patient_record` em texto. RNF05 precisa ser reescrito no documento pela equipe | Pedido explícito da equipe (prazo curto). Fica registrado como pendência de documentação |
| D3 | Diagramas de sequência descrevem JWT 8h, bcrypt, RBAC e auditoria; WhatsApp pede remover | **Sem JWT, sem RBAC, sem tabela de auditoria.** Apenas cadastro e login. O perfil é informado no cadastro e serve só para decidir quais telas o usuário vê. Nenhuma trava de autorização. **Nota:** D3 removeu a segregação por perfil e a trava de autorização; **não** removeu a necessidade de estar autenticado — ver D10 | Pedido explícito da equipe. Alinhado ao texto da seção "Seleção de Perfil", que já diz "sem a necessidade de mecanismos adicionais de controle de acesso nesta etapa" |
| D4 | Senha | **Hash com `werkzeug.security` (pbkdf2).** Nunca texto puro | Não é RBAC nem segregação de perfil; é só não deixar senha legível no banco |
| D5 | Banco | **PostgreSQL** como alvo, via `DATABASE_URL`. Sem a variável, cai em SQLite local | Documento fixa PostgreSQL 16; a máquina de desenvolvimento não tem Postgres instalado |
| D6 | GridSearchCV está no diagrama do Laboratório de Modelos mas o professor disse estar fora das sprints 2 e 3 | **Implementar.** 5 folds, `scoring="recall"` | Está no diagrama, e o diagrama é avaliado |
| D7 | Diagrama de classes cita `wandb` | **Não usar.** Equipe deve remover da Figura 2 | Professor apontou que não consta nos requisitos |
| D8 | `POST /training-runs` gravava em `ml/artifacts/`, sobrescrevendo a referência versionada do artigo | **`ml/artifacts/` é a referência versionada; execuções da API são isoladas.** O treino sob demanda grava em `ml/artifacts/runs/{training_run_id}/` (incluindo `report/`) e o `artifact_path` do `trained_models` aponta para lá; a pasta `runs/` fica no `.gitignore`. `python -m ml.train` continua gravando em `ml/artifacts/` porque é o caminho deliberado de regerar a referência — isso está explícito no código e na documentação | O RNF03 exige partição/hiperparâmetros versionados e o relatório cita sensibilidade 0,9762; um treino disparado na defesa não pode alterar silenciosamente esses números |
| D9 | Qual artefato a inferência usa depois de um treino sob demanda | **A classificação (`POST /predictions`) usa sempre os artefatos de referência de `ml/artifacts/`.** `ml/predict.py` não consulta o banco. Promover um modelo de execução registra o ponto de operação no banco e no Laboratório, mas **não** troca o artefato que classifica; para tornar uma execução a nova referência, roda-se `python -m ml.train` | A promoção já não alterava a inferência: o efeito que um treino da API tinha na classificação era só o efeito colateral da sobrescrita dos artefatos — o defeito corrigido em D8. Tornar `predict` ciente do banco é mudança de arquitetura fora do escopo |
| D10 | Rotas de dados respondiam 200 sem nenhum cookie de sessão, enquanto `/auth/me` devolvia 401 | **Autenticação (não autorização) exigida nas rotas de dados.** Sessão válida obrigatória em `/features/schema`, `/predictions*`, `/models*` e `/training-runs*`; sem sessão → 401 `UNAUTHENTICATED`. `/auth/*` e `/health` seguem públicas. **Nenhuma verificação de perfil** (D3): médico autenticado chama rota de pesquisador e vice-versa. Implementado por decorador explícito `exigir_sessao` rota a rota, com teste que varre o `url_map` para nenhuma rota nova escapar | O fluxo da Figura 3 (Seleção de Perfil) coloca o usuário entrando antes de qualquer operação, e o modo identificado grava nome e prontuário em texto (D2) |

### Pendências de documentação geradas por estas decisões

A equipe precisa ajustar no documento (não é código):

1. **RNF05** — reescrever: hoje promete criptografia, que não existirá no código.
2. **Capítulo 5 (Arquitetura)** — remover "controle de acesso baseado em perfis (RBAC)"
   da Camada de Aplicação e "credenciais criptografadas e perfis de acesso" da seção
   Banco de dados. Trocar por cadastro/login simples com perfil declarado.
3. **Seção 4.2** — remover as menções a JWT, bcrypt, auditoria e AES-256-GCM.
4. **Figura 2** — remover `wandb`.
5. **Legendas das Figuras 3 a 6** — a ordem real dos arquivos é: Seleção de Perfil,
   Triagem e Classificação, Histórico, Laboratório de Modelos.
6. **Incluir nos requisitos** (pedido do professor, item b): RF de cadastro/login com
   perfil, RNF de meta de sensibilidade ≥ 0,97, RF de paginação com filtros, RNF de
   PostgreSQL.
7. **HT01 a HT03** e as atividades técnicas no backlog (Quadro 11).

---

## 3. Arquitetura

Quatro camadas, conforme capítulo 5 do documento:

```
Frontend (React + Vite)
        │  HTTP/JSON — consome exclusivamente a API REST
        ▼
Backend (Flask)  ── regras de negócio, validação, orquestração, erros padronizados
        │                                  │
        ▼                                  ▼
ML Engine (scikit-learn)            Persistência (PostgreSQL via SQLAlchemy)
modelos carregados em memória       users, evaluations, trained_models, training_runs
```

O frontend nunca acessa banco nem a engine de ML diretamente.

---

## 4. Modelo de dados

### `users`
`id`, `name`, `email` (único), `password_hash`, `profile` (`medico` | `pesquisador`), `created_at`

### `evaluations` — histórico imutável (não pode ser alterado nem removido pela aplicação)
`id`, `user_id` (FK, nullable), `features` (JSON com as 30), `label`
(`benigno` | `maligno`), `probability` (float), `confidence` (float —
pendência 1, abaixo), `confidence_band` (texto),
`model_name`, `threshold_used`, `mode` (`anonimo` | `identificado`),
`patient_name` (nullable), `patient_record` (nullable),
`elapsed_ms` (int, para o RNF02), `created_at`

**Pendência 1 (corrigida):** esta seção listava apenas `probability` e
`confidence_band`, mas a seção 5 define os filtros `confidence_min`/
`confidence_max`, que exigem um valor numérico de confiança. A coluna
`confidence` (float — `P(maligno)` se maligno, `1 − P(maligno)` se benigno)
foi acrescentada para sustentar esse filtro (ver design.md §2.2, §10).

Índices compostos para o histórico filtrável (Figura do Módulo de Histórico):
`(created_at desc)`, `(label, created_at desc)`, `(mode, created_at desc)`

### `trained_models`
`id`, `training_run_id` (FK), `name`, `accuracy`, `sensitivity`, `specificity`, `auc`,
`false_negative_rate`, `train_oof_sensitivity`, `threshold`, `safety_threshold`,
`hyperparameters` (JSON), `random_seed`, `artifact_path`, `artifact_sha256`,
`is_production` (bool), `roc_points` (JSON), `confusion_matrix` (JSON), `trained_at`

**D11 — duas grandezas, dois campos.** `accuracy`, `sensitivity`, `specificity`,
`false_negative_rate` e `confusion_matrix` são **sempre** do CONJUNTO DE TESTE da
execução daquele modelo, avaliado no `threshold` vigente da linha, e são
gravadas sempre em conjunto; `auc` é do teste e independe do limiar. O portão de
promoção do RNF04 fica em `train_oof_sensitivity` (Float, nullable):
sensibilidade das predições out-of-fold do **treino** no `threshold` da linha.
Esse valor nunca é gravado em `sensitivity`. Invariante, com teste automatizado
(`tests/test_metricas_coerentes.py`): `sensitivity == vp/(vp+fn)` e
`false_negative_rate == fn/(vp+fn)` sobre a própria `confusion_matrix`, além de
`specificity == vn/(vn+fp)` e `accuracy == (vn+vp)/total`.

**D12 — uma linha por execução.** A unicidade da tabela é
`UniqueConstraint("training_run_id", "name", name="uq_trained_models_run_name")`
— uma linha por (execução, modelo). `artifact_sha256` continua gravado como
procedência (RNF03), mas **sem** `unique`: dois treinos deterministas com a mesma
semente e os mesmos dados produzem legitimamente os mesmos bytes, e era o desvio
de "reaproveitar o registro quando o hash coincide" que fazia `artifact_path`
apontar para a referência 80/20 em modelos nascidos de execuções 70/30.

`artifact_path` é **por execução** (D8) e aponta **sempre** para o artefato da
própria execução: `ml/artifacts/{nome}.joblib` para os modelos de referência
versionados e `ml/artifacts/runs/{training_run_id}/{nome}.joblib` para um treino
disparado pela API. É esse caminho que a promoção
(`PUT /models/{id}/threshold`) usa para localizar o `{nome}_oof.json` e o
`{nome}_test_proba.json` da própria execução.

**Recriação de schema.** O projeto não usa Alembic e a política é recriação sem
migração de linhas (banco de desenvolvimento descartável) — o que também é o
certo aqui, porque as linhas anteriores estão inconsistentes. SQLite: apagar
`instance/tcc_cancer_mama.db`. PostgreSQL:
`DROP SCHEMA public CASCADE; CREATE SCHEMA public;`. Em seguida, subir a
aplicação, que executa `create_all()` + `sincronizar_modelos()`.

### `training_runs`
`id`, `models_requested` (JSON), `test_size`, `random_seed`, `grid_search` (bool),
`dataset_sha256`, `split` (JSON com os índices das partições), `library_versions` (JSON),
`git_commit`, `status` (`running` | `success` | `failed`), `error_message`,
`started_at`, `finished_at`

---

## 5. API REST

Prefixo `/api/v1`. Erros sempre `{"error": "...", "code": "..."}`.
Códigos de erro: `VALIDATION_ERROR` (400), `UNAUTHENTICATED` (401), `NOT_FOUND` (404),
`MODEL_UNAVAILABLE` (503), `TIMEOUT` (504), `SENSITIVITY_BELOW_TARGET` (400),
`INTERNAL_ERROR` (500).

### Autenticação (D3 — simples, sem trava)

| Método | Rota | Descrição |
|--------|------|-----------|
| POST | `/api/v1/auth/register` | `{name, email, password, profile}` → 201 |
| POST | `/api/v1/auth/login` | `{email, password}` → 200 `{user}` + cookie de sessão |
| POST | `/api/v1/auth/logout` | 204 |
| GET | `/api/v1/auth/me` | usuário da sessão, ou 401 |

As quatro rotas de `/auth/*` são **públicas**. O `profile` retornado define o menu do
frontend. Nenhuma rota é bloqueada por perfil. Todas as rotas fora de `/auth/*` exigem
sessão válida; sem sessão, 401 `UNAUTHENTICATED`. A trava é de autenticação, não de
autorização (D10).

### Triagem e classificação (US01, US02, US03 — Figura "Triagem e Classificação")

Ambas **exigem sessão** (D10); nenhuma verifica perfil (D3).

| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/api/v1/features/schema` | 30 características: nome, rótulo em português, unidade, `min`, `max`, exemplo. Faixas derivadas do WDBC |
| POST | `/api/v1/predictions` | classifica e grava a avaliação (autoria do usuário da sessão em `evaluations.user_id`) |

Requisição:
```json
{ "features": { "mean_radius": 17.99, "...": "(30 campos)" },
  "mode": "anonimo",
  "patient_name": null, "patient_record": null }
```

Resposta 200:
```json
{ "evaluation_id": 1, "label": "maligno", "probability": 0.983,
  "confidence": 0.983, "confidence_band": "alta",
  "model_name": "regressao_logistica", "threshold_used": 0.31,
  "elapsed_ms": 18, "safety_threshold_triggered": false,
  "disclaimer": "Esta classificação é uma ferramenta de apoio e não substitui o laudo histopatológico e a avaliação médica." }
```

`confidence` é o valor numérico da confiança na classe prevista (`P(maligno)` se
maligno; `1 − P(maligno)` se benigno) — é a coluna que sustenta os filtros
`confidence_min` / `confidence_max` do histórico. `safety_threshold_triggered`
(não contratual, usado só pela interface) indica quando o caso foi classificado
como maligno com `P(maligno) < 0,5`, por efeito do limiar de segurança.

Comportamento obrigatório:
- Modelo de produção carregado em memória na subida da aplicação.
- `StandardScaler` aplicado antes da inferência.
- Classe decidida por `P(maligno) >= threshold` do modelo de produção (nunca `predict()`).
- `confidence_band`: `alta` (≥ 0,90), `média` (0,70–0,90), `baixa` (< 0,70).
  **Pendência 3 (nota):** o valor de API e de filtro é sempre `media`, **sem
  acento** (ex.: `"confidence_band": "media"`); o acento em "média" aparece
  só no texto exibido na interface. Não "corrigir" o acento no valor de API —
  isso quebraria o contrato (design.md §1.5, §10).
- Gravação transacional em `evaluations`; a resposta só sai depois do commit.
- Modelo ausente → 503 `MODEL_UNAVAILABLE`. Estouro de 2 s → 504 `TIMEOUT`, com log
  estruturado. Em ambos os casos o frontend preserva os dados preenchidos.

### Histórico (US07 — Figura "Módulo de Histórico")

Ambas **exigem sessão** (D10); nenhuma verifica perfil (D3).

| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/api/v1/predictions` | lista paginada |
| GET | `/api/v1/predictions/{id}` | detalhe |

Filtros: `page` (default 1), `limit` (default 25, máx. 100), `label`, `mode`,
`date_from`, `date_to`, `confidence_min`, `confidence_max`.
Resposta: `{ "items": [...], "page": 1, "limit": 25, "total": 137 }`.
Ordenação padrão: mais recentes primeiro.

### Laboratório de modelos (US04, US05, US06 — Figura "Laboratório de Modelos")

Todas **exigem sessão** (D10); nenhuma verifica perfil (D3) — um médico autenticado
chama estas rotas normalmente.

| Método | Rota | Descrição |
|--------|------|-----------|
| POST | `/api/v1/training-runs` | dispara o treino → **201** `{training_run_id, status, artifacts_dir}` |
| GET | `/api/v1/training-runs/{id}` | status e resultado |
| GET | `/api/v1/models` | modelos registrados |
| GET | `/api/v1/models/comparison` | métricas de teste por execução + composição desse teste + pontos da curva ROC |
| GET | `/api/v1/models/features?model=&top=` | importância por permutação |
| PUT | `/api/v1/models/{id}/threshold` | valida pelo portão out-of-fold, promove a produção e recalcula as métricas de teste |
| GET | `/api/v1/models/export?format=csv` | CSV com métricas e hiperparâmetros |

`POST /training-runs` recebe `{ "models": ["regressao_logistica", "svm"],
"test_size": 0.2, "grid_search": true, "hyperparameters": {...} }`. Executa
`GridSearchCV` com 5 folds estratificados e `scoring="recall"` (D6), registra semente
42, índices das partições, SHA-256 do dataset e dos artefatos, commit do git e versões
das bibliotecas, salva os artefatos em `ml/artifacts/runs/{training_run_id}/`
(**nunca sobrescreve a referência de `ml/artifacts/`** — D8) e grava as métricas. A
resposta 201 traz o campo aditivo `artifacts_dir` com esse caminho relativo
(ex.: `"ml/artifacts/runs/7"`), no mesmo espírito não contratual de
`safety_threshold_triggered`.

`GET /models/comparison` é dirigido pelo banco: um item por nome de modelo, a
linha mais recente. Expõe os campos aditivos `artifact_path` e
`training_run_id` (procedência da execução) e, por D11/D12:

| Campo | Significado |
|---|---|
| `test_size` | fração de teste da execução daquele modelo (`training_runs.test_size`) |
| `test_set_size` | tamanho do conjunto de teste daquele modelo, derivado da própria matriz de confusão (`vn+fp+fn+vp`); `null` sem matriz |
| `test_set_malignant` | malignos nesse teste (`vp+fn`); `null` sem matriz |
| `train_oof_sensitivity` | portão out-of-fold do **treino** no limiar vigente |
| `gate_meets_sensitivity_target` | `train_oof_sensitivity >= 0,97` |
| `meets_sensitivity_target` | `operating_point.sensitivity >= 0,97` (**teste**) |
| `test_partitions_mixed` (topo) | `true` quando os itens vêm de execuções ou partições diferentes |
| `test_partitions` (topo) | `[{training_run_id, test_size, test_set_size, test_set_malignant}]` |

`operating_point` vem das colunas do banco (conjunto de teste no limiar
vigente). `default_point`, `cross_validation` e `safety_threshold_reached_target`
vêm do `metrics.json` **da execução daquele registro** e são `null` quando a
execução já foi descartada — nunca da referência, que é outra partição. O bloco
`reproducibility` descreve **os artefatos de referência** de `ml/artifacts/`
(split 80/20), não necessariamente a execução dos modelos listados.

`PUT /models/{id}/threshold` é a **regra de segurança clínica**. O **portão** é a
sensibilidade das predições out-of-fold do **treino** no ponto de operação
pedido, lida de `{nome}_oof.json`; só promove o modelo se **≥ 0,97**. Abaixo
disso devolve 400 `SENSITIVITY_BELOW_TARGET` com a sensibilidade obtida e a
exigida, sem alterar nada. Passando o portão, o valor vai para
`train_oof_sensitivity` e **todas** as métricas reportadas são recalculadas em
conjunto no conjunto de teste, no limiar novo, a partir de
`{nome}_test_proba.json`. Se esse artefato faltar: 503 `MODEL_UNAVAILABLE`
**sem gravar nada** (uma linha meio atualizada é o defeito que D11 corrige).

Resposta 200:
```json
{ "model": "regressao_logistica", "threshold": 0.01,
  "train_oof_sensitivity": 0.9941,
  "test_metrics": { "accuracy": 0.7982, "sensitivity": 1.0,
                    "specificity": 0.6806, "auc": 0.996,
                    "false_negative_rate": 0.0,
                    "confusion_matrix": {"vn": 49, "fp": 23, "fn": 0, "vp": 42} } }
```

A chave `sensitivity` de nível superior **não existe mais**: era o portão
out-of-fold disfarçado de métrica reportada.

---

## 6. Machine learning

- Base: `data/wdbc.data` (569 registros, 30 características, rótulo B/M). Tabular —
  **não** são imagens. São medidas extraídas de punção aspirativa por agulha fina (FNA).
- 10 características base (radius, texture, perimeter, area, smoothness, compactness,
  concavity, concave points, symmetry, fractal dimension) em 3 variações
  (`mean`, `se`, `worst`) = 30.
- `StandardScaler` ajustado só no treino.
- Modelos: `LogisticRegression` e `SVC(probability=True)`.
- Split 80/20 estratificado, `random_state=42`, índices salvos em `split.json` (RNF03).
- Validação cruzada estratificada 5 folds no conjunto de treino.
- **Limiar de segurança**: o maior limiar ≤ 0,5 que mantém sensibilidade ≥ 0,97,
  calculado com predições *out-of-fold* do treino. O conjunto de teste nunca é usado
  para escolher limiar — **só reporta métricas** no limiar já decidido. Isso vale
  também no ajuste manual do limiar (`PUT /models/{id}/threshold`): quem decide é
  o out-of-fold, quem reporta é o teste (D11).
- Artefatos por execução que sustentam essa separação: `{modelo}_oof.json`
  (`{"y_true","proba"}` do treino, insumo do portão) e
  `{modelo}_test_proba.json` (`{"y_true","proba"}` do teste, insumo do recálculo
  das métricas reportadas). Ambos são gravados por
  `ml.train.train_and_evaluate` no diretório da execução e regenerados
  deterministicamente quando faltam, a partir de `split.json`, `scaler.joblib` e
  `{modelo}.joblib` (`services.modelos.regenerar_oof_ausentes` e
  `regenerar_test_proba_ausentes`).
- Métricas reportadas nos dois pontos de operação (0,5 e limiar de segurança):
  acurácia, sensibilidade, especificidade, AUC, **taxa de falsos negativos** (RNF04),
  matriz de confusão, pontos da ROC.
- Melhor modelo: maior sensibilidade no ponto de operação; empate resolvido por AUC,
  depois especificidade.
- Reprodutibilidade (RNF03): semente, partições, hiperparâmetros, versões, commit e
  SHA-256 de todos os artefatos e do dataset, versionados em `ml/artifacts/`.
  `ml/artifacts/` é a **referência versionada do artigo** (split 80/20, semente 42),
  regerada **somente** por `python -m ml.train`; execuções de treino sob demanda são
  isoladas em `ml/artifacts/runs/{training_run_id}/`, descartáveis e **não
  versionadas** (D8).
- Exportação científica: curvas ROC, matrizes de confusão e ranking de características
  em **300 DPI**, mais CSV, em `ml/artifacts/report/` para a referência e em
  `ml/artifacts/runs/{training_run_id}/report/` para cada execução sob demanda.
- Importância das características por **permutação** sobre o melhor modelo (US06).

---

## 7. Frontend

React + Vite, consumindo só a API. Rotas:

| Tela | Perfil | Conteúdo |
|------|--------|----------|
| Login / Cadastro | — | cadastro com escolha de perfil (médico ou pesquisador) |
| Classificar | Médico | formulário das 30 características **ou** importação de CSV; escolha entre registro anônimo e identificado; resultado com indicação visual, grau de confiança e aviso legal |
| Histórico | Médico e Pesquisador | tabela paginada, filtros por período, classe, modo e faixa de confiança, **com os filtros refletidos na URL** |
| Laboratório de Modelos | Pesquisador | disparar treino, tabela comparativa, **curvas ROC sobrepostas**, slider de limiar com a regra dos 0,97, ranking de características, exportar CSV |

Obrigatório:
- **RNF01**: o aviso de que é ferramenta de apoio e não substitui o laudo
  histopatológico nem a avaliação médica fica **permanentemente visível**, não só na
  tela de resultado.
- **Validação no cliente** contra as faixas de `/features/schema` com **margem de
  tolerância de 20%** antes de enviar.
- O menu é renderizado conforme o perfil (D3), sem trava de acesso.
- Erro de classificação não limpa o formulário.

### Qualidade visual

O trabalho é um TCC e vai ser apresentado. A interface precisa ser limpa e
profissional, não um protótipo:

- Sistema de design consistente: paleta, espaçamento, tipografia e componentes
  reutilizáveis. Tema clínico sóbrio.
- Contraste **WCAG AA**, navegação por teclado, `label` associado a todo campo,
  mensagens de erro ligadas ao campo via `aria-describedby`, foco visível.
- Nunca comunicar benigno/maligno só por cor — sempre cor + texto + ícone.
- Responsivo. O formulário de 30 campos agrupado pelas 10 características base com as
  3 variações, não uma lista corrida de 30 inputs.
- Estados de carregamento, vazio e erro tratados em todas as telas.

---

## 8. Requisitos verificáveis

| ID | Verificação |
|----|-------------|
| RF01 | formulário aceita e valida as 30 características |
| RF02 | classifica entre benigno e maligno |
| RF03 | exibe grau de confiança |
| RF04 | treina e compara Regressão Logística e SVM na mesma base |
| RF05 | exibe acurácia, sensibilidade, especificidade e AUC |
| RF06 | exibe as características mais relevantes do melhor modelo |
| RF07 | mantém histórico, sem exigir identificação do paciente |
| RNF01 | aviso permanente em todas as telas |
| RNF02 | classificação conclui em < 2 s; `elapsed_ms` gravado e teste automatizado |
| RNF03 | partições, hiperparâmetros, semente e versões versionados; treino pela API não altera `ml/artifacts/` (`git status` limpo após o POST — D8) |
| RNF04 | taxa de falsos negativos reportada explicitamente; limiar de segurança 0,97 validado pelo portão out-of-fold do treino (`train_oof_sensitivity`); invariante das métricas de teste verificada automaticamente em `tests/test_metricas_coerentes.py` (`sensitivity == vp/(vp+fn)` e `false_negative_rate == fn/(vp+fn)` em toda linha de `trained_models`) |
| RNF05 | **alterado por D2** — modo identificado sem criptografia; documento a corrigir |

---

## 9. Ambiente

- Python 3.14; Flask, Flask-CORS, Flask-SQLAlchemy, scikit-learn, pandas, numpy,
  joblib, python-dotenv, matplotlib, psycopg (v3). Ver `requirements.txt`.
- Node 24, React, Vite.
- `DATABASE_URL` aponta para PostgreSQL; ausente, usa SQLite local (D5).
- Testes: `python -m unittest discover -s tests -t . -v`.

### Aviso de segurança a constar no README

Todas as rotas de dados exigem sessão válida (401 `UNAUTHENTICATED` sem ela); só
`/auth/*` e `/health` são públicas (D10). Não existe controle de acesso por perfil
(D3): **qualquer usuário autenticado**, médico ou pesquisador, consegue ler o
histórico identificado inteiro, disparar treinos e promover modelos. Os dados do modo
identificado (nome e prontuário da paciente) ficam **em texto puro** no banco (D2). A
aplicação não deve ser exposta fora de ambiente controlado: não há segregação de
dados, cifragem em repouso nem trilha de auditoria.
