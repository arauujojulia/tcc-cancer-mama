# Relatório de verificação — correções de métricas e documentação

Repositório `c:/Users/isaiaslm/tcc-cancer-mama`, branch `feat/mvp-alinhado-documentacao`,
HEAD `ff7479e`. Execução: 26/10/2026. Nenhum código de produção foi alterado nesta
rodada; os arquivos criados ficam todos em
`.agents/tasks/correcoes-metricas-documentacao/`.

## Placar

| # | Item | Resultado |
|---|---|---|
| 1 | Suíte `unittest` completa | **PASSOU** — 107 testes, 0 falhas |
| 2 | `ml.train` + `ml.report` + `git status ml/artifacts` após treino pela API | **PASSOU** |
| 3 | `npm install` + `npm run build` | **PASSOU** |
| 4 | API real (limiar extremo, portão 0,97, `artifact_path` por execução) | **PASSOU** |
| 5 | `diagnostico_metricas.py` sem `DIVERGENTE` | **PASSOU** |
| 6 | 4 telas abertas e capturadas no navegador | **PASSOU** |
| 7 | Números da Entrega 2 extraídos da fonte | **PASSOU** |

Nenhum item falhou. As observações secundárias (ruído de ambiente, não defeito do
sistema) estão na seção "Observações" ao fim.

---

## 1. Suíte de testes — PASSOU

```powershell
cd c:\Users\isaiaslm\tcc-cancer-mama
python -m unittest discover -s tests -t . -v
```

```
Ran 107 tests in 98.255s

OK
```

Zero falhas e zero erros. Nenhum teste a listar.

O teste da invariante existe e passou. Ele vive em
`tests/test_metricas_coerentes.py` (9 testes) e o helper `assert_linha_coerente`
confere, em **toda** linha de `trained_models`, contra a própria
`confusion_matrix` e com `places=6`:

```
sensitivity          == vp / (vp + fn)
false_negative_rate  == fn / (vp + fn)
specificity          == vn / (vn + fp)
accuracy             == (vn + vp) / (vn + fp + fn + vp)
sensitivity + false_negative_rate == 1
```

Testes do arquivo, todos `ok`:

```
test_referencia_sincronizada_grava_linhas_coerentes ... ok
test_treino_sob_demanda_grava_linhas_coerentes ... ok
test_put_threshold_mantem_a_tabela_inteira_coerente ... ok
test_limiar_baixo_derruba_a_especificidade_gravada ... ok
test_sensibilidade_de_teste_nao_e_o_portao_quando_os_dois_diferem ... ok
test_auc_nao_muda_com_o_limiar ... ok
test_regeneracao_reproduz_as_metricas_da_referencia ... ok
test_test_proba_ausente_devolve_503_sem_alterar_a_linha ... ok
test_treino_grava_test_proba_da_execucao ... ok
```

`tests/test_modelos_comparacao.py` acrescenta 8 testes, também todos `ok`
(composição do teste por linha, sinalização de mistura de partições,
`default_point` da execução certa, uma linha por nome).

---

## 2. Pipeline de ML e isolamento dos artefatos — PASSOU

### `python -m ml.train`

```powershell
cd c:\Users\isaiaslm\tcc-cancer-mama
python -m ml.train
```

Exit code 0, sem traceback. Saída final:

```
Regenerando os artefatos de referência em ml/artifacts/ (RNF03 — split 80/20, semente 42)
Melhor modelo: regressao_logistica
regressao_logistica  teste_padrao    limiar=0.50 acc=0.9649 sens=0.9286 esp=0.9861 auc=0.9960 FN=0.0714
regressao_logistica  teste_operacao  limiar=0.31 acc=0.9825 sens=0.9762 esp=0.9861 auc=0.9960 FN=0.0238
svm                  teste_padrao    limiar=0.50 acc=0.9737 sens=0.9286 esp=1.0000 auc=0.9927 FN=0.0714
svm                  teste_operacao  limiar=0.38 acc=0.9737 sens=0.9524 esp=0.9861 auc=0.9927 FN=0.0476
```

O treino é reprodutível byte a byte nos números: a única diferença em relação ao
que está commitado é o carimbo de tempo e o hash do commit.

```powershell
git diff -- ml/artifacts/metrics.json ml/artifacts/train_config.json
```

```
-  "gerado_em": "2026-10-14T20:25:56.084610+00:00",
+  "gerado_em": "2026-10-26T13:39:03.411195+00:00",
-  "commit_git": "096bc54787318a90f40840bd51644a43b6dd4bab"
+  "commit_git": "ff7479ec15d4b13d4852d9a2482137de083a31ca"
```

Restaurado com `git checkout -- ml/artifacts` para manter os números publicados.

### `python -m ml.report`

```powershell
python -m ml.report
```

Exit code 0, sem traceback:

```
ml\artifacts\report\roc_comparacao.png
ml\artifacts\report\matrizes_confusao.png
ml\artifacts\report\importancia_regressao_logistica.png
ml\artifacts\report\importancia_svm.png
ml\artifacts\report\metricas.csv
```

### Treino pela API não toca na referência

Depois de dois `POST /api/v1/training-runs` reais (execuções 2 e 3, frações 0,3 e
0,2) com o servidor de pé:

```powershell
git -C c:/Users/isaiaslm/tcc-cancer-mama status --porcelain ml/artifacts
```

Saída **vazia**. Mesmo resultado após a suíte completa de testes e no estado
final da verificação. D8 confirmado: as execuções escrevem em
`ml/artifacts/runs/{id}/` e a referência 80/20 versionada fica intacta.

---

## 3. Build do frontend — PASSOU

```powershell
cd c:\Users\isaiaslm\tcc-cancer-mama\frontend
npm install
npm run build
```

```
up to date, audited 67 packages in 2s
=== INSTALL EXIT=0 ===

vite v5.4.21 building for production...
✓ 44 modules transformed.
dist/index.html                   0.43 kB │ gzip:  0.29 kB
dist/assets/index-ReDIXq6o.css   13.54 kB │ gzip:  3.24 kB
dist/assets/index-BVSCfXRu.js   205.26 kB │ gzip: 65.74 kB
✓ built in 8.21s
=== BUILD EXIT=0 ===
```

Sem erro e sem warning de compilação.

---

## 4. Requisições reais contra `python app.py` — PASSOU

Servidor subido com `python app.py` em `c:\Users\isaiaslm\tcc-cancer-mama`
(`/health` → `{"status": "ok"}`). Exercitado por
`.agents/tasks/correcoes-metricas-documentacao/verificar_runtime.py` (urllib +
`CookieJar`); saída integral em `runtime-api.txt` e `runtime-mistura.txt`.
Servidor derrubado ao final (confirmado: `/health` deixou de responder).

### 4.0 Sessão é exigida

`GET /api/v1/models` sem sessão → **HTTP 401**. Depois de
`POST /api/v1/auth/register` (201) e `POST /api/v1/auth/login` (200), as mesmas
rotas respondem 200. `GET /api/v1/auth/me` confirma a sessão.

### 4.1 `PUT /api/v1/models/1/threshold` com limiar 0,01

```
HTTP 200
{"model": "regressao_logistica",
 "threshold": 0.01,
 "train_oof_sensitivity": 0.9941,
 "test_metrics": {"accuracy": 0.7982456140350878,
                  "sensitivity": 1.0,
                  "specificity": 0.6805555555555556,
                  "auc": 0.996031746031746,
                  "false_negative_rate": 0.0,
                  "confusion_matrix": {"vn": 49, "fp": 23, "fn": 0, "vp": 42}}}
```

Linha gravada: `matriz={'vn': 49, 'fp': 23, 'fn': 0, 'vp': 42} total=114 malignos=42`,
`acc=0.798246 sens=1.000000 esp=0.680556 fn_rate=0.000000 auc=0.996032 limiar=0.01
oof_treino=0.994118`. Todas as invariantes conferidas contra a própria matriz:

```
[PASSOU] sensitivity == vp/(vp+fn)          -- 1.000000 vs 1.000000
[PASSOU] specificity == vn/(vn+fp)          -- 0.680556 vs 0.680556
[PASSOU] accuracy == (vp+vn)/total          -- 0.798246 vs 0.798246
[PASSOU] false_negative_rate == fn/(vp+fn)  -- 0.000000 vs 0.000000
[PASSOU] sens + fn_rate == 1
```

Separação portão × métrica reportada, que era o defeito A:

```
[PASSOU] resposta traz train_oof_sensitivity (campo proprio do portao)
[PASSOU] resposta NAO tem a chave ambigua 'sensitivity' de topo
[PASSOU] sensitivity gravada == test_metrics.sensitivity -- 1.0 vs 1.0
[PASSOU] sensibilidade out-of-fold NAO esta na coluna sensitivity
         -- sens_teste=1.000000 oof=0.994118
[PASSOU] especificidade CAIU com o limiar 0.01 -- 0.986111 -> 0.680556
[PASSOU] falsos positivos AUMENTARAM          -- fp 1 -> 23
[PASSOU] auc inalterada (independe do limiar)
```

A sensibilidade out-of-fold do treino (0,9941) aparece só em
`train_oof_sensitivity`; a coluna `sensitivity` carrega 1,0, que é a
sensibilidade de **teste** no limiar 0,01. Varrida a tabela inteira depois do
`PUT`: as duas linhas (`id=1` e `id=2`) passam em todas as invariantes.

### 4.2 Portão de 0,97 bloqueando com limiar 0,99

```
HTTP 400
{"code": "SENSITIVITY_BELOW_TARGET",
 "error": "Sensibilidade obtida abaixo da meta de segurança clínica.",
 "obtained": 0.7412, "required": 0.97}
```

```
[PASSOU] limiar 0.99 bloqueado com HTTP 400
[PASSOU] codigo SENSITIVITY_BELOW_TARGET
[PASSOU] erro informa obtained < required = 0.97
[PASSOU] bloqueio nao gravou nada (linha identica)
```

O `obtained` de 0,7412 é a sensibilidade **out-of-fold do treino** no limiar
pedido, que é o que o RNF04 avalia. Nada foi gravado: a linha ficou idêntica ao
estado anterior e continua coerente. Mesmo comportamento com 0,95
(`obtained: 0.8176`) e no `preparar_demo.py` com o SVM (`obtained: 0.7353`).

### 4.3 `POST /api/v1/training-runs` e `artifact_path`

```
HTTP 201 {"artifacts_dir": "ml/artifacts/runs/2", "status": "success", "training_run_id": 2}
```

`GET /api/v1/training-runs/2`:

```
modelo regressao_logistica: artifact_path=ml/artifacts/runs/2/regressao_logistica.joblib
modelo svm:                 artifact_path=ml/artifacts/runs/2/svm.joblib
```

```
[PASSOU] artifact_path fica em ml/artifacts/runs/2/        (os dois modelos)
[PASSOU] artifact_path NAO aponta para ml/artifacts/{nome}.joblib
[PASSOU] artefato existe em disco
[PASSOU] invariante das metricas na linha de cada execucao
```

Linhas da execução 2 (fração 0,3 → 171 casos de teste, 64 malignos), ambas
coerentes:

```
regressao_logistica  matriz={'vn':106,'fp':1,'fn':2,'vp':62}  acc=0.982456 sens=0.968750 esp=0.990654 limiar=0.32 oof=0.972973
svm                  matriz={'vn':105,'fp':2,'fn':1,'vp':63}  acc=0.982456 sens=0.984375 esp=0.981308 limiar=0.30 oof=0.972973
```

### 4.4 `GET /api/v1/models/comparison` — composição por execução

Com execução 3 (80/20, só a regressão logística) e execução 2 (70/30, SVM) como
linhas mais recentes:

```
test_partitions_mixed=True
test_partitions=[{"training_run_id":3,"test_size":0.2,"test_set_size":114,"test_set_malignant":42},
                 {"training_run_id":2,"test_size":0.3,"test_set_size":171,"test_set_malignant":64}]

regressao_logistica  run=3 test_size=0.2 teste=114 malignos=42 path=ml/artifacts/runs/3/regressao_logistica.joblib
svm                  run=2 test_size=0.3 teste=171 malignos=64 path=ml/artifacts/runs/2/svm.joblib
```

```
[PASSOU] test_set_size == vn+fp+fn+vp da propria linha        (os dois modelos)
[PASSOU] test_set_malignant == vp+fn da propria linha         (os dois modelos)
[PASSOU] train_oof_sensitivity e campo separado
[PASSOU] default_point vem da execucao do proprio modelo
[PASSOU] test_partitions_mixed == True com particoes diferentes
[PASSOU] ha dois test_set_size distintos -- [114, 171]
```

Uma verificação do meu primeiro script acusou `test_partitions_mixed == False`
quando eu havia treinado **os dois** modelos na mesma execução 70/30 — premissa
errada do meu teste, não defeito: com as duas linhas mais recentes vindas do
mesmo run, não há mistura e `False` é a resposta correta. Refeito treinando um
modelo só em outra partição (`verificar_mistura.py`), o sinalizador acendeu.

---

## 5. `diagnostico_metricas.py` — PASSOU

```powershell
cd c:\Users\isaiaslm\tcc-cancer-mama
python .agents/diagnostico_metricas.py
```

Saída completa em
`.agents/tasks/correcoes-metricas-documentacao/diagnostico-depois.txt` (estado
após exercitar a API) e em `diagnostico-depois-demo.txt` (estado final de
demonstração). Trecho do `depois`:

```
=== training_runs ===
  run 1: test_size=0.2 grid=0 status=success seed=42
  run 2: test_size=0.3 grid=0 status=success seed=42
  run 3: test_size=0.2 grid=0 status=success seed=42
=== trained_models ===
  id=1 regressao_logistica  run=1  limiar=0.01  esp=0.6806  matriz={'vn':49,'fp':23,'fn':0,'vp':42}
      artifact_path=ml/artifacts/regressao_logistica.joblib
      COERENCIA: ... -> OK
  id=2 svm                  run=1  limiar=0.38  matriz={'vn':71,'fp':1,'fn':2,'vp':40}
      artifact_path=ml/artifacts/svm.joblib                        -> OK
  id=3 regressao_logistica  run=2  limiar=0.32  matriz={'vn':106,'fp':1,'fn':2,'vp':62}
      artifact_path=ml/artifacts/runs/2/regressao_logistica.joblib -> OK
  id=4 svm                  run=2  limiar=0.30  matriz={'vn':105,'fp':2,'fn':1,'vp':63}
      artifact_path=ml/artifacts/runs/2/svm.joblib                 -> OK
  id=5 regressao_logistica  run=3  limiar=0.31  matriz={'vn':71,'fp':1,'fn':1,'vp':41}
      artifact_path=ml/artifacts/runs/3/regressao_logistica.joblib -> OK
```

**Nenhuma linha `DIVERGENTE`.** As três linhas de execução (`id=3,4,5`) apontam
para `ml/artifacts/runs/{id}/`; só as duas linhas de **referência** (`id=1,2`,
run sintético 1) apontam para `ml/artifacts/`, que é a procedência correta delas.

### Comparação com `diagnostico-antes.txt`

| | antes | depois |
|---|---|---|
| Linhas `DIVERGENTE` | **2** (`id=2` e `id=6`) | **0** |
| `artifact_path` de execução apontando para a referência | **todas as 7 linhas** | **nenhuma** |
| Especificidade impossível | `id=6`: limiar 0,01 com `esp=0.9907` | limiar 0,01 → `esp=0.6806`, matriz recalculada (`fp` 1 → 23) |
| Coluna do portão out-of-fold | não existia | `train_oof_sensitivity`, separada de `sensitivity` |
| Linhas por execução | 7 linhas para 9 execuções, registros reaproveitados | uma linha por (execução, modelo) |

O defeito A aparecia em `antes` como `id=2` (`sens=0.9730` numa matriz que dá
0,9762) e `id=6` (`sens=0.9941`, out-of-fold, numa matriz que dá 0,9688, com a
especificidade do limiar antigo). Nenhum dos dois padrões reaparece no `depois`.

`.agents/comparar_artefatos.py` também roda sem divergência: os blocos
`=== COMMITADO (HEAD) ===` e `=== ARVORE DE TRABALHO ===` saem idênticos.

---

## 6. As 4 telas no navegador — PASSOU

Capturadas com Chrome (Puppeteer via `puppeteer-core` 25.4.0, instância e perfil
dedicados, para não tocar no Chrome do usuário) contra o frontend compilado
servido pelo próprio Flask em `http://127.0.0.1:5000`. Script:
`.agents/tasks/correcoes-metricas-documentacao/screenshots.cjs`. As imagens
foram abertas e conferidas visualmente, não só salvas.

Arquivos em `.agents/tasks/correcoes-metricas-documentacao/screenshots/`
(sufixo `-misto` = estado com partições de teste diferentes; sem sufixo = estado
de demonstração com a referência 80/20):

| Tela | Estado misto | Estado de referência |
|---|---|---|
| Seleção de Perfil | `01-selecao-de-perfil-misto.png` | `01-selecao-de-perfil.png` |
| Triagem e Classificação | `02-triagem-e-classificacao-misto.png` | `02-triagem-e-classificacao.png` |
| Histórico | `03-historico-misto.png` | `03-historico.png` |
| Laboratório de Modelos | `04-laboratorio-de-modelos-misto.png` | `04-laboratorio-de-modelos.png` |

### Cabeçalho e linhas não se contradizem mais

O cabeçalho da seção "Comparação dos classificadores" não cita mais nenhum
tamanho de conjunto de teste; sobrou só classe positiva, melhor modelo e
critério. O tamanho e a composição passaram para dentro da tabela, por linha:

```
MODELO | LIMIAR | TESTE (CASOS) | MALIGNOS NO TESTE | ACURÁCIA (TESTE) | SENSIBILIDADE (TESTE)
       | ESPECIFICIDADE (TESTE) | AUC (TESTE) | FALSOS NEGATIVOS (TESTE) | SENSIBILIDADE OOF TREINO (PORTÃO)
Regressão logística ★ | 0.31 | 114 | 42 | 98.25% | 97.62% | 98.61% | 0.9960 | 2.38% | 97.06%
SVM (RBF)             | 0.30 | 171 | 64 | 98.25% | 98.44% | 98.13% | 0.9972 | 1.56% | 97.30%
```

Cada linha traz a composição da sua própria execução (114/42 e 171/64) e os
títulos das matrizes de confusão acompanham: "Regressão logística (limiar 0.31)
— teste da execução #3: 114 casos, 42 malignos" e "SVM (RBF) (limiar 0.30) —
teste da execução #2: 171 casos, 64 malignos". Quando as partições diferem, a
tela avisa:

> **A tabela mistura partições de teste diferentes** — Os modelos abaixo vêm de
> execuções com conjuntos de teste distintos, então comparar as métricas entre
> eles não é válido. Execução #3: fração de teste 20%, 114 casos (42 malignos).
> Execução #2: fração de teste 30%, 171 casos (64 malignos).

No estado de referência (uma só partição) o aviso não aparece e as duas linhas
mostram 114/42, como esperado.

### Está explícito o que é teste e o que é portão out-of-fold

- Toda coluna de métrica tem o sufixo `(TESTE)`.
- A última coluna é "SENSIBILIDADE OOF TREINO (PORTÃO)".
- `caption` da tabela: "Métricas no CONJUNTO DE TESTE da execução de cada
  modelo, no limiar vigente; a última coluna é o portão de promoção, calculado
  em predições out-of-fold do TREINO — não reportar uma pela outra."
- A segunda tabela virou "Limiar padrão (0,50) na mesma partição de cada modelo".
- Na seção do slider: "O portão é sempre a sensibilidade das predições
  out-of-fold do TREINO — o conjunto de teste nunca escolhe limiar, só reporta
  as métricas depois que ele já foi decidido", e por modelo "Sensibilidade no
  limiar vigente (portão out-of-fold do treino): 97.06%".
- Reprodutibilidade: "Este bloco descreve os artefatos de referência (partição
  80/20, semente 42) citados no artigo — não necessariamente a execução dos
  modelos listados acima".

### RNF01 em todas as telas

A barra de aviso aparece no topo das quatro telas, conferida no texto renderizado
e nas imagens:

> ⚠ **Ferramenta de apoio à decisão.** Não substitui o laudo histopatológico nem
> a avaliação médica.

```
[PASSOU] RNF01 visivel na Selecao de Perfil
[PASSOU] RNF01 visivel na Triagem e Classificacao
[PASSOU] RNF01 visivel no Historico
[PASSOU] RNF01 visivel no Laboratorio
```

A tela de Seleção de Perfil mostra o grupo "Perfil" com as opções Médico e
Pesquisador (D3: segregação de telas, sem trava). A Triagem traz as 30 medidas
agrupadas pelas 10 base × média/erro padrão/pior valor, os botões de exemplo da
base e a escolha Anônimo/Identificado. O Histórico mostra 3 avaliações com
filtros (classificação, registro, período, faixa de confiança) e paginação.

---

## 7. Números da Entrega 2 (fonte única)

Extraídos de `c:/Users/isaiaslm/tcc-cancer-mama/ml/artifacts/metrics.json` e
`ml/artifacts/train_config.json`, e conferidos contra o que o `python -m ml.train`
reproduziu nesta rodada e contra o que o banco e a tela exibem. **Citar estes
valores, não outros.**

### Conjunto de dados e partição de referência (80/20)

| | valor |
|---|---|
| Base | WDBC (Wisconsin Diagnostic Breast Cancer), tabular, 30 características |
| Total | 569 casos |
| Treino | **455** casos — 285 benignos, 170 malignos |
| Teste | **114** casos — **72 benignos, 42 malignos** |
| Partição | 20% de teste, estratificada, `random_state = 42` |
| Validação cruzada | 5 folds (`scoring = recall`) |
| Classe positiva | maligno |
| Meta de sensibilidade (RNF04) | **0,97** |
| Melhor modelo | **regressão logística** |
| Critério | maior sensibilidade no ponto de operação; desempate por AUC e depois por especificidade |
| Versões | Python 3.14.6 · scikit-learn 1.9.1 · numpy 2.5.0 · joblib 1.6.0 |
| `commit_git` do artefato | `096bc54787318a90f40840bd51644a43b6dd4bab` |
| SHA-256 do dataset | `11218503215d46bf9eb4e9bcf7da97b878f0cdae46c75863d00e5009ab91a76c` |

### Regressão logística (modelo em produção)

| | limiar padrão 0,50 | **ponto de operação — limiar de segurança 0,31** |
|---|---|---|
| Acurácia | 0,9649 (96,49%) | **0,9825 (98,25%)** |
| Sensibilidade (teste) | 0,9286 (92,86%) | **0,9762 (97,62%)** |
| Especificidade (teste) | 0,9861 (98,61%) | **0,9861 (98,61%)** |
| AUC | 0,9960 | **0,9960** |
| Taxa de falsos negativos | 0,0714 (7,14%) | **0,0238 (2,38%)** |
| Matriz de confusão | vn 71 · fp 1 · fn 3 · vp 39 | **vn 71 · fp 1 · fn 1 · vp 41** |

- Valores sem arredondamento: acurácia `0.9824561403508771`, sensibilidade
  `0.9761904761904762`, especificidade `0.9861111111111112`, AUC
  `0.996031746031746`, FN `0.023809523809523808`.
- Limiar vigente / limiar de segurança: **0,31 / 0,31**.
- Portão out-of-fold do treino no limiar vigente
  (`train_oof_sensitivity`): **0,970588** (33/34) — atinge a meta de 0,97.
- `atende_meta_sensibilidade_teste`: **sim**.
- Validação cruzada (5 folds, média ± desvio): acurácia 0,9736 ± 0,0167 ·
  sensibilidade 0,9529 ± 0,0446 · especificidade 0,9860 ± 0,0192 ·
  AUC 0,9958 ± 0,0052 · FN 0,0471 ± 0,0446.
- Hiperparâmetros: `C=1`, `penalty=l2`, `solver=lbfgs`, `max_iter=1000`,
  `random_state=42`.
- SHA-256 do artefato: `9ec517d16ebf…`.

### SVM (RBF)

| | limiar padrão 0,50 | **ponto de operação — limiar de segurança 0,38** |
|---|---|---|
| Acurácia | 0,9737 (97,37%) | **0,9737 (97,37%)** |
| Sensibilidade (teste) | 0,9286 (92,86%) | **0,9524 (95,24%)** |
| Especificidade (teste) | 1,0000 (100%) | **0,9861 (98,61%)** |
| AUC | 0,9927 | **0,9927** |
| Taxa de falsos negativos | 0,0714 (7,14%) | **0,0476 (4,76%)** |
| Matriz de confusão | vn 72 · fp 0 · fn 3 · vp 39 | **vn 71 · fp 1 · fn 2 · vp 40** |

- Valores sem arredondamento: acurácia `0.9736842105263158`, sensibilidade
  `0.9523809523809523`, especificidade `0.9861111111111112`, AUC
  `0.9927248677248677`, FN `0.047619047619047616`.
- Limiar vigente / limiar de segurança: **0,38 / 0,38**.
- Portão out-of-fold do treino no limiar vigente: **0,970588** (33/34) — atinge a
  meta, por isso o limiar de segurança 0,38 é promovível.
- `atende_meta_sensibilidade_teste`: **não** (0,9524 < 0,97 no conjunto de
  teste). O portão do RNF04 é o out-of-fold do treino, que passa; a tela informa
  "SVM (RBF): NÃO atende a meta no teste", e é esse o número a citar como
  desempenho de teste.
- Validação cruzada (5 folds): acurácia 0,9758 ± 0,0092 · sensibilidade
  0,9588 ± 0,0446 · especificidade 0,9860 ± 0,0147 · AUC 0,9949 ± 0,0056 ·
  FN 0,0412 ± 0,0446.
- Hiperparâmetros: `C=10`, `kernel=rbf`, `gamma=scale`, `probability=True`,
  `random_state=42`.
- SHA-256 do artefato: `8bfca2197929…`.

### Como citar sem repetir o defeito A

- "Sensibilidade de 97,62%" é do **conjunto de teste** da partição 80/20, no
  limiar 0,31.
- "Portão de promoção de 97,06%" é a sensibilidade **out-of-fold do treino** no
  mesmo limiar. É o número que o RNF04 compara com 0,97.
- Os dois são diferentes e não se substituem. A sensibilidade out-of-fold nunca
  entra na coluna/no texto de sensibilidade de teste.

---

## Observações (nenhuma é defeito do sistema)

1. **`sklearn` FutureWarning.** `python -m ml.train` emite 84 avisos
   `FutureWarning: The 'probability' parameter was deprecated in 1.9 and will be
   removed in version 1.11` (SVC com `probability=True`, scikit-learn 1.9.1).
   Não afeta resultado nem exit code, mas vira erro na 1.11 — fica como dívida
   conhecida.
2. **`npm audit`.** `npm install` relata 4 vulnerabilidades (3 moderadas, 1
   alta) nas dependências de desenvolvimento do Vite. O build passa; nenhuma
   delas entra no bundle servido.
3. **`.pyc` rastreados.** `ml/__pycache__/*.cpython-314.pyc` estão commitados
   apesar de `__pycache__/` constar no `.gitignore`, então qualquer execução
   deixa `git status` sujo nesses três arquivos (restaurados com
   `git checkout -- ml/__pycache__` ao fim desta verificação).
   `git status --porcelain ml/artifacts`, que é o que a checklist cobra, segue
   vazio.
4. **Estado final do ambiente.** Servidor derrubado. `instance/tcc_cancer_mama.db`
   e `ml/artifacts/runs/` foram recriados do zero e repovoados com
   `.agents/preparar_demo.py` (usuários `medico@demo.local` e
   `pesquisador@demo.local`, senha `demo12345`; 3 avaliações; bloqueio do RNF04
   exercitado). Ambos são ignorados pelo git. Nenhum arquivo rastreado foi
   modificado.

## Arquivos produzidos nesta verificação

Todos em `.agents/tasks/correcoes-metricas-documentacao/`:

| Arquivo | Conteúdo |
|---|---|
| `relatorio-verificacao.md` | este relatório |
| `diagnostico-depois.txt` | item 5, estado após exercitar a API |
| `diagnostico-depois-demo.txt` | item 5, estado final de demonstração |
| `runtime-api.txt` | saída integral do item 4 |
| `runtime-mistura.txt` | saída do complemento do item 4.4 |
| `screenshots/` | 8 PNG (4 telas × 2 estados) |
| `screenshots-log.txt` | conferências de texto renderizado do item 6 (passagem no estado de referência; a passagem no estado misto está transcrita na seção 6 acima) |

Nada foi commitado: este passo é só verificação, e os scripts de apoio em
`.agents/` seguem não rastreados, como o plano da rodada determinou.
| `verificar_runtime.py`, `verificar_mistura.py`, `ler_portao.py`, `screenshots.cjs` | scripts da verificação |
