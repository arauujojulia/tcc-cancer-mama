"""
Complemento do item 4: `test_partitions_mixed` exige que as linhas mais recentes
venham de particoes diferentes. O script anterior treinou OS DOIS modelos na
mesma execucao 70/30, entao nao havia mistura (False correto). Aqui treina-se
UM modelo so, em outra particao, para a mistura aparecer.
"""
import http.cookiejar
import json
import sys
import urllib.error
import urllib.request

BASE = "http://127.0.0.1:5000/api/v1"
jar = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
falhas = []


def chamar(metodo, caminho, corpo=None):
    dados = None if corpo is None else json.dumps(corpo).encode("utf-8")
    req = urllib.request.Request(BASE + caminho, data=dados, method=metodo)
    if dados is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with opener.open(req, timeout=300) as r:
            bruto = r.read().decode("utf-8")
            return r.status, (json.loads(bruto) if bruto else None)
    except urllib.error.HTTPError as e:
        bruto = e.read().decode("utf-8")
        return e.code, (json.loads(bruto) if bruto else None)


def checar(rotulo, condicao, detalhe=""):
    if not condicao:
        falhas.append(rotulo)
    print(f"  [{'PASSOU' if condicao else 'FALHOU'}] {rotulo}" + (f" -- {detalhe}" if detalhe else ""))


chamar("POST", "/auth/login", {"email": "verificador@demo.local", "password": "demo12345"})

st, c = chamar("POST", "/training-runs", {
    "models": ["regressao_logistica"], "test_size": 0.2, "grid_search": False,
})
print(f"  POST /training-runs (so regressao_logistica, 80/20) -> HTTP {st} {json.dumps(c)}")
run_id = c["training_run_id"]

st, comp = chamar("GET", "/models/comparison")
print(f"  test_partitions_mixed={comp['test_partitions_mixed']}")
print(f"  test_partitions={json.dumps(comp['test_partitions'])}")
for m in comp["models"]:
    print(f"  {m['name']:22s} run={m['training_run_id']} test_size={m['test_size']} "
          f"teste={m['test_set_size']} malignos={m['test_set_malignant']} "
          f"path={m['artifact_path']}")
    checar(f"{m['name']}: default_point vem da execucao do proprio modelo",
           m["default_point"] is None or m["default_point"]["threshold"] == 0.5,
           json.dumps(m["default_point"]))

checar("test_partitions_mixed == True com particoes diferentes",
       comp["test_partitions_mixed"] is True, str(comp["test_partitions_mixed"]))
checar("ha dois test_set_size distintos",
       len({m["test_set_size"] for m in comp["models"]}) == 2,
       str(sorted({m["test_set_size"] for m in comp["models"]})))

print(f"\n  falhas: {len(falhas)}")
for f in falhas:
    print(f"    - {f}")
sys.exit(1 if falhas else 0)
