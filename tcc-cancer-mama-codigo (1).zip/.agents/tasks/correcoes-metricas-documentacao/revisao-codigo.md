# Revisão de código — correções dos três defeitos de métricas

Repositório `c:/Users/isaiaslm/tcc-cancer-mama`, branch
`feat/mvp-alinhado-documentacao`. Base da rodada `1b450f3`, HEAD `ff7479e`.
Seis commits revisados:

```
ff7479e docs(tasks): registra o hash do commit de documentacao no plano
d7e95f5 docs: registra os tres defeitos de metricas e a nova semantica
68bf1ef fix(frontend): rotula teste x portao out-of-fold no Laboratorio de Modelos
d4ad3b3 test: cobre a invariante das metricas e a composicao do teste por execucao
8f538cb fix(api): recalcula as metricas de teste no limiar vigente (defeitos A, B e C)
3265dd7 fix(db): separa o portao out-of-fold das metricas de teste em trained_models
a92e6ba feat(ml): persiste as probabilidades do conjunto de teste por execucao
```

Diff: 17 arquivos, +2894/−170. Código de produção tocado: `db/models.py`,
`ml/train.py`, `services/modelos.py`, `api/routes.py`,
`frontend/src/pages/ModelosPage.jsx`. Testes novos:
`tests/test_metricas_coerentes.py`, `tests/test_modelos_comparacao.py`, mais
uma classe nova em `tests/test_training.py`. Artefatos novos versionados:
`ml/artifacts/regressao_logistica_test_proba.json` e `.../svm_test_proba.json`.

**Veredito: APPROVED.** Nenhum achado bloqueante. As evidências de verificação
exigidas estão registradas em
`.agents/tasks/correcoes-metricas-documentacao/relatorio-verificacao.md` (suíte
107 testes OK, `ml.train`/`ml.report` OK, `npm run build` OK, requisições reais
contra `python app.py`, `diagnostico_metricas.py` sem `DIVERGENTE`) e não foram
reexecutadas aqui, conforme o escopo do passo. Foram feitas duas leituras
pontuais e estreitas, justificadas adiante (seção "Checagens pontuais").

---

## 1. Defeito A — portão out-of-fold separado das métricas de teste

### 1.1 Campo próprio e explicitamente nomeado

`db/models.py:216` acrescenta
`train_oof_sensitivity = db.Column(db.Float, nullable=True)`, com comentário de
coluna e bloco D11 na docstring da classe declarando que o campo é o portão do
RNF04 (out-of-fold do **treino**, avaliado no `threshold` da própria linha) e
que **não** é métrica reportada. `to_dict()` (`db/models.py:249`) expõe o campo
logo após `false_negative_rate`, então `GET /models` e
`GET /training-runs/{id}` o carregam sem mudança adicional.

O nome carrega as duas informações que evitavam a confusão (`train` +
`oof`), como o plano pedia em D-A1. Nenhum outro campo ficou ambíguo.

### 1.2 A coluna `sensitivity` nunca mais recebe o valor out-of-fold

Varri todos os pontos de escrita de `sensitivity` no código de produção
(`services/modelos.py:272`, `:371`, `:497`):

- `sincronizar_modelos` e `concluir_training_run_sucesso` gravam
  `sensitivity=op["sensibilidade"]`, onde `op = r["teste_operacao"]` — conjunto
  de teste avaliado no `limiar_seguranca`, que é exatamente o `threshold`
  inicial da linha. Coerente por construção.
- `promover_modelo` (`services/modelos.py:477-501`) tem assinatura nova
  `(registro, threshold, sensibilidade_oof_valor, metricas_teste)` e grava
  `train_oof_sensitivity = sensibilidade_oof_valor` e
  `sensitivity = metricas_teste["sensibilidade"]`. O caminho antigo
  (`registro.sensitivity = sensibilidade`) desapareceu do diff.

O único chamador de `promover_modelo` é `api/routes.py:534`, que passa
`sensibilidade` (do OOF) na posição do portão e `metricas` (do teste) na
posição das métricas. Não há segundo chamador.

### 1.3 O portão do RNF04 continua decidindo pelo out-of-fold do treino

`api/routes.py:494-520` ficou intacto no essencial: o portão continua vindo de
`svc_modelos.sensibilidade_oof(registro.name, threshold, artifacts_dir=diretorio)`,
com 503 `MODEL_UNAVAILABLE` quando falta o `{modelo}_oof.json` e 400
`SENSITIVITY_BELOW_TARGET` com `obtained`/`required` quando o valor fica abaixo
de `SENSIBILIDADE_MINIMA`. O limiar **não** é validado pelo conjunto de teste em
nenhum ponto novo: `metricas_teste_no_limiar` é chamada **depois** da checagem
do portão e só para reportar.

Confirmei a ordem no código: a comparação com a meta (`api/routes.py:510-520`)
precede o `try` que obtém as métricas de teste (`:518-533`), que por sua vez
precede `promover_modelo`. O 400 retorna antes de qualquer escrita, e o 503 de
`TesteProbaIndisponivel` também — não existe caminho que grave o `threshold`
novo e deixe as métricas antigas. Isso é justamente o defeito corrigido, e o
teste `test_test_proba_ausente_devolve_503_sem_alterar_a_linha` compara
`to_dict()` antes/depois para provar que a linha fica idêntica.

### 1.4 Métricas reportadas são todas de teste e recalculadas em conjunto

`services/modelos.py:490-503` escreve `accuracy`, `sensitivity`, `specificity`,
`auc`, `false_negative_rate` e `confusion_matrix` **no mesmo bloco**, todos de
`metricas_teste`, que é o retorno de
`metricas_teste_no_limiar` → `ml.train.compute_metrics(y_true, proba >= threshold, proba)`.
Há uma única implementação da matriz e das razões no projeto, o que faz a
invariante valer por construção em vez de por disciplina.

O insumo é `{modelo}_test_proba.json`, gravado por
`ml.train.train_and_evaluate` (`ml/train.py:332-336`) imediatamente após
`proba = modelo.predict_proba(X_test_scaled)[:, 1]` — portanto exatamente o
vetor usado para `teste_padrao` e `teste_operacao`, sem risco de divergência. A
regeneração determinística para artefatos antigos
(`regenerar_test_proba_ausentes`, `services/modelos.py:176-225`) espelha
`regenerar_oof_ausentes`: usa `split.json["teste"]`, `scaler.joblib` e
`{modelo}.joblib`, e degrada sem gravar quando falta qualquer um dos três — o
mesmo contrato já fechado para o OOF. Ela é chamada em `sincronizar_modelos`
logo após `regenerar_oof_ausentes` (`services/modelos.py:240-241`).

### 1.5 `auc` não muda com o limiar

`compute_metrics` calcula a AUC sobre `proba`, não sobre a predição binária, e
`promover_modelo` reescreve `auc` com esse mesmo valor (documentado na
docstring). `test_auc_nao_muda_com_o_limiar` fecha isso com `places=9`, e o
runtime registrado mostra `auc = 0.996031746031746` antes e depois do `PUT` em
0,01.

### 1.6 A invariante tem teste automatizado

`tests/test_metricas_coerentes.py` traz `assert_linha_coerente(modelo)`, que
para **cada** linha confere contra a própria `confusion_matrix`, com
`places=6`:

```
sensitivity          == vp / (vp + fn)
false_negative_rate  == fn / (vp + fn)
specificity          == vn / (vn + fp)
accuracy             == (vn + vp) / (vn + fp + fn + vp)
sensitivity + false_negative_rate == 1
```

`assert_tabela_coerente()` itera `TrainedModel.query.all()` — a varredura é da
tabela inteira, não só da linha alterada, que era o requisito ("para qualquer
linha de `trained_models`"). Os cenários cobertos são os cinco pedidos no plano:
referência sincronizada, `POST /training-runs` com `test_size` 0,2 e 0,3,
`PUT /threshold` em 0,01/0,20/0,45 (aceitando 200 **ou** 400 e exigindo
coerência nos dois casos), a regressão direta do caso id=6 (especificidade tem
de cair e `fp` tem de aumentar com limiar 0,01) e a independência da AUC. A
tolerância de arredondamento pedida está presente (`places=6`, e `delta=1e-9`
na comparação com `metrics.json`).

Um detalhe que considerei e aceito: `test_sensibilidade_de_teste_nao_e_o_portao_quando_os_dois_diferem`
só exige `sensitivity != train_oof_sensitivity` quando os dois valores de fato
diferem (`if abs(portao - teste) > 1e-9`). Isso é correto — exigir diferença
incondicional seria asserção falsa quando os dois coincidem legitimamente — e a
asserção forte (`sensitivity == recálculo no teste`,
`train_oof_sensitivity == portão`) é feita sem condição.

---

## 2. Defeito B — um registro por execução

### 2.1 Sempre registro novo, sempre o artefato da própria execução

`concluir_training_run_sucesso` (`services/modelos.py:366-389`) perdeu por
completo a busca por `artifact_sha256` e o bloco
`if novo or not os.path.exists(...)` que preservava o `artifact_path` antigo.
Agora constrói `TrainedModel(...)` novo com
`artifact_path=_caminho_artefato(artifacts_dir, nome)`, onde `artifacts_dir` vem
do `output_dir` do próprio treino. Era esse ramo que fazia modelos nascidos de
execuções 70/30 apontarem para `ml/artifacts/`.

`sincronizar_modelos` trocou o critério "falta o hash" por "falta a linha desta
referência": `_registro_desta_referencia(nome)` filtra por `artifact_path`
**e** `artifact_sha256` (`services/modelos.py:247-252`), e o `else` do laço usa
a mesma função em vez do hash. Verifiquei `caminho_relativo`
(`services/modelos.py:65-73`): normaliza para barras normais com
`.replace(os.sep, "/")`, então o filtro por `artifact_path` casa com o que está
gravado no banco também no Windows — se não normalizasse, cada subida criaria
linhas novas. O estado final do banco de demonstração confirma: duas linhas,
`ml/artifacts/regressao_logistica.joblib` e `ml/artifacts/svm.joblib`.

Checei também o cenário de violação acidental da nova unicidade: se
`ml/artifacts/` for regenerado e o hash mudar, `pendentes` fica não vazio e
`_run_sintetico` cria um `TrainingRun` **novo** (`services/modelos.py:109-128`
sempre instancia), então as linhas novas entram com outro `training_run_id` e
`uq_trained_models_run_name` não é violada. Quando `pendentes` está vazio,
nenhum run é criado — idempotência preservada, e é o que
`test_sincronizar_duas_vezes_nao_duplica_linhas_nem_run_sintetico` prova.

### 2.2 Unicidade compatível com PostgreSQL e SQLite

`db/models.py:233-237` declara

```python
__table_args__ = (
    db.UniqueConstraint("training_run_id", "name", name="uq_trained_models_run_name"),
)
```

e `artifact_sha256` passou a `db.Column(db.String(64), nullable=False, index=True)`,
sem `unique`. Restrição de tabela em `__table_args__` é emitida igual por
`create_all()` nos dois dialetos — não há tipo nem sintaxe específica envolvida,
coerente com design §2.1. A unicidade é exercitada de verdade por
`test_duas_linhas_com_a_mesma_execucao_e_nome_violam_a_unicidade`, que espera
`IntegrityError` no commit e faz `rollback()` ao fim.

Nenhuma suposição de identidade-por-hash sobreviveu no código de produção:
grep por `artifact_sha256` em `.py` só devolve a declaração da coluna, o
`to_dict()`, o filtro combinado da sincronização, as duas atribuições na criação
de linha, o `print` do `__main__` e usos em testes/scripts de diagnóstico.

### 2.3 Migração/recriação incluída e documentada

Não há Alembic no projeto e a política fechada no design §2 é recriação de
schema. A recriação está documentada em três lugares, com os dois bancos:
`README.md` (bloco "Recriação obrigatória para D11/D12" na seção 2 e o item D12
em "Outras decisões técnicas"), `.agents/ESPECIFICACAO-CONSOLIDADA.md` seção 4
("Recriação de schema") e `.agents/RELATORIO-IMPLEMENTACAO.md` §2.6 (defeito B,
"Migração"). Em todos: SQLite → apagar `instance/tcc_cancer_mama.db`;
PostgreSQL → `DROP SCHEMA public CASCADE; CREATE SCHEMA public;` e subir a
aplicação, que faz `create_all()` + `sincronizar_modelos()`. O relatório de
verificação registra que o banco foi de fato recriado do zero e repovoado.

Também confirmei que a frase antiga "o registro existente é reaproveitado e
mantém o caminho estável de `ml/artifacts/`" foi **removida** da especificação
(seção 4) e que a nota de §2.5 do relatório de implementação marca aquela
correção parcial como encerrada, apontando para §2.6. Não sobrou documentação
contradizendo o código.

---

## 3. Defeito C — composição do teste vem dos dados, por execução

`_composicao_do_teste` (`api/routes.py:249-262`) deriva
`test_set_size = vn+fp+fn+vp` e `test_set_malignant = vp+fn` da própria
`confusion_matrix` da linha, devolvendo `(None, None)` para matriz ausente ou
malformada — sem coluna nova, como D-C previa, e sem risco de exibir número de
outra partição. `test_size` vem de `registro.training_run.test_size`, com guarda
para `run is None`.

O laço de `comparar_modelos` passou a ser dirigido pelo banco, por
`_linhas_mais_recentes_por_modelo()` (`api/routes.py:282-293`), que ordena por
`trained_at desc, id desc` e guarda a primeira ocorrência de cada nome — a
escolha arbitrária do "último do dict" saiu. `default_point`,
`cross_validation` e `safety_threshold_reached_target` vêm de
`_metrics_da_execucao`, que usa `diretorio_artefatos_da_execucao` (a variante
que **não** degrada para a referência) e devolve `None` quando a execução já não
existe em disco; `roc_points` mantém o fallback `registro.roc_points or r.get("roc")`.
A mistura fica visível no topo da resposta via `test_partitions_mixed`
(mais de um `training_run_id` ou mais de um `test_set_size`) e `test_partitions`.

`meets_sensitivity_target` agora é calculado de `registro.sensitivity` (teste) e
`gate_meets_sensitivity_target` de `train_oof_sensitivity`, com guarda para
`None`. Os dois ficam em campos distintos e nomeados.

`tests/test_modelos_comparacao.py` cobre o conjunto: composição conferida contra
a matriz de cada linha, `test_partitions_mixed` falso com só a referência e
verdadeiro após um treino 70/30 de **um** modelo (171/64 numa linha, 114/42 na
outra), `default_point` com 171 casos vindo da execução certa, execução
descartada devolvendo `default_point`/`cross_validation` nulos sem quebrar a
rota, item sem matriz com `test_set_size is None`, e um item por nome.

---

## 4. Interface do Laboratório

`frontend/src/pages/ModelosPage.jsx`:

- o cabeçalho da seção perdeu `r.n_teste`/`r.distribuicao_teste` (que descrevem
  a referência) e ficou só com classe positiva, melhor modelo e critério;
- as colunas de métrica foram renomeadas com o sufixo `(teste)`;
- a tabela do ponto de operação ganhou "Teste (casos)", "Malignos no teste" e
  "Sensibilidade OOF treino (portão)", com `caption` dizendo explicitamente que
  as métricas são do conjunto de teste da execução de cada modelo no limiar
  vigente e que a última coluna é o portão out-of-fold do treino, "não reportar
  uma pela outra";
- o `Alert tone="warning"` de partições misturadas aparece sob
  `comparacao.test_partitions_mixed`, listando `test_partitions`;
- a segunda tabela virou "Limiar padrão (0,50) na mesma partição de cada
  modelo" e só é renderizada quando há itens com `default_point != null`
  (`comLimiarPadrao`), com guarda no `length > 0`;
- a seção do slider mostra `train_oof_sensitivity` por modelo com a legenda
  "portão out-of-fold do treino", e `aplicarLimiar` passou a ler
  `resposta.train_oof_sensitivity` e `resposta.test_metrics?.sensitivity`,
  compatível com o corpo novo da rota; o `Alert` de sucesso distingue o portão
  (que autorizou a promoção) da sensibilidade de teste recalculada;
- "Reprodutibilidade" ganhou o parágrafo dizendo que o bloco descreve os
  artefatos de referência 80/20, não necessariamente a execução das linhas
  acima;
- o texto "atende / NÃO atende a meta no teste" continua, agora alimentado por
  `meets_sensitivity_target` (teste) — rótulo e fonte do dado batem.

O `RocChart` trocou `m.default_point.auc` por `m.operating_point.auc`, mudança
necessária porque `default_point` agora pode ser `null`; a AUC é a mesma nos
dois pontos (independe do limiar) e há comentário explicando. O build do
frontend está registrado como verde no relatório de verificação.

O aviso do RNF01 não foi tocado: o diff do frontend se limita a
`ModelosPage.jsx`, e o relatório de verificação registra a barra visível nas
quatro telas, conferida no texto renderizado e nas capturas.

---

## 5. Decisões fechadas, limites de escopo e higiene

- `design.md`: o diff acrescenta **somente** notas datadas em §2.3, §5.3, §5.4 e
  §6, todas declarando explicitamente que a decisão anterior fica como está. A
  seção 11 não aparece no diff — não foi reaberta.
- `ESPECIFICACAO-CONSOLIDADA.md`: alterações restritas às seções 4, 5, 6 e à
  linha do RNF04 na tabela da seção 8. Nenhuma das decisões D1–D7 aparece no
  diff; a linha de RNF05 continua apontando para D2 sem alteração.
- Nenhum push e nenhum PR: a branch `feat/mvp-alinhado-documentacao` não tem
  upstream e `origin/feat/mvp-alinhado-documentacao` não existe (`git log` nessa
  ref falha com "unknown revision"). Só `main` tem `[origin/main]`.
- `.agents/preparar_demo.py`, `.agents/comparar_artefatos.py` e
  `.agents/diagnostico_metricas.py` seguem **não rastreados**
  (`git ls-files` nos três não devolve nada) e aparecem como `??` no
  `git status`. Não foram commitados nem modificados pelo diff.
- `git status --porcelain ml/artifacts` está **vazio**: os dois
  `*_test_proba.json` entraram commitados e `metrics.json`/`train_config.json`
  não aparecem no diff da rodada (o `--stat` lista apenas os dois arquivos novos
  em `ml/artifacts/`). A referência versionada do artigo continua byte a byte a
  mesma.
- Sujeira remanescente: `ml/__pycache__/*.cpython-314.pyc` aparece como `M` no
  `git status`. São arquivos rastreados desde antes desta rodada (problema
  pré-existente, registrado como observação 3 do relatório de verificação) e não
  fazem parte do diff — fora do escopo.

---

## 6. Números escritos nos arquivos do repositório

Conferi contra as fontes, não contra o texto:

| Afirmação | Fonte | Resultado |
|---|---|---|
| RL: limiar 0,31 · acc 0,9825 · sens 0,9762 · esp 0,9861 · AUC 0,9960 · FN 0,0238 · matriz `{71,1,1,41}` | `ml/artifacts/metrics.json` | bate |
| RL limiar padrão 0,50: 0,9649 / 0,9286 / 0,9861 / 0,0714 · matriz `{71,1,3,39}` | `metrics.json` | bate |
| SVM: limiar 0,38 · acc 0,9737 · sens 0,9524 · esp 0,9861 · AUC 0,9927 · FN 0,0476 · matriz `{71,1,2,40}` | `metrics.json` | bate |
| SVM limiar padrão 0,50: esp 1,0000 · matriz `{72,0,3,39}` | `metrics.json` | bate |
| 114 casos de teste, 42 malignos (72 benignos) | `train_config.json` (`n_teste`, `distribuicao_teste`) | bate |
| `commit_git` do artefato `096bc547…` | `train_config.json` | bate |
| Estado do banco de demonstração: id=1 RL run=1 limiar 0,31 matriz `{71,1,1,41}`; id=2 SVM limiar 0,38 matriz `{71,1,2,40}`; `artifact_path` em `ml/artifacts/` | `diagnostico-depois-demo.txt` | bate |
| Exemplo do 200 do `PUT` na especificação (limiar 0,01: acc 0,7982 · sens 1,0 · esp 0,6806 · FN 0,0 · matriz `{49,23,0,42}` · `train_oof_sensitivity` 0,9941) | `runtime-api.txt` + recálculo do OOF | bate |
| Portão out-of-fold no limiar vigente: 0,970588 para os dois modelos | recálculo de `{modelo}_oof.json` | bate (165/170) |
| Bloqueios do RNF04 citados: `obtained` 0,7412 (RL @0,99), 0,8176 (RL @0,95), 0,7353 (SVM @0,95) | recálculo de `{modelo}_oof.json` | bate |
| Contagem de testes 107 (= 86 + 9 + 8 + 4) | arquivos de teste no diff | bate (9 em `test_metricas_coerentes`, 8 em `test_modelos_comparacao`, 4 na classe nova de `test_training`) |
| `{modelo}_test_proba.json` da referência com 114 pares e 42 malignos | os próprios arquivos | bate |

Não encontrei nenhum número no repositório que não saia de `metrics.json`,
`train_config.json`, do banco ou dos artefatos OOF/test_proba.

### Checagens pontuais feitas nesta revisão

Duas, as duas de leitura:

1. Recálculo da sensibilidade out-of-fold a partir de
   `ml/artifacts/{modelo}_oof.json` nos limiares citados na documentação.
   Justificativa: 0,970588 aparecendo idêntico para os dois modelos e os valores
   de `obtained` (0,7412 / 0,8176 / 0,7353) são os números centrais do RNF04 e
   não constam de nenhum artefato — precisava confirmar que não eram
   aproximações escritas à mão. Confirmados exatamente.
2. Leitura de `metrics.json`, `train_config.json`, dos dois
   `*_test_proba.json` e de `diagnostico-depois-demo.txt` para a tabela acima.

Não reexecutei suíte, build nem treino.

---

## 7. Observações não bloqueantes

Registradas por transparência; nenhuma autoriza mudança de comportamento
aprovado e nenhuma entra em `findings`.

1. **Degradação de `diretorio_artefatos_do_registro` no `PUT`.** Se o diretório
   `ml/artifacts/runs/{id}/` de uma execução for apagado à mão enquanto a linha
   sobrevive no banco, `ajustar_threshold` cai em `ARTIFACTS_DIR` e passaria a
   recalcular as métricas de teste sobre a partição 80/20 da referência,
   gravando-as numa linha cujo `training_run.test_size` diz 0,3. A linha
   continuaria internamente coerente (a invariante vale), a mistura ficaria
   parcialmente visível na tela (`test_set_size` 114 ao lado de `test_size` 0,3,
   com `default_point`/`cross_validation` nulos), e o contrato de degradação é
   exatamente o que o plano aprovou no item 7 e o design já fixara para o OOF.
   Fica como risco residual conhecido, não como defeito desta rodada.
2. **Datas das notas do `design.md`.** As notas estão datadas de 22/10/2026
   enquanto o relatório de verificação é de 26/10/2026. Cosmético.
3. **`train_oof_sensitivity` na resposta do `PUT`** é arredondado para 4 casas,
   enquanto o banco guarda o valor cheio. Consistente com o `obtained` do 400 e
   coberto pelo teste com `places=4`; só vale saber que o campo da resposta não
   é o valor exato da coluna.
