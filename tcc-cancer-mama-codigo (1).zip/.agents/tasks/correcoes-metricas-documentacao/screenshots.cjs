/**
 * Item 6 da checklist: abre as 4 telas no Chrome e salva screenshot de cada.
 * Usa puppeteer-core (ja instalado em c:\Users\isaiaslm\sam-dashboard) com uma
 * instancia de Chrome dedicada e perfil descartavel, para nao tocar no Chrome
 * do usuario. Nao altera codigo de producao.
 *
 * node .agents/tasks/correcoes-metricas-documentacao/screenshots.cjs [sufixo]
 */
const puppeteer = require("c:/Users/isaiaslm/sam-dashboard/node_modules/puppeteer-core");
const fs = require("fs");
const path = require("path");

const BASE = "http://127.0.0.1:5000";
const SAIDA = path.join(__dirname, "screenshots");
const SUFIXO = process.argv[2] ? `-${process.argv[2]}` : "";
const CHROME = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";

const MEDICO = { name: "Medico Demo", email: "medico@demo.local", password: "demo12345", profile: "medico" };
const PESQ = { name: "Pesquisador Demo", email: "pesquisador@demo.local", password: "demo12345", profile: "pesquisador" };

fs.mkdirSync(SAIDA, { recursive: true });
const achados = [];

function log(m) { console.log(m); achados.push(m); }

async function api(page, metodo, caminho, corpo) {
  return page.evaluate(async (metodo, caminho, corpo) => {
    const r = await fetch(caminho, {
      method: metodo,
      credentials: "include",
      headers: corpo ? { "Content-Type": "application/json" } : {},
      body: corpo ? JSON.stringify(corpo) : undefined,
    });
    let dados = null;
    try { dados = await r.json(); } catch (e) { dados = null; }
    return { status: r.status, dados };
  }, metodo, caminho, corpo);
}

async function entrar(page, usuario) {
  await page.goto(BASE + "/login", { waitUntil: "networkidle2" });
  await api(page, "POST", "/api/v1/auth/register", usuario);
  const r = await api(page, "POST", "/api/v1/auth/login", { email: usuario.email, password: usuario.password });
  if (r.status !== 200) throw new Error(`login de ${usuario.email} falhou: HTTP ${r.status}`);
}

async function capturar(page, url, arquivo, esperar) {
  await page.goto(BASE + url, { waitUntil: "networkidle2" });
  if (esperar) {
    try { await page.waitForFunction(esperar, { timeout: 30000 }); }
    catch (e) { log(`  AVISO: espera nao satisfeita em ${url}: ${e.message}`); }
  }
  await new Promise((r) => setTimeout(r, 2500));
  const destino = path.join(SAIDA, arquivo);
  await page.screenshot({ path: destino, fullPage: true });
  const texto = await page.evaluate(() => document.body.innerText);
  log(`  salvo ${arquivo} (${fs.statSync(destino).size} bytes, ${texto.length} chars de texto)`);
  return texto;
}

function contem(texto, agulha, rotulo) {
  const ok = texto.toLowerCase().includes(agulha.toLowerCase());
  log(`  [${ok ? "PASSOU" : "FALHOU"}] ${rotulo}` + (ok ? "" : ` -- nao achei "${agulha}"`));
  return ok;
}

(async () => {
  const browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: "new",
    args: ["--no-sandbox", "--disable-dev-shm-usage", "--window-size=1440,1200"],
    userDataDir: path.join(require("os").tmpdir(), "chrome-tcc-screenshots" + SUFIXO),
  });
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1440, height: 1200, deviceScaleFactor: 1 });

    // --- 1. Selecao de Perfil (cadastro: escolha medico/pesquisador) -------
    log("=== 1. Selecao de Perfil ===");
    await page.goto(BASE + "/login", { waitUntil: "networkidle2" });
    await api(page, "POST", "/api/v1/auth/logout");
    await page.goto(BASE + "/login", { waitUntil: "networkidle2" });
    await page.waitForSelector('[role="tab"]', { timeout: 30000 });
    // aba "Cadastrar": e onde o perfil e escolhido (D3 - segregacao de telas)
    await page.evaluate(() => {
      const abas = [...document.querySelectorAll('[role="tab"]')];
      const cadastrar = abas.find((b) => b.textContent.trim() === "Cadastrar");
      if (cadastrar) cadastrar.click();
    });
    await new Promise((r) => setTimeout(r, 1200));
    let destino = path.join(SAIDA, `01-selecao-de-perfil${SUFIXO}.png`);
    await page.screenshot({ path: destino, fullPage: true });
    let txt = await page.evaluate(() => document.body.innerText);
    log(`  salvo 01-selecao-de-perfil${SUFIXO}.png (${fs.statSync(destino).size} bytes)`);
    contem(txt, "Perfil", "tela de perfil pede o perfil");
    contem(txt, "Médico", "opcao Medico presente");
    contem(txt, "Pesquisador", "opcao Pesquisador presente");
    contem(txt, "Não substitui o laudo histopatológico", "RNF01 visivel na Selecao de Perfil");

    // --- 2. Triagem e Classificacao (perfil medico) ------------------------
    log("\n=== 2. Triagem e Classificacao ===");
    await entrar(page, MEDICO);
    txt = await capturar(page, "/classificar", `02-triagem-e-classificacao${SUFIXO}.png`,
      () => document.querySelectorAll("input,select").length > 5);
    contem(txt, "Não substitui o laudo histopatológico", "RNF01 visivel na Triagem e Classificacao");

    // --- 3. Historico ------------------------------------------------------
    log("\n=== 3. Historico ===");
    txt = await capturar(page, "/historico", `03-historico${SUFIXO}.png`,
      () => document.body.innerText.length > 300);
    contem(txt, "Não substitui o laudo histopatológico", "RNF01 visivel no Historico");

    // --- 4. Laboratorio de Modelos (perfil pesquisador) -------------------
    log("\n=== 4. Laboratorio de Modelos ===");
    await api(page, "POST", "/api/v1/auth/logout");
    await entrar(page, PESQ);
    txt = await capturar(page, "/laboratorio", `04-laboratorio-de-modelos${SUFIXO}.png`,
      () => document.body.innerText.includes("Sensibilidade"));
    contem(txt, "Não substitui o laudo histopatológico", "RNF01 visivel no Laboratorio");
    contem(txt, "Sensibilidade (teste)", "coluna rotulada como TESTE");
    contem(txt, "Teste (casos)", "coluna com o tamanho do teste por execucao");
    contem(txt, "Malignos no teste", "coluna com a composicao do teste por execucao");
    contem(txt, "out-of-fold", "portao out-of-fold do treino explicito");
    contem(txt, "Acurácia (teste)", "acuracia rotulada como teste");
    contem(txt, "AUC (teste)", "AUC rotulada como teste");
    contem(txt, "referência", "bloco de reprodutibilidade identificado como a referencia");

    // cabecalho nao pode mais citar um conjunto de teste fixo
    const cabecalho = await page.evaluate(() => {
      const h = [...document.querySelectorAll("h2,h3")]
        .find((e) => e.textContent.includes("Compara"));
      if (!h) return null;
      const sec = h.closest("section") || h.parentElement;
      return sec ? sec.innerText.slice(0, 700) : h.innerText;
    });
    log("  --- cabecalho da secao de comparacao ---");
    log(String(cabecalho).split("\n").slice(0, 12).map((l) => "    " + l).join("\n"));

    // tabela do ponto de operacao, linha por linha
    const tabela = await page.evaluate(() => {
      const tabs = [...document.querySelectorAll("table")];
      return tabs.map((t) => ({
        caption: t.caption ? t.caption.innerText : null,
        linhas: [...t.querySelectorAll("tr")].map((tr) =>
          [...tr.querySelectorAll("th,td")].map((c) => c.innerText.trim()).join(" | ")),
      }));
    });
    log("  --- tabelas renderizadas ---");
    for (const t of tabela) {
      if (t.caption) log(`    caption: ${t.caption.replace(/\n/g, " ")}`);
      for (const l of t.linhas.slice(0, 8)) log(`      ${l}`);
      log("");
    }

    // avisos (Alert) presentes na tela
    const avisos = await page.evaluate(() =>
      [...document.querySelectorAll("div[class*='alert'], aside[class*='alert'], section[class*='alert']")]
        .map((e) => (e.innerText || "").replace(/\s+/g, " ").trim().slice(0, 300))
        .filter((t) => t.length > 0));
    log("  --- avisos na tela ---");
    for (const a of avisos) log(`    ${a}`);
  } finally {
    await browser.close();
  }
  fs.writeFileSync(path.join(__dirname, `screenshots-log${SUFIXO}.txt`), achados.join("\n"), "utf8");
})().catch((e) => { console.error("ERRO:", e); process.exit(1); });
