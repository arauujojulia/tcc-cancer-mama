"""Item 7: imprime o portao out-of-fold gravado em cada linha de trained_models."""
import os
import sqlite3

con = sqlite3.connect(os.path.join("instance", "tcc_cancer_mama.db"))
con.row_factory = sqlite3.Row
for r in con.execute(
    "SELECT id, name, threshold, safety_threshold, sensitivity, train_oof_sensitivity,"
    " is_production, artifact_sha256 FROM trained_models ORDER BY id"
):
    oof = r["train_oof_sensitivity"]
    print(
        f"id={r['id']} {r['name']:22s} limiar={r['threshold']} "
        f"limiar_seguranca={r['safety_threshold']} "
        f"sens_teste={r['sensitivity']:.6f} "
        f"train_oof_sensitivity={'None' if oof is None else f'{oof:.6f}'} "
        f"producao={bool(r['is_production'])} sha256={r['artifact_sha256'][:12]}"
    )
con.close()
