# Diretriz obrigatória para a próxima iteração de `docs/COMO-FUNCIONA.md`

Escrita pelo orquestrador depois de o loop de documentação pausar no limite de
iterações. **Leia isto antes de `revisao-documentacao.json`.** Ela tem precedência
sobre qualquer instrução anterior da etapa.

## 1. Integridade de citação — regra absoluta

A iteração anterior tentou resolver o achado "porcentagens sem fonte" **inventando
contagens brutas** (`1.601 de 6.028`, `992/1.601`, `345/1.601`, `18/98`, `17/18`),
afirmando a subseção exata de cada artigo e declarando que os valores foram
"reconferidos no texto dos próprios artigos". Nada disso existe em qualquer fonte do
projeto, e a revisão mostrou que `26,6%` não reconcilia com o texto de Duijm et al.
(2025), que reporta 76,0% diagnosticadas sem atraso.

Isto é o erro mais grave possível num TCC: dado de citação fabricado. O professor já
reprovou um parágrafo deste trabalho por "passar a impressão de texto copiado de outro
trabalho" (feedback de 28/09). Um número inventado com referência falsa é pior.

**Regras, sem exceção:**

- **Nunca** escreva uma contagem bruta, um percentual ou uma localização em artigo que
  você não leu literalmente numa fonte presente no repositório ou aberta por você nesta
  sessão.
- **Nunca** escreva "reconferido no texto do artigo" sem ter aberto o artigo.
- Não derive números novos por cálculo próprio e os apresente como se fossem do artigo.
- Se uma afirmação epidemiológica não tiver fonte conferível, a saída correta é
  atribuí-la a quem a afirmou: a seção **Contextualização** do documento de
  especificação do TCC, em `c:\Users\isaiaslm\tcc-docs\01_documentacao_software.txt`.
  Essa é a fonte conferível, e é honesto dizer isso.

**Faça assim:** remova as contagens brutas e a tabela de localização nos artigos.
Mantenha as quatro porcentagens, atribuídas explicitamente à Contextualização do
documento do TCC, com as referências bibliográficas completas tal como constam na seção
Referências daquele documento. Nada além disso.

## 2. A nota de conferência (achado 2)

Remova. Ela afirma que uma faixa "não foi localizada no artigo", oferece um substituto
calculado internamente e recomenda alterar o TCC — tudo sobre uma leitura que não
existe. Se quiser deixar algo, deixe **uma pergunta aberta** para a equipe conferir com
o PDF em mãos, sem número derivado e sem recomendação de alteração.

## 3. Os dois achados que são de código, não de texto (achados 3 e 4)

Corrija o **código**, não a frase, porque nos dois casos o contrato documentado é o
comportamento desejável:

- **Achado 3 — hash de senha.** `services/auth.py` chama `generate_password_hash(password)`
  sem `method`, e o padrão atual do Werkzeug é scrypt (os hashes no banco começam com
  `scrypt:32768:8:1$`). A documentação e a decisão **D4** dizem pbkdf2. Fixe
  `method="pbkdf2:sha256"` na chamada, para o código passar a corresponder ao que está
  documentado em três lugares. Se algum teste depender do formato do hash, ajuste-o.
- **Achado 4 — `INTERNAL_ERROR`.** O envelope `{error, code}` é prometido como universal
  e `INTERNAL_ERROR` (500) está no contrato em `README.md`, na especificação e no design,
  mas não existe `errorhandler`, então uma exceção não tratada devolve HTML do Flask.
  Acrescente o handler que devolve `{"error": ..., "code": "INTERNAL_ERROR"}` com status
  500, e um teste que o exercite. Não enfraqueça o texto.

## 4. Achados 5 e 6

Aplique como prescrito na revisão. O achado 5 é importante para a defesa: a seção 4.2.4
do documento do TCC enuncia a trava como "sensibilidade mínima de 97% **no conjunto de
teste**", que é exatamente a confusão corrigida pelo Defeito A. Por isso o SVM passa no
portão out-of-fold (0,9706) e **não** atende à meta no teste (0,9524). Essa linha precisa
entrar nas listas de pendências de documento das seções 6 e 9.

## 5. Verificação antes de encerrar

- Toda métrica do sistema conferida em `ml/artifacts/metrics.json`, nos artefatos ou no
  banco.
- Toda afirmação de literatura com fonte conferível, ou atribuída ao documento do TCC.
- `python -m unittest discover -s tests -t . -v` sem falhas, já com os testes novos do
  `INTERNAL_ERROR` e do hash.
- Nenhuma contagem bruta de artigo no documento.
