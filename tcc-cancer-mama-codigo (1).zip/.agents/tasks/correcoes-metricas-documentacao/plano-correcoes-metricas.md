﻿# Plano de implementação — correção dos três defeitos de métricas

Branch `feat/mvp-alinhado-documentacao`, HEAD `1b450f3`. Commits locais apenas:
**sem push, sem PR**. Os três scripts não rastreados
`c:/Users/isaiaslm/tcc-cancer-mama/.agents/preparar_demo.py`,
`.../comparar_artefatos.py` e `.../diagnostico_metricas.py` ficam como estão
(não commitar, não apagar, não editar o `preparar_demo.py`).

Nenhuma decisão da seção 11 de
`c:/Users/isaiaslm/tcc-cancer-mama/.agents/tasks/mvp-alinhado/design.md` é
reaberta. As decisões fechadas que este plano **preserva**: o limiar e o portão
de promoção continuam calculados em predições out-of-fold do treino (§5.3, §6),
`ml/artifacts/` continua a referência versionada 80/20 e as execuções continuam
isoladas em `ml/artifacts/runs/{id}/` (D8), `{modelo}_oof.json` continua o
artefato autoritativo do portão, `roc_points` continua `{"fpr","tpr"}`, a
classificação continua usando a referência (D9) e não há trava por perfil (D3).

---

## 0. Decisões de design desta rodada

### D-A1 — o portão de promoção ganha coluna própria: `train_oof_sensitivity`

O defeito A existe porque um único campo (`trained_models.sensitivity`) foi usado
para dois significados. A separação fica:

| Grandeza | Onde fica | Conjunto | Quando muda |
|---|---|---|---|
| Portão do RNF04 | **coluna nova `train_oof_sensitivity`** (Float, nullable) | predições out-of-fold do **treino** | a cada gravação, sempre avaliada no `threshold` vigente da própria linha |
| Métricas reportadas | `accuracy`, `sensitivity`, `specificity`, `false_negative_rate`, `confusion_matrix` | **conjunto de teste** da execução daquele modelo | recalculadas em conjunto no `threshold` vigente |
| `auc` | `auc` | conjunto de teste | não muda com o limiar (calculada sobre as probabilidades) |

Nome exato: coluna `trained_models.train_oof_sensitivity`; campo de API
`train_oof_sensitivity` (em `GET /models`, `GET /models/comparison`,
`GET /training-runs/{id}` e na resposta de `PUT /models/{id}/threshold`).
Escolhido por ser autoexplicativo em inglês e carregar as duas informações que
evitam a confusão: é do **treino** e é **out-of-fold**. A coluna `sensitivity`
passa a significar, sem exceção, sensibilidade no conjunto de teste.

Rejeitado `oof_sensitivity` (não diz que é do treino) e
`promotion_gate_sensitivity` (nomeia o uso, não a origem do dado — e o mesmo
número também serve de diagnóstico fora da promoção).

### D-A2 — insumo do recálculo: probabilidades do teste **persistidas** por execução

Opções avaliadas para recalcular as métricas de teste em um limiar novo:

1. **Persistir as probabilidades do teste** em `{modelo}_test_proba.json`
   (`{"y_true": [...], "proba": [...]}`) no diretório de artefatos da execução,
   ao lado do já existente `{modelo}_oof.json`.
2. **Recomputar sob demanda** carregando `scaler.joblib` + `{modelo}.joblib` e
   os índices de `split.json["teste"]` a cada chamada.

**Escolhida a opção 1**, com a opção 2 rebaixada a mecanismo de *regeneração*
de arquivo ausente. Justificativa: (a) é exatamente o precedente já fechado no
design §6 para o vetor OOF, então não introduz um segundo padrão de artefato;
(b) o `PUT /threshold` fica em leitura de JSON (114–171 floats), sem carregar
sklearn nem o dataset, e continua bem longe de qualquer limite de tempo;
(c) sobrevive à ausência do `.joblib` e a divergência de versão do sklearn, que
é o que RNF03 cobra; (d) o custo é desprezível (dois arquivos de ~3 KB por
execução, e `ml/artifacts/runs/` é ignorado pelo git).

A regeneração determinística (opção 2 como fallback) é necessária porque os
artefatos de referência já versionados nasceram antes deste campo — mesma
situação e mesma solução do `regenerar_oof_ausentes` (design §2.4).

### D-B — unicidade por execução + nome, não por hash do artefato

`artifact_sha256 UNIQUE` é a premissa errada: dois treinos deterministas com a
mesma semente e os mesmos dados produzem legitimamente os mesmos bytes, e foi o
desvio para "reaproveitar o registro" que fez `artifact_path` apontar para a
referência 80/20 em modelos nascidos de execuções 70/30.

Novo esquema: `artifact_sha256` continua existindo (procedência e RNF03), mas
**sem** `unique`; a unicidade passa a ser a restrição de tabela
`UniqueConstraint("training_run_id", "name", name="uq_trained_models_run_name")`
— uma linha por (execução, modelo), que é o que o domínio diz. Restrição de
tabela declarada em `__table_args__` é criada igual por `create_all()` em
PostgreSQL e em SQLite (nenhum tipo ou sintaxe de dialeto envolvido, coerente
com design §2.1). `artifact_path` passa a ser **sempre** o artefato da própria
execução.

Migração: o projeto não usa Alembic e a política fechada no design §2 é
**recriação de schema, sem migração de linhas** (banco de desenvolvimento
descartável). Vale aqui também, porque as linhas atuais estão justamente
inconsistentes: SQLite → apagar `instance/tcc_cancer_mama.db`; PostgreSQL →
`DROP SCHEMA public CASCADE; CREATE SCHEMA public;` e subir a aplicação, que
executa `create_all()` + `sincronizar_modelos()`. Documentado no README, na
especificação e no relatório.

### D-C — composição do teste vem dos dados, por execução

Não é preciso coluna nova: a matriz de confusão de cada linha **é** a composição
do teste daquela execução (`total = vn+fp+fn+vp`, `malignos = vp+fn`), e
`training_runs.test_size` dá a fração. O cabeçalho fixo "114 casos, 42 malignos"
sai; cada linha da tabela passa a exibir a sua própria composição, e a tela
avisa quando a tabela mistura partições diferentes.

---

## 1. Itens de implementação (em ordem de dependência)

- [x] 1. **Esquema de `trained_models`: coluna do portão e nova unicidade.**
      Em `c:/Users/isaiaslm/tcc-cancer-mama/db/models.py`, classe `TrainedModel`:
      acrescentar `train_oof_sensitivity = db.Column(db.Float, nullable=True)`
      (docstring: sensibilidade das predições out-of-fold do TREINO avaliada no
      `threshold` desta linha — portão do RNF04, nunca métrica reportada);
      trocar `artifact_sha256 = db.Column(..., unique=True)` por
      `db.Column(db.String(64), nullable=False, index=True)`; acrescentar
      `__table_args__ = (db.UniqueConstraint("training_run_id", "name", name="uq_trained_models_run_name"),)`.
      Incluir `train_oof_sensitivity` em `to_dict()`, logo após
      `false_negative_rate`, e atualizar a docstring do módulo e da classe
      declarando que `sensitivity`/`specificity`/`accuracy`/
      `false_negative_rate`/`confusion_matrix` são **sempre** do conjunto de
      teste no `threshold` vigente.
      Files: `c:/Users/isaiaslm/tcc-cancer-mama/db/models.py`
      Verify: `cd c:\Users\isaiaslm\tcc-cancer-mama; python -m unittest discover -s tests -t . -v` — suíte verde (os testes de treino/promoção ainda não exercitam o campo novo; nenhum deve quebrar).

- [x] 2. **Persistir as probabilidades do conjunto de teste no treino.**
      Em `c:/Users/isaiaslm/tcc-cancer-mama/ml/train.py`, dentro do laço de
      `train_and_evaluate`, após calcular `proba = modelo.predict_proba(X_test_scaled)[:, 1]`,
      gravar `_salvar_json(os.path.join(output_dir, f"{nome}_test_proba.json"), {"y_true": y_test.tolist(), "proba": proba.tolist()})`.
      Acrescentar à docstring da função o arquivo novo na lista de artefatos e
      uma frase dizendo que ele é o insumo do recálculo das métricas de teste
      quando o limiar vigente muda (`PUT /models/{id}/threshold`).
      Files: `c:/Users/isaiaslm/tcc-cancer-mama/ml/train.py`
      Verify: `python -m unittest tests.test_training -v` — verde; e o item 3 adiciona a asserção sobre o arquivo.

- [x] 3. **Regeneração determinística do `{modelo}_test_proba.json` ausente.**
      Em `c:/Users/isaiaslm/tcc-cancer-mama/services/modelos.py`, criar
      `regenerar_test_proba_ausentes(metrics, artifacts_dir=ARTIFACTS_DIR)`
      espelhando `regenerar_oof_ausentes`: lê `split.json` (chave `"teste"`, em
      português — não renomear), carrega `scaler.joblib` e `{modelo}.joblib` do
      mesmo diretório, aplica `scaler.transform(X[idx_teste])`, grava
      `{"y_true": y_teste.tolist(), "proba": predict_proba[:,1].tolist()}`.
      Sem `split.json`, sem scaler ou sem `.joblib`, retorna sem gravar (mesmo
      contrato de degradação do OOF). Chamar a função em `sincronizar_modelos`
      imediatamente após `regenerar_oof_ausentes(metrics, artifacts_dir)`.
      Files: `c:/Users/isaiaslm/tcc-cancer-mama/services/modelos.py`
      Verify: novo teste do item 11 (`tests/test_metricas_coerentes.py::test_regeneracao_reproduz_as_metricas_da_referencia`) — as métricas recalculadas a partir do arquivo regenerado batem com `metrics.json: teste_operacao` em 1e-9.

- [x] 4. **Gerar e versionar os dois `*_test_proba.json` da referência.**
      Rodar a regeneração só para a referência (sem reexecutar `python -m ml.train`,
      para `metrics.json`/`train_config.json` continuarem byte-a-byte iguais ao
      commit — mesmo cuidado da rodada anterior): script temporário de uma linha
      em `app_context` chamando `svc_modelos.regenerar_test_proba_ausentes(json.load(open('ml/artifacts/metrics.json')))`,
      apagado depois. Resultado esperado:
      `c:/Users/isaiaslm/tcc-cancer-mama/ml/artifacts/regressao_logistica_test_proba.json`
      e `.../svm_test_proba.json`, com 114 pares cada.
      Files (criados): `ml/artifacts/regressao_logistica_test_proba.json`, `ml/artifacts/svm_test_proba.json`
      Verify: `cd c:\Users\isaiaslm\tcc-cancer-mama; git status --porcelain ml/artifacts` lista **apenas** os dois arquivos novos (nenhum `M`), e `python -c "import json;d=json.load(open('ml/artifacts/svm_test_proba.json'));print(len(d['y_true']),len(d['proba']),sum(d['y_true']))"` imprime `114 114 42`.

- [x] 5. **Recálculo coerente das métricas de teste em um limiar qualquer.**
      Em `c:/Users/isaiaslm/tcc-cancer-mama/services/modelos.py`: nova exceção
      `TesteProbaIndisponivel(Exception)` e nova função
      `metricas_teste_no_limiar(nome_modelo, threshold, artifacts_dir=ARTIFACTS_DIR) -> dict`,
      que lê `{nome}_test_proba.json` (levantando `TesteProbaIndisponivel` se
      ausente) e devolve `ml.train.compute_metrics(y_true, (proba >= threshold).astype(int), proba)`.
      Reusar `compute_metrics` é deliberado: garante uma única implementação da
      matriz de confusão e das razões, e é o que faz a invariante do item 10
      valer por construção. Nenhuma outra função calcula métricas de teste.
      Files: `c:/Users/isaiaslm/tcc-cancer-mama/services/modelos.py`
      Verify: `python -m unittest tests.test_metricas_coerentes -v` (item 10) — verde.

- [x] 6. **`promover_modelo` passa a gravar a linha inteira coerente.**
      Em `c:/Users/isaiaslm/tcc-cancer-mama/services/modelos.py`, trocar a
      assinatura para `promover_modelo(registro, threshold, sensibilidade_oof_valor, metricas_teste)` e gravar:
      `registro.threshold = threshold`;
      `registro.train_oof_sensitivity = sensibilidade_oof_valor`;
      `accuracy/sensitivity/specificity/auc/false_negative_rate/confusion_matrix`
      de `metricas_teste` (`acuracia`/`sensibilidade`/`especificidade`/`auc`/
      `taxa_falsos_negativos`/`matriz_confusao`); `is_production` como hoje.
      **Nunca** gravar o valor OOF em `sensitivity`. Docstring explicando a
      separação (portão × métricas reportadas) e que `auc` é reescrita com o
      mesmo valor por ser independente do limiar.
      Files: `c:/Users/isaiaslm/tcc-cancer-mama/services/modelos.py`
      Verify: `python -m unittest tests.test_training tests.test_metricas_coerentes -v` — verde depois do item 7.

- [x] 7. **`PUT /api/v1/models/{id}/threshold`: portão OOF + métricas de teste.**
      Em `c:/Users/isaiaslm/tcc-cancer-mama/api/routes.py`, `ajustar_threshold`:
      (1) manter o cálculo do portão com `svc_modelos.sensibilidade_oof(...)` no
      diretório do próprio registro e o 503 `MODEL_UNAVAILABLE` quando o OOF
      falta; (2) manter o 400 `SENSITIVITY_BELOW_TARGET` com
      `obtained`/`required` quando o portão < 0,97, **sem** alterar nada;
      (3) antes de qualquer escrita, obter `metricas = svc_modelos.metricas_teste_no_limiar(registro.name, threshold, artifacts_dir=svc_modelos.diretorio_artefatos_do_registro(registro))`
      e, em `TesteProbaIndisponivel`, devolver 503 `MODEL_UNAVAILABLE` com
      mensagem "Probabilidades do conjunto de teste indisponíveis para
      recalcular as métricas no limiar pedido." — nada é gravado, porque uma
      linha meio atualizada é exatamente o defeito A;
      (4) chamar `promover_modelo(registro, threshold, sensibilidade, metricas)`,
      manter `clear_cache()` e responder 200 com
      `{"model", "threshold", "train_oof_sensitivity", "test_metrics": {accuracy, sensitivity, specificity, auc, false_negative_rate, confusion_matrix}}`.
      A chave ambígua `sensitivity` de nível superior **sai** da resposta (era
      o portão disfarçado de métrica); `_metricas_en` é reusada para traduzir o
      bloco `test_metrics`.
      Files: `c:/Users/isaiaslm/tcc-cancer-mama/api/routes.py`
      Verify: `python -m unittest tests.test_training -v` — os testes de promoção ajustados no item 12 passam.

- [x] 8. **Uma linha de `trained_models` por execução (defeito B).**
      Em `c:/Users/isaiaslm/tcc-cancer-mama/services/modelos.py`:
      — `concluir_training_run_sucesso`: remover a busca por `artifact_sha256` e
      o reaproveitamento de registro; **sempre** `TrainedModel(...)` novo com
      `training_run_id=run.id`, `artifact_path=_caminho_artefato(artifacts_dir, nome)`
      (o diretório da própria execução, sem o `if novo or not os.path.exists(...)`)
      e `artifact_sha256=sha`; preencher `train_oof_sensitivity` chamando
      `sensibilidade_oof(nome, r["limiar_seguranca"], artifacts_dir)` dentro de
      `try/except OofIndisponivel` → `None` (treino bem-sucedido não pode falhar
      por causa do portão informativo). Atualizar a docstring do módulo, que hoje
      afirma que o hash é a identidade do registro.
      — `sincronizar_modelos`: trocar o critério "falta o hash" por "falta a
      linha **desta referência**", isto é, considerar já sincronizado o modelo
      que tem linha com `artifact_path == _caminho_artefato(artifacts_dir, nome)`
      **e** `artifact_sha256 == hash atual`; só os demais entram em `pendentes`
      (mantendo o run sintético criado uma única vez) e, no laço, o registro
      existente é buscado por esse mesmo par em vez de pelo hash. Preencher
      também `train_oof_sensitivity` nas linhas criadas.
      Files: `c:/Users/isaiaslm/tcc-cancer-mama/services/modelos.py`
      Verify: `python -m unittest tests.test_training -v` com os testes novos do item 12 (duas execuções idênticas → duas linhas, cada uma com o `artifact_path` da sua execução; sincronizar duas vezes → nenhuma linha duplicada).

- [x] 9. **`GET /api/v1/models/comparison` dirigido pelo banco, com composição por execução (defeitos A e C).**
      Em `c:/Users/isaiaslm/tcc-cancer-mama/api/routes.py`, `comparar_modelos`:
      — manter `load_bundle()` (503 `MODEL_UNAVAILABLE` sem artefato) e o bloco
      `reproducibility` da referência, mas renomear nada: só documentar que
      descreve a referência 80/20.
      — trocar `registros = {m.name: m for m in TrainedModel.query.all()}` (hoje
      o "último do dict" é arbitrário) pela **linha mais recente por nome**:
      consulta ordenada por `trained_at desc, id desc`, guardando a primeira
      ocorrência de cada `name`. O laço passa a iterar essas linhas, não
      `metrics["modelos"]`.
      — por item, além do que já existe: `training_run_id`, `artifact_path`,
      `test_size` (de `registro.training_run.test_size`),
      `test_set_size` e `test_set_malignant` derivados de
      `registro.confusion_matrix` (`vn+fp+fn+vp` e `vp+fn`; `None` se a matriz
      faltar), `train_oof_sensitivity`, `operating_point` com as colunas do
      banco (teste no `threshold` vigente), `meets_sensitivity_target` =
      `sensitivity >= SENSIBILIDADE_MINIMA` (teste) e
      `gate_meets_sensitivity_target` = `train_oof_sensitivity >= SENSIBILIDADE_MINIMA`.
      — `default_point`, `cross_validation`, `safety_threshold_reached_target` e
      `roc_points` passam a vir do `metrics.json` **da execução daquele
      registro** (`svc_modelos.diretorio_artefatos_do_registro(registro)`), com
      `default_point`/`cross_validation` iguais a `None` quando o diretório da
      execução já não existe (execução descartada) — nunca da referência, que é
      outra partição. `roc_points` mantém o fallback para `registro.roc_points`.
      — no topo da resposta: `test_partitions_mixed` (True quando os itens têm
      mais de um `training_run_id` ou mais de um `test_set_size`) e
      `test_partitions` (lista de `{training_run_id, test_size, test_set_size, test_set_malignant}`).
      Files: `c:/Users/isaiaslm/tcc-cancer-mama/api/routes.py`
      Verify: `python -m unittest tests.test_modelos_comparacao -v` (item 13) — verde.

- [x] 10. **Teste da invariante das métricas (defeito A).**
      Criar `c:/Users/isaiaslm/tcc-cancer-mama/tests/test_metricas_coerentes.py`
      (classe sobre `ApiAutenticadoTestCase`) com um helper
      `assert_linha_coerente(modelo)` que, para toda linha de `trained_models`,
      verifica com `assertAlmostEqual(..., places=6)`:
      `sensitivity == vp/(vp+fn)`, `false_negative_rate == fn/(vp+fn)`,
      `specificity == vn/(vn+fp)`, `accuracy == (vn+vp)/(vn+fp+fn+vp)` e
      `sensitivity + false_negative_rate == 1`. Casos:
      (a) após `sincronizar_modelos()` da referência;
      (b) após `POST /training-runs` (`test_size` 0.2 e 0.3, `grid_search=False`);
      (c) após `PUT /threshold` em 0.01, 0.20 e 0.45 — varrendo **todas** as
      linhas da tabela depois de cada chamada;
      (d) regressão do caso real id=6: com `threshold=0.01`, a `specificity`
      gravada tem de **cair** em relação ao limiar de segurança e a matriz de
      confusão tem de mudar (`fp` maior), provando que não ficou do limiar
      antigo; e `sensitivity != train_oof_sensitivity` quando os dois diferem,
      com `sensitivity` sempre igual ao recálculo no conjunto de teste;
      (e) `auc` idêntica antes e depois do `PUT` (independe do limiar);
      (f) `test_regeneracao_reproduz_as_metricas_da_referencia`: as métricas
      recalculadas de `{modelo}_test_proba.json` no `limiar_seguranca` batem com
      `metrics.json: modelos[nome].teste_operacao` (todas as chaves, 1e-9) —
      é a validação da escolha D-A2.
      Files: `c:/Users/isaiaslm/tcc-cancer-mama/tests/test_metricas_coerentes.py`
      Verify: `python -m unittest tests.test_metricas_coerentes -v` — todos os testes passam.

- [x] 11. **Teste do artefato de probabilidades do teste.**
      No mesmo arquivo do item 10 (ou em `tests/test_training.py`, onde já há o
      padrão de inspeção de artefatos): após `POST /training-runs`, existe
      `ml/artifacts/runs/{run_id}/{modelo}_test_proba.json` com
      `len(y_true) == len(proba) == train_config["n_teste"]`; e
      `sum(y_true) == train_config["distribuicao_teste"]["maligno"]`. Confirmar
      também que `git status --porcelain ml/artifacts` segue vazio após a
      suíte (os `*_test_proba.json` da referência já estarão commitados).
      Files: `c:/Users/isaiaslm/tcc-cancer-mama/tests/test_metricas_coerentes.py`
      Verify: `python -m unittest tests.test_metricas_coerentes -v`.

- [x] 12. **Testes ajustados/novos de treino, promoção e unicidade (defeito B).**
      Em `c:/Users/isaiaslm/tcc-cancer-mama/tests/test_training.py`:
      — ajustar `test_sensibilidade_igual_ou_acima_de_0_97_promove` e
      `test_promocao_le_o_oof_do_diretorio_da_execucao` para a resposta nova
      (`train_oof_sensitivity` + bloco `test_metrics`, sem a chave `sensitivity`
      de topo) e para `patch.object(svc_modelos, "sensibilidade_oof", ...)`
      continuar sendo só o portão;
      — novo: duas execuções `POST /training-runs` com os mesmos parâmetros
      (bytes idênticos) criam **duas** linhas, cada uma com
      `artifact_path == f"ml/artifacts/runs/{run_id}/{nome}.joblib"` — regressão
      direta do defeito B;
      — novo: `sincronizar_modelos()` chamado duas vezes não duplica linhas nem
      cria um segundo `TrainingRun` sintético;
      — novo: inserir à mão duas linhas com o mesmo `(training_run_id, name)`
      levanta `IntegrityError` (a nova unicidade vale), com `db.session.rollback()`
      no fim;
      — novo: `TesteProbaIndisponivel` no `PUT` devolve 503 `MODEL_UNAVAILABLE` e
      a linha permanece **idêntica** (limiar e todas as métricas inalteradas).
      Files: `c:/Users/isaiaslm/tcc-cancer-mama/tests/test_training.py`
      Verify: `python -m unittest tests.test_training -v` — verde.

- [x] 13. **Teste do endpoint de comparação (defeito C).**
      Criar `c:/Users/isaiaslm/tcc-cancer-mama/tests/test_modelos_comparacao.py`:
      com a referência sincronizada, `GET /models/comparison` traz, por item,
      `test_set_size`/`test_set_malignant` coerentes com a matriz de confusão da
      própria linha e `test_partitions_mixed == False`; depois de um
      `POST /training-runs` com `test_size=0.3` de **um só** modelo, a resposta
      passa a ter `test_partitions_mixed == True`, dois `test_set_size`
      distintos e `default_point` da execução certa (ou `None` se o diretório da
      execução foi descartado); `train_oof_sensitivity` presente e distinto de
      `operating_point.sensitivity`; item sem `confusion_matrix` não quebra a
      rota (`test_set_size is None`).
      Files: `c:/Users/isaiaslm/tcc-cancer-mama/tests/test_modelos_comparacao.py`
      Verify: `python -m unittest tests.test_modelos_comparacao -v` — verde.

- [x] 14. **Laboratório de Modelos: rótulos explícitos e composição por execução.**
      Em `c:/Users/isaiaslm/tcc-cancer-mama/frontend/src/pages/ModelosPage.jsx`:
      — remover do cabeçalho da seção "Comparação dos classificadores" o texto
      derivado de `r.n_teste`/`r.distribuicao_teste` (a referência), deixando só
      classe positiva, melhor modelo e critério;
      — na tabela do ponto de operação, acrescentar colunas **"Teste (casos)"**
      e **"Malignos no teste"** (de `test_set_size`/`test_set_malignant`, "—"
      quando nulo) e **"Sensibilidade OOF treino (portão)"** (de
      `train_oof_sensitivity`), com `caption` explicitando: "Métricas no
      CONJUNTO DE TESTE da execução de cada modelo, no limiar vigente; a última
      coluna é o portão de promoção, calculado em predições out-of-fold do
      TREINO — não reportar uma pela outra";
      — renomear os rótulos das colunas de métrica para "Acurácia (teste)",
      "Sensibilidade (teste)", "Especificidade (teste)", "AUC (teste)",
      "Falsos negativos (teste)";
      — quando `comparacao.test_partitions_mixed`, exibir
      `<Alert tone="warning" title="A tabela mistura partições de teste diferentes">`
      listando `test_partitions` e dizendo que comparar métricas entre partições
      distintas não é válido;
      — a tabela `default_point` só é renderizada para itens com
      `default_point != null`, e o título passa a "Limiar padrão (0,50) na mesma
      partição de cada modelo";
      — na seção do slider, exibir, por modelo, `train_oof_sensitivity` ao lado
      do limiar de segurança, com a legenda "portão out-of-fold do treino", e o
      `Alert` de sucesso passa a ler `resposta.train_oof_sensitivity` e a
      mostrar também a sensibilidade de teste recalculada
      (`resposta.test_metrics.sensitivity`);
      — na seção "Reprodutibilidade", prefixar que o bloco descreve **os
      artefatos de referência (80/20)**, não necessariamente a execução das
      linhas acima.
      Ajustar `aplicarLimiar` em
      `c:/Users/isaiaslm/tcc-cancer-mama/frontend/src/pages/ModelosPage.jsx`
      para o novo corpo de resposta. `frontend/src/api.js` não muda.
      Files: `c:/Users/isaiaslm/tcc-cancer-mama/frontend/src/pages/ModelosPage.jsx`
      Verify: `cd c:\Users\isaiaslm\tcc-cancer-mama\frontend; npm run build` — build sem erro (dist é ignorado pelo git).

- [x] 15. **Suíte completa + pipeline de ML + verificação de runtime.**
      Rodar, nesta ordem, de `c:/Users/isaiaslm/tcc-cancer-mama`:
      `python -m unittest discover -s tests -t . -v` (esperado: ≥ 86 testes
      anteriores + os novos, zero falhas; `git status --porcelain ml/artifacts`
      vazio depois); `python -m ml.train` (confirma que o treino de referência
      roda e agora grava os `*_test_proba.json`; se `metrics.json`/
      `train_config.json` diferirem só em `gerado_em`/`commit_git`, restaurar com
      `git checkout -- ml/artifacts` como na rodada anterior e regerar
      `python -m ml.report`); subir `python app.py` e exercitar com `urllib` +
      `CookieJar` (script temporário, apagado depois):
      `PUT /models/{id}/threshold` com 0.01 → 200, e conferir no banco que
      `specificity` caiu, a matriz mudou e a invariante vale;
      `GET /models/comparison` → `test_partitions_mixed` e composição por item.
      Files: nenhum (verificação)
      Verify: suíte verde, build do frontend verde e `python .agents\diagnostico_metricas.py` sem nenhuma linha `DIVERGENTE`.

- [x] 16. **Higiene do banco de demonstração.**
      Derrubar o servidor; apagar
      `c:/Users/isaiaslm/tcc-cancer-mama/instance/tcc_cancer_mama.db` (está no
      `.gitignore`, não entra em commit) e, se existir,
      `c:/Users/isaiaslm/tcc-cancer-mama/ml/artifacts/runs/` inteiro; subir
      `python app.py` (recria o schema com a nova unicidade e sincroniza só os
      dois modelos de **referência** 80/20); rodar
      `python .agents\preparar_demo.py` **sem editar o script** — ele cria
      `medico@demo.local` e `pesquisador@demo.local` (senha `demo12345`, perfis
      `medico` e `pesquisador`), classifica um caso maligno e um benigno, grava
      uma avaliação no **modo identificado** e exercita o bloqueio do RNF04
      (limiar 0,95 → 400 `SENSITIVITY_BELOW_TARGET`, sem alterar nada).
      Files: nenhum rastreado (apenas `instance/` e `ml/artifacts/runs/`, ignorados)
      Verify: `python .agents\diagnostico_metricas.py` mostra **2 execuções** (a sintética e nenhuma outra, ou a sintética apenas), **2 modelos** com `total=114` e `malignos=42`, `artifact_path=ml/artifacts/{nome}.joblib`, todas as linhas `OK` em COERENCIA; e `python .agents\comparar_artefatos.py` sem divergência.

- [x] 17. **Documentação: README.**
      Em `c:/Users/isaiaslm/tcc-cancer-mama/README.md`: na tabela do contrato da
      API, atualizar a linha de `PUT /models/{id}/threshold` (portão OOF +
      recálculo das métricas de teste, resposta com `train_oof_sensitivity` e
      `test_metrics`) e a de `GET /models/comparison` (composição do teste por
      execução, `test_partitions_mixed`); no bloco "Outras decisões técnicas",
      ajustar o item "Promoção de modelo" e acrescentar **D11 — métricas
      reportadas são do teste; o portão é do treino out-of-fold** (com a
      invariante `sensitivity == vp/(vp+fn)`) e **D12 — uma linha de
      `trained_models` por execução** (unicidade `(training_run_id, name)`,
      `artifact_path` sempre da execução, e como recriar o banco em SQLite e em
      PostgreSQL); em "Como rodar", acrescentar a nota de recriação do banco e
      os novos artefatos `{modelo}_test_proba.json` na descrição de
      `ml/artifacts/`.
      Files: `c:/Users/isaiaslm/tcc-cancer-mama/README.md`
      Verify: leitura — nenhuma menção sobrevivente a "reaproveita o registro existente" nem a conjunto de teste fixo de 114 casos fora do contexto da referência 80/20.

- [x] 18. **Documentação: especificação consolidada.**
      Em `c:/Users/isaiaslm/tcc-cancer-mama/.agents/ESPECIFICACAO-CONSOLIDADA.md`:
      seção 4 (`trained_models`) — acrescentar `train_oof_sensitivity` à lista de
      colunas, declarar que as métricas escalares e a matriz são do conjunto de
      teste no limiar vigente, substituir o parágrafo que diz que o registro é
      reaproveitado quando o `artifact_sha256` coincide pela nova regra de
      unicidade `(training_run_id, name)` com `artifact_path` sempre da execução,
      e registrar a recriação de schema (SQLite e PostgreSQL); seção 5 — corpo de
      resposta novo de `PUT /models/{id}/threshold` e campos aditivos de
      `GET /models/comparison` (`test_set_size`, `test_set_malignant`,
      `test_size`, `train_oof_sensitivity`, `test_partitions_mixed`,
      `test_partitions`); seção 6 — o artefato `{modelo}_test_proba.json` por
      execução e a frase de que o conjunto de teste nunca escolhe limiar, só
      reporta métricas; seção 8 — verificação do RNF04 passa a citar a
      invariante testada automaticamente.
      Files: `c:/Users/isaiaslm/tcc-cancer-mama/.agents/ESPECIFICACAO-CONSOLIDADA.md`
      Verify: leitura cruzada com o código dos itens 1, 7, 8 e 9 — nenhum campo documentado que não exista e nenhum campo novo não documentado.

- [x] 19. **Documentação: relatório de implementação e notas datadas no design.**
      Em `c:/Users/isaiaslm/tcc-cancer-mama/.agents/RELATORIO-IMPLEMENTACAO.md`:
      nova seção **2.6 "Defeitos de métricas encontrados na segunda revisão e
      corrigidos"**, com um bloco por defeito (sintoma, evidência real — id=2 e
      id=6 de `diagnostico-antes.txt`, incluindo a especificidade 0,9907 em
      limiar 0,01 —, causa, correção e como foi verificado), citando
      `.agents/tasks/correcoes-metricas-documentacao/diagnostico-antes.txt`;
      atualizar a contagem de testes, a seção 2.2 (deixando claro que os números
      publicados são da referência 80/20), a seção 2.5 (defeito 2 do
      `artifact_path` agora encerrado), a seção 4 (pendências) e a seção 6
      (estado da branch e commits).
      Em `c:/Users/isaiaslm/tcc-cancer-mama/.agents/tasks/mvp-alinhado/design.md`,
      acrescentar **notas datadas** (sem reabrir decisões) em §2.3 (coluna nova e
      nova unicidade), §5.3 (portão × métricas reportadas e o 503 quando falta o
      `*_test_proba.json`), §5.4 (`comparison` dirigido pelo banco) e §6 (o novo
      artefato ao lado do OOF). A **seção 11 permanece intocada** — conferir com
      `git diff` que nenhum hunk cai nela.
      Files: `c:/Users/isaiaslm/tcc-cancer-mama/.agents/RELATORIO-IMPLEMENTACAO.md`, `c:/Users/isaiaslm/tcc-cancer-mama/.agents/tasks/mvp-alinhado/design.md`
      Verify: `cd c:\Users\isaiaslm\tcc-cancer-mama; git diff --stat .agents/tasks/mvp-alinhado/design.md` e inspeção dos hunks — todos antes da seção 11.

---

## 2. Ordem de commits

Cada commit deixa a árvore compilável e a suíte verde; os três scripts não
rastreados e `instance/` ficam fora de todos eles (`git add` por arquivo, nunca
`git add -A`). Não incluir `ml/__pycache__/*.pyc` (rastreados por acidente desde
antes — restaurar com `git checkout -- ml/__pycache__` se aparecerem como
modificados).

1. `feat(ml): persiste as probabilidades do conjunto de teste por execucao`
   — itens 2, 3, 4 e 11. Arquivos: `ml/train.py`, `services/modelos.py`
   (somente a regeneração), os dois `ml/artifacts/*_test_proba.json`,
   `tests/test_metricas_coerentes.py` (parte dos artefatos).
2. `fix(db): separa o portao out-of-fold das metricas de teste em trained_models`
   — item 1. Arquivos: `db/models.py`.
3. `fix(api): recalcula as metricas de teste no limiar vigente (defeito A)`
   — itens 5, 6, 7, 10 e a parte de promoção do 12. Arquivos:
   `services/modelos.py`, `api/routes.py`, `tests/test_metricas_coerentes.py`,
   `tests/test_training.py`.
4. `fix(db): uma linha de trained_models por execucao (defeito B)`
   — itens 8 e o restante do 12. Arquivos: `services/modelos.py`,
   `tests/test_training.py`.
5. `fix(api): composicao do conjunto de teste por execucao em /models/comparison (defeito C)`
   — itens 9 e 13. Arquivos: `api/routes.py`,
   `tests/test_modelos_comparacao.py`.
6. `fix(frontend): rotula teste x portao out-of-fold no Laboratorio de Modelos`
   — item 14. Arquivos: `frontend/src/pages/ModelosPage.jsx`.
7. `docs: registra os tres defeitos de metricas e a nova semantica`
   — itens 17, 18 e 19. Arquivos: `README.md`,
   `.agents/ESPECIFICACAO-CONSOLIDADA.md`,
   `.agents/RELATORIO-IMPLEMENTACAO.md`,
   `.agents/tasks/mvp-alinhado/design.md`.

Os itens 15 e 16 (verificação ponta a ponta e higiene do banco) não geram
commit: só produzem evidência para o relatório e um banco de demonstração limpo.

---

## 3. Premissas e lacunas assumidas

1. **`POST /predictions` continua classificando pela referência** (D9): o
   limiar usado na inferência vem de `metrics.json: limiar_seguranca`, não da
   coluna `threshold`. Isso está fora do escopo destes três defeitos e **não** é
   alterado; o README já documenta a consequência.
2. **`GET /models/comparison` continua devolvendo um item por nome de modelo**
   (o mais recente), não um item por execução. Mudar para uma linha por execução
   seria redesenho da tela, não correção de defeito; o aviso de partições
   mistas cobre o risco metodológico que resta.
3. **`train_oof_sensitivity` é nullable.** Fica `None` quando o
   `{modelo}_oof.json` da execução não pôde ser lido na criação da linha. A
   promoção, que é onde o portão decide, nunca aceita `None`: sem OOF ela
   devolve 503 antes de gravar.
4. **Sem Alembic no projeto.** A estratégia de recriação de schema é a mesma já
   fechada no design §2 e foi mantida por coerência; se o avaliador exigir
   migração versionada, isso é trabalho novo, fora destes defeitos.

---

## 4. Verificação executada

Rodada em 22/10/2026, a partir de `c:/Users/isaiaslm/tcc-cancer-mama`, na branch
`feat/mvp-alinhado-documentacao`, sobre o conjunto completo das correções.

### 4.1 Suíte automatizada

```
python -m unittest discover -s tests -t . -v
Ran 107 tests in 93.925s
OK
```

Zero falhas e zero erros. Eram **86** testes antes desta rodada; os 21 novos são
`tests/test_metricas_coerentes.py` (9, incluindo o teste da invariante), os 8 de
`tests/test_modelos_comparacao.py` e os 4 de
`tests/test_training.py::TestUmaLinhaPorExecucao`. Os avisos no stderr
(`SECRET_KEY não configurada` em teste, `FutureWarning` do scikit-learn,
`ResourceWarning` de SQLite em memória) não são falhas.

Teste da invariante isolado:

```
python -m unittest tests.test_metricas_coerentes -v
Ran 9 tests in 12.264s
OK
```

Depois da suíte, `git status --porcelain ml/artifacts` lista apenas os dois
`*_test_proba.json` (já commitados); nenhum artefato de referência modificado.
Os `.pyc` de `ml/__pycache__` (rastreados por acidente desde antes) foram
restaurados com `git checkout -- ml/__pycache__`.

### 4.2 Pipeline de ML

```
python -m ml.train
```

Saída limpa, exit 0. Reproduz exatamente os números publicados:

```
regressao_logistica  teste_operacao  limiar=0.31 acc=0.9825 sens=0.9762 esp=0.9861 auc=0.9960 FN=0.0238
svm                  teste_operacao  limiar=0.38 acc=0.9737 sens=0.9524 esp=0.9861 auc=0.9927 FN=0.0476
```

`metrics.json` e `train_config.json` diferiram **apenas** em `gerado_em` e
`commit_git`; restaurados com `git checkout -- ml/artifacts` para o commit
continuar citando os mesmos artefatos, e o report regerado:

```
python -m ml.report
ml/artifacts/report/roc_comparacao.png
ml/artifacts/report/matrizes_confusao.png
ml/artifacts/report/importancia_regressao_logistica.png
ml/artifacts/report/importancia_svm.png
ml/artifacts/report/metricas.csv
```

Saída limpa, exit 0; `git status --porcelain ml/artifacts` sem nenhum arquivo
modificado depois.

Validação de D-A2 — as probabilidades persistidas reproduzem a referência:

```
regressao_logistica  métricas idênticas (1e-9): True   matriz idêntica: True
svm                  métricas idênticas (1e-9): True   matriz idêntica: True
```

### 4.3 Frontend

```
cd frontend; npm install; npm run build
vite v5.4.21 building for production...
✓ 44 modules transformed.
dist/index.html                   0.43 kB
dist/assets/index-ReDIXq6o.css   13.54 kB
dist/assets/index-BVSCfXRu.js   205.26 kB
✓ built in 8.15s
```

Build limpo. O `npm audit` continua reportando 4 vulnerabilidades em
dependências transitivas de **desenvolvimento** (dev-server do Vite,
react-router) — não bloqueantes, já registradas como pendência conhecida.

### 4.4 Diagnóstico do banco de demonstração

Banco recriado do zero (apagado `instance/tcc_cancer_mama.db` e
`ml/artifacts/runs/`), aplicação subida e `.agents/preparar_demo.py` executado
sem modificação:

```
python .agents/diagnostico_metricas.py
=== training_runs ===
  run 1: test_size=0.2 grid=0 status=success seed=42
=== trained_models ===
  id=1 regressao_logistica  run=1 prod=True
      acc=0.9825 sens=0.9762 esp=0.9861 auc=0.9960 fn_rate=0.0238
      limiar=0.31 limiar_seg=0.31  matriz={vn:71, fp:1, fn:1, vp:41} total=114 malignos=42
      artifact_path=ml/artifacts/regressao_logistica.joblib
      COERENCIA: sens da matriz=0.9762 fn da matriz=0.0238 -> OK
  id=2 svm                  run=1 prod=False
      acc=0.9737 sens=0.9524 esp=0.9861 auc=0.9927 fn_rate=0.0476
      limiar=0.38 limiar_seg=0.38  matriz={vn:71, fp:1, fn:2, vp:40} total=114 malignos=42
      artifact_path=ml/artifacts/svm.joblib
      COERENCIA: sens da matriz=0.9524 fn da matriz=0.0476 -> OK
```

**Nenhuma linha `DIVERGENTE`** e **nenhum `artifact_path` de execução apontando
para a referência** — as duas linhas *são* da referência 80/20 (114 casos, 42
malignos), como esperado num banco limpo. `python .agents/comparar_artefatos.py`
não reporta divergência entre o commitado e a árvore de trabalho.

Saída de `.agents/preparar_demo.py`:

```
cadastro medico@demo.local: 201
cadastro pesquisador@demo.local: 201
login medico: 200
caso maligno  -> maligno  prob=1.0000 faixa=alta modelo=regressao_logistica limiar=0.31 17ms
caso benigno  -> benigno  prob=0.0638 faixa=alta modelo=regressao_logistica limiar=0.31 1ms
caso identificado: 200
RNF04 - promover 'svm' com limiar 0.95 -> HTTP 400
  resposta: {"code": "SENSITIVITY_BELOW_TARGET", "obtained": 0.7353, "required": 0.97}
historico: 3 avaliacoes registradas
```

### 4.5 Verificação de runtime (servidor no ar)

`PUT /api/v1/models/1/threshold {"threshold": 0.01}` → **HTTP 200**:

```
antes : limiar 0.31 · sens 0.9762 · esp 0.9861 · matriz {vn:71, fp:1, fn:1, vp:41}
resposta: train_oof_sensitivity = 0.9941
          test_metrics = acc 0.7982 · sens 1.0000 · esp 0.6806 · FN 0.0000
                         matriz {vn:49, fp:23, fn:0, vp:42}
depois: limiar 0.01 · sens 1.0000 · esp 0.6806 · matriz {vn:49, fp:23, fn:0, vp:42}

especificidade caiu: True            (0.9861 -> 0.6806)
fp aumentou: 23 > 1                  (True)
auc inalterada: True                 (0.996031746031746)
invariante sens == vp/(vp+fn): True
invariante fn_rate == fn/(vp+fn): True
portao oof separado: train_oof_sensitivity=0.9941 != sensitivity=1.0
```

É a regressão exata do caso id=6: antes, a linha ficava com `sensitivity`
0,9941 (o valor out-of-fold) e `specificity` 0,9907 (do limiar antigo) num
limiar de 0,01. Agora o portão fica no seu campo e as métricas de teste são
coerentes entre si.

`GET /api/v1/models/comparison`, com a referência mais uma execução
`test_size=0.3` de um só modelo:

```
test_partitions_mixed: True
test_partitions: [{"training_run_id": 2, "test_size": 0.3, "test_set_size": 171, "test_set_malignant": 64},
                  {"training_run_id": 1, "test_size": 0.2, "test_set_size": 114, "test_set_malignant": 42}]
  regressao_logistica  run 2  teste 171 (64 malignos)  test_size 0.3
                       artefato ml/artifacts/runs/2/regressao_logistica.joblib
  svm                  run 1  teste 114 (42 malignos)  test_size 0.2
                       artefato ml/artifacts/svm.joblib
```

Defeito C resolvido (composição por execução, mistura sinalizada) e defeito B
também (o modelo da execução 70/30 aponta para `runs/2/`, não para a
referência). Depois dessa verificação o banco foi recriado e repovoado de novo,
para ficar no estado limpo descrito em 4.4.

> O passo seguinte do loop faz a verificação ponta a ponta mais pesada
> (servidor no ar, requisições reais e screenshots); o que está acima é o que foi
> rodado nesta etapa.

---

## 5. Commits criados

Acima de `1b450f3`, na branch `feat/mvp-alinhado-documentacao`, commits locais
(sem push, sem PR). Os três scripts não rastreados `.agents/preparar_demo.py`,
`.agents/comparar_artefatos.py` e `.agents/diagnostico_metricas.py` ficaram
fora de todos eles, sem modificação; `instance/` segue ignorado.

| Hash | Título |
|---|---|
| `a92e6ba` | `feat(ml): persiste as probabilidades do conjunto de teste por execucao` |
| `3265dd7` | `fix(db): separa o portao out-of-fold das metricas de teste em trained_models` |
| `8f538cb` | `fix(api): recalcula as metricas de teste no limiar vigente (defeitos A, B e C)` |
| `d4ad3b3` | `test: cobre a invariante das metricas e a composicao do teste por execucao` |
| `68bf1ef` | `fix(frontend): rotula teste x portao out-of-fold no Laboratorio de Modelos` |
| `d7e95f5` | `docs: registra os tres defeitos de metricas e a nova semantica` |

A ordem de commits planejada na seção 2 foi agrupada em seis commits em vez de
sete, porque as mudanças de `services/modelos.py` e de `api/routes.py` são
interdependentes (a assinatura de `promover_modelo` muda junto com a rota que a
chama) e separá-las deixaria um commit intermediário com a suíte vermelha. Cada
um dos seis commits deixa a árvore compilável e a suíte verde.
