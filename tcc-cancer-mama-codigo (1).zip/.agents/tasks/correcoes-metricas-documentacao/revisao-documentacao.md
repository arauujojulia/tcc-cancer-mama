# Revisão de `docs/COMO-FUNCIONA.md` contra o código e as fontes da verdade

Revisão da versão atual de `docs/COMO-FUNCIONA.md` (arquivo ainda não rastreado, branch
`feat/mvp-alinhado-documentacao`, HEAD `ff7479e`) contra `ml/artifacts/metrics.json`,
`train_config.json`, `split.json`, os vetores `{modelo}_oof.json` e
`{modelo}_test_proba.json`, `feature_importance.json`, `data/wdbc.data`, o banco
`instance/tcc_cancer_mama.db`, os pontos de código citados e os documentos do TCC em
`c:/Users/isaiaslm/tcc-docs/`. A suíte, o build e o treino **não** foram re-executados: as
evidências vieram de `relatorio-verificacao.md`, conforme determinado. Todos os números
citados no documento foram reconferidos na fonte, um por um, inclusive recalculando os
portões out-of-fold a partir dos vetores persistidos.

Nenhum número inventado, nenhuma métrica sem fonte conferível, nenhuma contagem bruta de
artigo, e a base é descrita como tabular em todos os pontos em que aparece. As dez seções
exigidas estão presentes e respondem ao que foi pedido. A tabela de rastreabilidade foi
conferida linha a linha: **todos** os arquivos e funções que ela cita existem com
exatamente aquele nome. Os quatro blocos Mermaid são estruturalmente válidos.

Atenção: três imprecisões de atribuição e de escopo, nenhuma delas numérica. A afirmação
de incidência da seção 1 é atribuída à Contextualização do documento do TCC, mas está na
Introdução (confirmado). A lista de "pendências de documento" se declara completa e
rotula os sete itens como "o código está correto", o que desclassifica o item do hash de
senha — que a `DIRETRIZ-OBRIGATORIA.md` mandou corrigir **no código** (confirmado). E a
mesma lista omite a família do item (b) do feedback do professor: os RFs/RNFs de login e
perfis, PostgreSQL, paginação com filtros e meta de 0,97, que o professor e a própria
equipe pediram para incluir nos requisitos (confirmado).

**Veredito**: APPROVED

## Visão geral

Os números estão certos. Métricas, limiares, matrizes de confusão, validação cruzada,
composição das partições, hiperparâmetros, versões, commit e SHA-256 batem com os
artefatos; o portão out-of-fold de 0,9706 e os bloqueios de 0,7353 (SVM em 0,95) e 0,8176
(regressão logística em 0,95) foram recalculados do zero sobre `{modelo}_oof.json` e
reproduzem o documento até a quarta casa. O que o banco mostra — duas linhas em
`trained_models`, ambas da execução 1, `is_production` na regressão logística,
`train_oof_sensitivity` separada de `sensitivity`, `elapsed_ms` de 22/1/1 — é exatamente
o que o texto descreve.

A base é tratada como tabular de ponta a ponta: 569 registros, 32 colunas, 357 benignos e
212 malignos conferidos no arquivo, com a distinção entre medida extraída de imagem de FNA
e imagem de biópsia feita de forma explícita, e repetida como advertência de apresentação.
Nenhuma frase do documento descreve o sistema como processador de imagens.

Na rastreabilidade conferi as 12 linhas, não uma amostra: cada símbolo citado existe com
aquele nome — de `feature_schema` e `validar_caracteristicas` a `sensibilidade_oof`,
`promover_modelo`, `sha256_arquivo`, `_commit_git`, `ITENS_MENU`, `disclaimer-bar` com
`role="note"`, os quatro índices compostos e os listeners de imutabilidade. Os dois testes
citados como prova (`test_predict.py`, `test_sessao_obrigatoria.py`) fazem o que o texto
diz que fazem.

As imprecisões que restam são de atribuição e de escopo. A divergência pbkdf2/scrypt e a
ausência do handler de `INTERNAL_ERROR` são descritas com precisão, mas enquadradas como
texto a corrigir em vez de código pendente, contra o que a diretriz vigente decidiu — e o
próprio `services/auth.py` ainda tem "pbkdf2" na docstring, um terceiro ponto fora de
sincronia que o documento não registra. E a lista de sete pendências é apresentada como
exaustiva e vai servir de checklist à equipe, mas não cobre os requisitos que o professor
pediu para acrescentar ao Quadro 9 e ao Quadro 10.

<details>
<summary>Achados (3)</summary>

1. **Atribuição da afirmação de incidência** — a seção 1 credita "a Contextualização do
   documento de especificação do TCC" pela frase da neoplasia mais incidente; a frase está
   na Introdução (linha 30), não na Contextualização (que começa na linha 34). Trocar para
   "Introdução" ou para "o documento de especificação do TCC", sem mexer nas duas fontes
   citadas, que estão certas.
2. **"o código está correto" não vale para o item do hash** — o cabeçalho das pendências na
   seção 9 rotula os sete itens como redação do TCC a corrigir; o item 3 é a decisão D4 da
   `ESPECIFICACAO-CONSOLIDADA.md` (não do TCC) e a `DIRETRIZ-OBRIGATORIA.md` determinou
   fixar `method="pbkdf2:sha256"` no código. Reclassificar como pendência de implementação,
   registrar que a docstring de `services/auth.py` também diz pbkdf2, e dar o mesmo
   tratamento ao `INTERNAL_ERROR` da seção 8 (handler a implementar, não ressalva
   permanente).
3. **A lista exaustiva omite o item (b) do feedback** — faltam, nas listas das seções 6 e 9,
   os RFs/RNFs que o professor (item (b) e item (b) do "o que fazer") e a equipe pediram
   para incluir: login e perfis, PostgreSQL, paginação com filtros e a meta de
   sensibilidade de 0,97 — hoje implementados sem requisito correspondente nos Quadros 9 e
   10. Acrescentar o item e ajustar a contagem de "sete".

</details>

<details>
<summary>Detalhes</summary>

### Achado 1 — a afirmação de incidência está na Introdução, não na Contextualização

Confiança: **confirmado**.

A seção 1 abre com: "O câncer de mama é a neoplasia maligna mais incidente entre mulheres
no Brasil, excluídos os tumores de pele não melanoma (INCA, 2022; Muxagata et al., 2026 —
as duas fontes que a Contextualização do documento de especificação do TCC atribui a essa
afirmação...)".

A frase existe em `tcc-docs/01_documentacao_software.txt`, linha 30: "No cenário nacional,
excluindo-se os tumores de pele não melanoma, o câncer de mama é a neoplasia maligna mais
incidente entre as mulheres (INCA, 2022; MUXAGATA et al., 2026)". A linha 30 está na
**Introdução**; o cabeçalho `## Contextualização` só aparece na linha 34. As duas fontes
atribuídas estão corretas, e correspondem às entradas (4) e (5) da seção Referências do
`COMO-FUNCIONA.md` — INCA, *Estimativa 2023*, 2022 (linha 403 do TCC) e Muxagata et al.,
2026 (linha 406).

É erro de localização dentro do mesmo arquivo, com citação correta — não a classe que a
`DIRETRIZ-OBRIGATORIA.md` proíbe, já que nada foi fabricado. Pesa porque o documento faz
questão de dizer em que seção cada afirmação foi conferida, e este é o único ponto em que a
seção indicada está errada. As quatro porcentagens da mesma seção **estão** na
Contextualização (linhas 36 e 37), então a tabela de fontes do topo segue correta para elas.

Mudança: na seção 1, trocar "a Contextualização do documento de especificação do TCC
atribui" por "a Introdução do documento de especificação do TCC atribui". Nada mais nessa
frase muda.

### Achado 2 — a divergência do hash é tarefa de código, e o documento a rotula como texto

Confiança: **confirmado**.

O estado do código, reconferido: `services/auth.py:30` chama
`generate_password_hash(password)` sem o argumento `method`, e os hashes em
`users.password_hash` começam com `scrypt:32768:8:1$` (duas contas no banco de
demonstração). `app.py` não registra nenhum `errorhandler`, e `api/routes.py` registra
dois, para `ErroValidacao` e `ModeloIndisponivel` — logo não existe handler de
`INTERNAL_ERROR`/500. Ou seja: as duas tarefas dos itens 3 e 4 da
`DIRETRIZ-OBRIGATORIA.md` continuam abertas, como a revisão anterior já havia registrado.

O `COMO-FUNCIONA.md` descreve esse estado com precisão; o problema é o enquadramento, em
dois pontos:

- A seção 9 introduz a lista com "**Pendências de documento** (redação do TCC a corrigir;
  o código está correto)" e inclui ali o item "D4 descreve o hash da senha como pbkdf2, mas
  o código usa o padrão atual do `werkzeug.security`". D4 não é texto do TCC: é decisão da
  `.agents/ESPECIFICACAO-CONSOLIDADA.md` (linha 33, "Hash com `werkzeug.security`
  (pbkdf2)"). E a diretriz vigente, que tem precedência, decidiu o sentido da correção:
  fixar `method="pbkdf2:sha256"` na chamada, para o código corresponder ao que está
  documentado em três lugares. Dizer "o código está correto" sobre esse item contradiz a
  decisão em vigor. A seção 6, item 3, é mais honesta ("ou o código precisa fixar
  `method='pbkdf2:sha256'`"), mas o cabeçalho da seção 9 cobre o item inteiro.
- A "Ressalva de contrato" da seção 8 apresenta o `INTERNAL_ERROR` como "contrato previsto e
  não implementado" e conclui que "o envelope vale para os seis códigos acima, não para
  falha inesperada". A descrição é exata, mas a diretriz determinou acrescentar o handler e
  **não** enfraquecer o texto do contrato. Como está, o documento normaliza a lacuna.

Falta ainda um ponto conferível que o documento não menciona: a própria docstring de
`services/auth.py` afirma "sempre com `werkzeug.security` (pbkdf2)". São três lugares
dizendo pbkdf2 (D4, docstring do módulo e o texto do TCC) contra um comportamento scrypt.

Mudanças:
- Na seção 9, separar a lista em dois blocos ou ajustar o cabeçalho, de modo que o item do
  hash apareça como **pendência de implementação** (fixar `method="pbkdf2:sha256"`, ajustar
  teste que dependa do formato do hash), e não como redação do TCC.
- Na seção 6, item 3, registrar também a docstring de `services/auth.py` entre os pontos a
  convergir.
- Na seção 8, manter a descrição factual e acrescentar uma frase dizendo que o handler de
  `INTERNAL_ERROR` é tarefa de implementação pendente, e não uma redução deliberada do
  contrato.

### Achado 3 — a lista de pendências se declara completa e não cobre o item (b)

Confiança: **confirmado**.

A seção 6 encerra com "Isso deixa **pendências de documento** (...) — sete, todas de
redação a corrigir na versão final" e a seção 9 repete "São sete pendências de redação, as
mesmas listadas na seção 6". É a lista que a equipe vai usar como tarefas, e os sete itens
cobrem RNF05/FA01, a trava de sensibilidade da §4.2.4, o hash, as sobras do item (a), a
legenda da Figura 5, a Lista de Figuras vazia e o retry do FA02 do UC02 — todos conferidos
na fonte e corretos.

Falta a família do item (b) do feedback (`tcc-docs/03_feedback_professor.txt`, linhas
81–82 e, no "o que fazer", linha 96): "Os diagramas de sequência e a arquitetura descrevem
autenticação por perfil (...), banco PostgreSQL, paginação com filtros e promoção de modelo
condicionada a sensibilidade mínima de 0,97. Nada disso está nos 7 RFs nem nos 5 RNFs (o
RNF04 só diz 'priorizar minimizar falsos negativos', sem meta)". A mesma coisa está na
lista de mudanças da equipe pelo WhatsApp ("ADICIONAR NOS REQUISITOS: banco PostgreSQL,
paginação com filtros, promoção de modelo condicionada a sensibilidade mínima de 0,97").

Conferido no documento do TCC: o Quadro 9 (linhas 182–193) tem RF01–RF07 sem nenhum
requisito de login, perfis ou paginação, e o Quadro 10 (linhas 200–210) tem RNF01–RNF05 com
o RNF04 na redação sem meta numérica, e nenhum requisito de banco. Enquanto isso, o código
implementa sessão obrigatória (D10), `DATABASE_URL` para PostgreSQL (D5), histórico
paginado com filtros e o portão de 0,97 em `SENSIBILIDADE_MINIMA`. A rastreabilidade da
seção 9 cobre apenas RF01–RF07 e RNF01–RNF05, o que é coerente com a especificação atual —
mas significa que quatro comportamentos implementados e explicados no documento não têm
requisito nenhum apontando para eles, e a lista de pendências não avisa.

É omissão, não afirmação falsa: por isso não é bloqueante. Mas uma lista que se declara
exaustiva e serve de checklist precisa incluir o item.

Mudança: acrescentar às listas das seções 6 e 9 um item com a redação do item (b) — incluir
nos Quadros 9 e 10 os requisitos de login e perfis, banco PostgreSQL, paginação com filtros
e meta de sensibilidade de 0,97 no RNF04 — e corrigir "sete" para o novo total nos dois
lugares. Vale apontar, de passagem, que a seção 4 já explica a meta de 0,97 e a seção 7 já
descreve a paginação com filtros, então o texto do requisito pode sair daí.

### Observações que não são achados

**Mermaid.** Os quatro blocos foram inspecionados linha a linha: `flowchart TD` com quatro
`subgraph` fechados por `end` e arestas entre subgrafos; `sequenceDiagram` com `actor`,
quatro `participant` com alias entre parênteses, setas `->>`/`-->>` e auto-mensagens;
`flowchart TD` da promoção com losangos `{"..."}` e rótulos de aresta `|não|`/`|sim|`;
`flowchart LR` das telas. Todo texto com pontuação sensível (`—`, `(`, `)`, `{`, `}`, `>=`,
`/`, `·`, `<br/>`) está entre aspas e nenhum identificador colide com palavra reservada.
Não há renderizador Mermaid na máquina, então a conferência é estrutural e não uma
renderização — confiança **provável** de que renderiza sem erro.

**A caixa "Pergunta aberta para a equipe".** Cumpre o que a `DIRETRIZ-OBRIGATORIA.md`
autorizou: nenhuma contagem bruta, nenhuma subseção de artigo afirmada, nenhuma
recomendação de alterar o TCC. Mencionar que "os PDFs não foram abertos na elaboração deste
documento" é comentário sobre o processo de autoria dentro de um entregável, e poderia ser
reescrito como instrução à equipe sem perder a honestidade. Opcional.

**Pendências herdadas da revisão anterior.** Os seis achados de documento da rodada
anterior foram atendidos: o UC01 não é mais acusado de exemplos errados, o nome truncado
do dataset foi movido para o Abstract (com o Resumo registrado como correto), a abertura das
Referências passou a dizer que o TCC traz DOI na entrada da base, a Figura 5 e a Lista de
Figuras entraram nas pendências, o item (a) foi estreitado e a entrada (3) deixou de
afirmar leitura da lista de referências do artigo (2).

</details>

<details>
<summary>Mapa de conferências (números × fonte)</summary>

| Afirmação do documento | Fonte conferida | Resultado |
|---|---|---|
| 569 registros, 32 colunas, 357 benignos / 212 malignos | `data/wdbc.data` (contado) | confere |
| 30 características = 10 medidas × mean/se/worst | `ml/data.py` (`_MEDIDAS`, `MEDIDAS_PT`, `GRUPOS_PT`), `train_config.json:feature_names` | confere |
| margem de 20%, `unit` sempre nulo | `ml/data.py:feature_schema`, `MARGEM_FAIXA = 0.20` | confere |
| top-3 de importância: `worst_texture`, `worst_symmetry`, `worst_concavity` (depois `worst_concave_points`, `mean_concave_points`, `mean_concavity`); permutação, 30 repetições, log-loss no teste | `feature_importance.json` | confere |
| RL limiar 0,50: acc 0,9649 · sens 0,9286 · esp 0,9861 · AUC 0,9960 · FN 0,0714 · vn71 fp1 fn3 vp39 | `metrics.json:teste_padrao` | confere |
| RL limiar 0,31: acc 0,9825 · sens 0,9762 · esp 0,9861 · AUC 0,9960 · FN 0,0238 · vn71 fp1 fn1 vp41 | `metrics.json:teste_operacao`; `trained_models` id=1 | confere |
| SVM limiar 0,38: acc 0,9737 · sens 0,9524 · esp 0,9861 · AUC 0,9927 · FN 0,0476 · vn71 fp1 fn2 vp40 | `metrics.json`; `trained_models` id=2 | confere |
| SVM não atende à meta no teste; RL atende | `metrics.json:atende_meta_sensibilidade_teste` | confere |
| Limiares 0,31 e 0,38, ambos com `limiar_atingiu_meta_no_treino: true` | `metrics.json` | confere |
| Portão out-of-fold 0,970588 = 165/170, para os dois modelos | recalculado em `regressao_logistica_oof.json` (0,31) e `svm_oof.json` (0,38) | confere |
| Bloqueio do SVM em 0,95: 125/170 = 0,7353; RL em 0,95: 0,8176 | recalculado nos mesmos vetores (139/170 = 0,817647) | confere |
| CV 5 dobras: RL sens 0,9529 ± 0,0446; SVM 0,9588 ± 0,0446, medida no limiar 0,50 | `metrics.json:validacao_cruzada`; `ml/train.py:_cv_metrics` | confere |
| 455 treino (285/170) e 114 teste (72/42); 455 e 114 índices | `train_config.json`, `split.json` | confere |
| semente 42, `cv_folds = 5`, `grid_search: true` | `train_config.json`, `split.json:random_state` | confere |
| Python 3.14.6 · scikit-learn 1.9.1 · numpy 2.5.0 · joblib 1.6.0 | `train_config.json:versoes` | confere |
| commit `096bc547…`, SHA-256 do dataset `1121850321…` | `train_config.json` | confere |
| hiperparâmetros RL (`C=1`, `l2`, `lbfgs`, `max_iter=1000`) e SVM (`C=10`, `rbf`, `scale`, `probability=True`) | `train_config.json:hiperparametros`; `trained_models.hyperparameters` | confere |
| onze arquivos versionados em `ml/artifacts/`; `report/` e `runs/` ignorados | `git ls-files ml/artifacts` (11), `.gitignore` | confere |
| registro sintético grava `grid_search = 0` contra `grid_search: true` do artefato | `training_runs` id=1 no banco; `services/modelos.py:116` | confere |
| duas linhas em `trained_models`, ambas da execução 1, RL em produção, `artifact_path` em `ml/artifacts/` | `instance/tcc_cancer_mama.db` | confere |
| `train_oof_sensitivity` = 0,9706 separada de `sensitivity` = 0,9762 | mesma tabela | confere |
| `elapsed_ms` de 22, 1 e 1 ms nas três avaliações | `evaluations` | confere |
| hashes de senha em scrypt (`scrypt:32768:8:1$`) | `users.password_hash` | confere |
| modo identificado grava nome e prontuário em texto | `evaluations` id=3 (`Paciente Exemplo` / `PRONT-0001`) | confere |
| decisão por `P(maligno) >= limiar`, limiar do `melhor_modelo` do `metrics.json`, sem consultar o banco | `ml/predict.py:predict` | confere |
| faixas de confiança 0,90 / 0,70, valor `media` sem acento | `ml/predict.py:faixa_confianca`; `tests/test_predict.py` | confere |
| `safety_threshold_triggered` = maligno com P < 0,50 | `ml/predict.py` (`acionou_limiar_seguranca`) | confere |
| grade do limiar de 0,01 a 0,50, passo 0,01, de cima para baixo; fallback no mais cauteloso | `ml/train.py:escolher_limiar_seguranca` | confere |
| OOF com `StratifiedKFold(5, shuffle=True, random_state=42)` e `cross_val_predict` | `ml/train.py` (`cv`, `_oof_proba`) | confere |
| seis códigos de erro emitidos; nenhum handler de 500 | `api/routes.py`, `app.py`, `services/validation.py` | confere |
| 504 `TIMEOUT` sem gravar; `LIMITE_TEMPO_MS = 2000` | `api/routes.py:criar_predicao` | confere |
| portão lê `{modelo}_oof.json`, métricas de teste de `{modelo}_test_proba.json`, 503 sem artefato, nada gravado no bloqueio | `api/routes.py:ajustar_threshold`, `services/modelos.py` | confere |
| `test_size`/`test_set_size`/`test_set_malignant` da própria matriz; `gate_meets_sensitivity_target` × `meets_sensitivity_target`; `test_partitions_mixed` | `api/routes.py:comparar_modelos` | confere |
| filtros do histórico: `page` 1, `limit` 25 (máx. 100), `date_to` inclusiva | `services/validation.py` | confere |
| sem filtro por autoria; `patient_name`/`patient_record` expostos a qualquer sessão | `services/avaliacoes.py:listar`, `db/models.py:Evaluation.to_dict` | confere |
| unicidade `(training_run_id, name)`; `artifact_sha256` sem `unique` | `db/models.py` | confere |
| imutabilidade por `before_update` / `before_delete` | `db/models.py` | confere |
| senha mínima de 8 caracteres; cadastro abre sessão | `services/validation.py:SENHA_MINIMA`, `services/auth.py:register` | confere |
| menu por perfil sem trava; Histórico nos dois perfis | `frontend/src/App.jsx:ITENS_MENU` | confere |
| CSV aceita cabeçalho, 30 valores ou formato original do WDBC | `frontend/src/pages/ClassificarPage.jsx:parseCsv` | confere |
| GridSearchCV 5 dobras, `scoring="recall"` | `ml/train.py` (`PARAM_GRIDS`, `GridSearchCV`) | confere |
| figuras em 300 DPI | `ml/report.py:DPI = 300` | confere |
| 12 linhas da rastreabilidade (RF01–RF07, RNF01–RNF05) | todos os arquivos e símbolos citados | confere |
| UC01 lista as dez medidas nas três variações | TCC, Quadro 2, linha 94 | confere |
| Abstract escreve "Wisconsin Diagnostic Breast Dataset"; Resumo correto | TCC, linhas 23 e 20 | confere |
| Introdução fala em "imagens de biópsia", parágrafo seguinte diz "tabular" | TCC, linhas 31 e 32 | confere |
| §4.2.4 enuncia a trava "no conjunto de teste"; o diagrama não qualifica a partição | TCC, linha 341; `tcc-docs/figuras/doc_image4.png` (ramos "Sensibilidade >= 0.97" / "< 0.97") | confere |
| legendas: Figura 5 "Histórico e Auditoria"; Figura 6 "Módulo de Autenticação" | TCC, linhas 336 e 343 | confere |
| Lista de Figuras, de Quadros e Sumário vazios | TCC, linhas 25–27 | confere |
| HT01–HT03 no Quadro 12; HT03 "Configuração dos perfis de médico e pesquisador" | TCC, linhas 239–245 | confere |
| Quadro 11 mapeia US01→RF01 … US07→RF07 e nada de RNF | TCC, linhas 218–230 | confere |
| FA02 do UC02 promete nova tentativa | TCC, Quadro 3, linha 108 | confere |
| 26,6% · 20–25% · 74,2% · 18,4% na Contextualização | TCC, linhas 36 e 37 | confere |
| referências (1) a (5), com DOI só na entrada da base | TCC, linhas 398–407 | confere |
| afirmação de incidência atribuída à Contextualização | TCC, linha 30 (**Introdução**) | **achado 1** |
| D1–D12 | `.agents/ESPECIFICACAO-CONSOLIDADA.md` | confere |
| seção 11 do `design.md` (`media` sem acento, chaves de `split.json`, `roc_points`, 201 com `status failed`, `top`, 503 sem artefato) | `.agents/tasks/mvp-alinhado/design.md` §11 | sem contradição |

</details>
