"""
Verificacao de runtime (item 4 da checklist): exercita a API real com sessao.

Nao altera codigo de producao. Escreve apenas em stdout; o chamador redireciona.
Uso: python .agents/tasks/correcoes-metricas-documentacao/verificar_runtime.py
"""
import http.cookiejar
import json
import os
import sys
import urllib.error
import urllib.request

BASE = "http://127.0.0.1:5000/api/v1"
EMAIL = "verificador@demo.local"
SENHA = "demo12345"

jar = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

falhas = []


def chamar(metodo, caminho, corpo=None):
    dados = None if corpo is None else json.dumps(corpo).encode("utf-8")
    req = urllib.request.Request(BASE + caminho, data=dados, method=metodo)
    if dados is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with opener.open(req, timeout=300) as r:
            bruto = r.read().decode("utf-8")
            return r.status, (json.loads(bruto) if bruto else None)
    except urllib.error.HTTPError as e:
        bruto = e.read().decode("utf-8")
        return e.code, (json.loads(bruto) if bruto else None)


def checar(rotulo, condicao, detalhe=""):
    marca = "PASSOU" if condicao else "FALHOU"
    if not condicao:
        falhas.append(rotulo)
    print(f"  [{marca}] {rotulo}" + (f" -- {detalhe}" if detalhe else ""))


def quase(a, b, tol=1e-6):
    return a is not None and b is not None and abs(a - b) <= tol


def invariante(rotulo, linha):
    """sensitivity==vp/(vp+fn), specificity==vn/(vn+fp), accuracy==(vp+vn)/total,
    false_negative_rate==fn/(vp+fn) -- tudo contra a propria matriz da linha."""
    cm = linha.get("confusion_matrix")
    if not cm:
        checar(f"{rotulo}: matriz de confusao presente", False)
        return
    vn, fp, fn, vp = cm["vn"], cm["fp"], cm["fn"], cm["vp"]
    mal, ben, tot = vp + fn, vn + fp, vn + fp + fn + vp
    print(f"    matriz={cm} total={tot} malignos={mal}")
    print(f"    acc={linha['accuracy']:.6f} sens={linha['sensitivity']:.6f} "
          f"esp={linha['specificity']:.6f} fn_rate={linha['false_negative_rate']:.6f} "
          f"auc={linha['auc']:.6f} limiar={linha['threshold']} "
          f"oof_treino={linha.get('train_oof_sensitivity')}")
    checar(f"{rotulo}: sensitivity == vp/(vp+fn)", quase(linha["sensitivity"], vp / mal),
           f"{linha['sensitivity']:.6f} vs {vp / mal:.6f}")
    checar(f"{rotulo}: specificity == vn/(vn+fp)", quase(linha["specificity"], vn / ben),
           f"{linha['specificity']:.6f} vs {vn / ben:.6f}")
    checar(f"{rotulo}: accuracy == (vp+vn)/total", quase(linha["accuracy"], (vp + vn) / tot),
           f"{linha['accuracy']:.6f} vs {(vp + vn) / tot:.6f}")
    checar(f"{rotulo}: false_negative_rate == fn/(vp+fn)",
           quase(linha["false_negative_rate"], fn / mal),
           f"{linha['false_negative_rate']:.6f} vs {fn / mal:.6f}")
    checar(f"{rotulo}: sens + fn_rate == 1",
           quase(linha["sensitivity"] + linha["false_negative_rate"], 1.0))


def linha(nome):
    _, corpo = chamar("GET", "/models")
    for m in corpo["items"]:
        if m["name"] == nome:
            return m
    return None


# ----------------------------------------------------------------------
print("=== 0. autenticacao (sessao exigida) ===")
st, _ = chamar("GET", "/models")
checar("GET /models sem sessao devolve 401", st == 401, f"HTTP {st}")

st, c = chamar("POST", "/auth/register", {
    "name": "Verificador", "email": EMAIL, "password": SENHA, "profile": "pesquisador",
})
print(f"  register -> HTTP {st}")
st, c = chamar("POST", "/auth/login", {"email": EMAIL, "password": SENHA})
checar("POST /auth/login devolve 200", st == 200, f"HTTP {st} {c}")
st, c = chamar("GET", "/auth/me")
checar("GET /auth/me confirma sessao", st == 200, json.dumps(c))

st, c = chamar("GET", "/models")
checar("GET /models com sessao devolve 200", st == 200, f"HTTP {st}")
print("  modelos: " + ", ".join(
    f"id={m['id']} {m['name']} limiar={m['threshold']} path={m['artifact_path']}"
    for m in c["items"]))

alvo = linha("regressao_logistica")
alvo_id = alvo["id"]
auc_antes = alvo["auc"]
esp_antes = alvo["specificity"]
fp_antes = alvo["confusion_matrix"]["fp"]
print(f"  alvo: id={alvo_id} regressao_logistica limiar={alvo['threshold']} "
      f"esp={esp_antes:.6f} fp={fp_antes}")

# ----------------------------------------------------------------------
print("\n=== 1. PUT /models/{id}/threshold com limiar extremo 0.01 ===")
st, c = chamar("PUT", f"/models/{alvo_id}/threshold", {"threshold": 0.01})
print(f"  HTTP {st}")
print("  resposta: " + json.dumps(c, ensure_ascii=False))
checar("limiar 0.01 devolve 200", st == 200, f"HTTP {st}")
checar("resposta traz train_oof_sensitivity (campo proprio do portao)",
       isinstance(c, dict) and "train_oof_sensitivity" in c)
checar("resposta traz bloco test_metrics", isinstance(c, dict) and "test_metrics" in c)
checar("resposta NAO tem a chave ambigua 'sensitivity' de topo",
       isinstance(c, dict) and "sensitivity" not in c)

depois = linha("regressao_logistica")
invariante("linha apos limiar 0.01", depois)
checar("sensitivity gravada == test_metrics.sensitivity (teste, nao o portao)",
       quase(depois["sensitivity"], c["test_metrics"]["sensitivity"], 1e-9),
       f"{depois['sensitivity']} vs {c['test_metrics']['sensitivity']}")
checar("train_oof_sensitivity gravado == portao da resposta",
       quase(depois["train_oof_sensitivity"], c["train_oof_sensitivity"], 1e-4))
checar("sensibilidade out-of-fold NAO esta na coluna sensitivity",
       not quase(depois["sensitivity"], depois["train_oof_sensitivity"], 1e-9)
       or quase(c["train_oof_sensitivity"], c["test_metrics"]["sensitivity"], 1e-4),
       f"sens_teste={depois['sensitivity']:.6f} oof={depois['train_oof_sensitivity']}")
checar("especificidade CAIU com o limiar 0.01 (defeito A: nao ficou a do limiar antigo)",
       depois["specificity"] < esp_antes, f"{esp_antes:.6f} -> {depois['specificity']:.6f}")
checar("falsos positivos AUMENTARAM com o limiar 0.01",
       depois["confusion_matrix"]["fp"] > fp_antes,
       f"fp {fp_antes} -> {depois['confusion_matrix']['fp']}")
checar("auc inalterada (independe do limiar)", quase(depois["auc"], auc_antes, 1e-9))

print("\n  -- toda a tabela apos o PUT --")
_, todos = chamar("GET", "/models")
for m in todos["items"]:
    invariante(f"id={m['id']} {m['name']}", m)

# ----------------------------------------------------------------------
print("\n=== 2. PUT /models/{id}/threshold com limiar extremo 0.99 (portao de 0,97) ===")
antes_099 = linha("regressao_logistica")
st, c = chamar("PUT", f"/models/{alvo_id}/threshold", {"threshold": 0.99})
print(f"  HTTP {st}")
print("  resposta: " + json.dumps(c, ensure_ascii=False))
checar("limiar 0.99 bloqueado com HTTP 400", st == 400, f"HTTP {st}")
checar("codigo SENSITIVITY_BELOW_TARGET", isinstance(c, dict) and c.get("code") == "SENSITIVITY_BELOW_TARGET",
       json.dumps(c, ensure_ascii=False))
checar("erro informa obtained < required = 0.97",
       isinstance(c, dict) and c.get("obtained") is not None and c.get("required") == 0.97
       and c["obtained"] < 0.97, json.dumps(c, ensure_ascii=False))
depois_099 = linha("regressao_logistica")
checar("bloqueio nao gravou nada (linha identica)", depois_099 == antes_099)
invariante("linha apos o 400 de 0.99", depois_099)

print("\n=== 2b. PUT com 0.95 (caso da demo: portao abaixo da meta) ===")
st, c = chamar("PUT", f"/models/{alvo_id}/threshold", {"threshold": 0.95})
print(f"  HTTP {st} resposta: {json.dumps(c, ensure_ascii=False)}")
checar("limiar 0.95 tambem bloqueia com 400 SENSITIVITY_BELOW_TARGET",
       st == 400 and isinstance(c, dict) and c.get("code") == "SENSITIVITY_BELOW_TARGET")

# ----------------------------------------------------------------------
print("\n=== 3. POST /api/v1/training-runs: artifact_path no diretorio da execucao ===")
st, c = chamar("POST", "/training-runs", {
    "models": ["regressao_logistica", "svm"], "test_size": 0.3, "grid_search": False,
})
print(f"  HTTP {st} resposta: {json.dumps(c, ensure_ascii=False)}")
checar("POST /training-runs devolve 201", st == 201, f"HTTP {st}")
checar("status success", isinstance(c, dict) and c.get("status") == "success")
run_id = c["training_run_id"]

st, run = chamar("GET", f"/training-runs/{run_id}")
checar(f"GET /training-runs/{run_id} devolve 200", st == 200, f"HTTP {st}")
esperado_prefixo = f"ml/artifacts/runs/{run_id}/"
for m in run["models"]:
    print(f"  modelo {m['name']}: artifact_path={m['artifact_path']}")
    checar(f"artifact_path de {m['name']} fica em {esperado_prefixo}",
           str(m["artifact_path"]).replace("\\", "/").startswith(esperado_prefixo),
           m["artifact_path"])
    checar(f"artifact_path de {m['name']} NAO aponta para a referencia ml/artifacts/{m['name']}.joblib",
           str(m["artifact_path"]).replace("\\", "/") != f"ml/artifacts/{m['name']}.joblib")
    caminho = os.path.join(*str(m["artifact_path"]).replace("\\", "/").split("/"))
    checar(f"artefato de {m['name']} existe em disco", os.path.exists(caminho), caminho)
    invariante(f"linha da execucao {run_id} / {m['name']}", m)

# ----------------------------------------------------------------------
print("\n=== 4. GET /models/comparison: composicao do teste por execucao ===")
st, comp = chamar("GET", "/models/comparison")
checar("GET /models/comparison devolve 200", st == 200, f"HTTP {st}")
print(f"  test_partitions_mixed={comp['test_partitions_mixed']}")
print(f"  test_partitions={json.dumps(comp['test_partitions'], ensure_ascii=False)}")
for m in comp["models"]:
    op = m["operating_point"]
    print(f"  {m['name']:22s} run={m['training_run_id']} test_size={m['test_size']} "
          f"teste={m['test_set_size']} malignos={m['test_set_malignant']} "
          f"limiar={m['threshold']} sens_teste={op['sensitivity']:.6f} "
          f"oof_treino={m['train_oof_sensitivity']} path={m['artifact_path']}")
    cm = op["confusion_matrix"]
    checar(f"{m['name']}: test_set_size == vn+fp+fn+vp da propria linha",
           m["test_set_size"] == cm["vn"] + cm["fp"] + cm["fn"] + cm["vp"])
    checar(f"{m['name']}: test_set_malignant == vp+fn da propria linha",
           m["test_set_malignant"] == cm["vp"] + cm["fn"])
    checar(f"{m['name']}: train_oof_sensitivity e campo separado", "train_oof_sensitivity" in m)
checar("mistura de particoes sinalizada depois do treino 70/30",
       comp["test_partitions_mixed"] is True, str(comp["test_partitions_mixed"]))

print("\n=== RESUMO ===")
print(f"  verificacoes com falha: {len(falhas)}")
for f in falhas:
    print(f"    - {f}")
sys.exit(1 if falhas else 0)
