# Notas de implementação — correções pós-revisão (iteração 1)

Branch `feat/mvp-alinhado-documentacao`, HEAD `b96c97c`. **Nenhum commit foi
feito nesta etapa** (uma etapa posterior do workflow cuida disso). Os dois
scripts não rastreados `.agents/preparar_demo.py` e `.agents/comparar_artefatos.py`
continuam não rastreados e inalterados.

Não havia `revisao-correcoes.json` quando esta etapa começou, logo esta é a
primeira iteração: as duas entregas foram implementadas do zero, seguindo
`plano-correcoes.md` (itens 1 a 15; o item 16, de commits, fica para a etapa
seguinte).

---

## Arquivos alterados

| Arquivo | O que mudou |
|---|---|
| `ml/train.py` | `RUNS_DIR`, `diretorio_execucao(training_run_id)`, `output_dir` no retorno de `train_and_evaluate`, docstrings declarando `ml/artifacts/` como referência versionada e a linha impressa no `__main__` |
| `services/modelos.py` | `caminho_relativo` extraído de `_caminho_artefato`; `diretorio_artefatos_do_registro`; `concluir_training_run_sucesso` resolve o diretório por `resultado["output_dir"]`; registro reaproveitado por hash mantém o `artifact_path` estável |
| `api/routes.py` | decorador `exigir_sessao` + aplicação nas 11 rotas de dados; `POST /training-runs` com `output_dir=diretorio_execucao(run.id)`, `gerar_figuras(artifacts_dir=...)`, sem `clear_cache()`, resposta com `artifacts_dir`; promoção lê o OOF do diretório do registro; `artifact_path` em `/models/comparison` |
| `.gitignore` | `ml/artifacts/runs/` |
| `tests/base.py` | limpeza das pastas de `ml/artifacts/runs/` no `tearDown`; nova `ApiAutenticadoTestCase` |
| `tests/test_training.py` | base autenticada; 4 testes de isolamento de artefatos; 1 teste de promoção lendo o OOF da execução |
| `tests/test_predictions.py` | base autenticada; asserção de `user_id` da sessão |
| `tests/test_sessao_obrigatoria.py` (novo) | 401 sem sessão em toda rota `/api/v1` fora de `/auth` (varredura do `url_map`), `/auth/*` e `/health` públicas, 200 com sessão, médico↔pesquisador sem trava |
| `README.md` | aviso de segurança reescrito, coluna "Sessão" na tabela da API, `ml/artifacts/runs/` no mapa de pastas, distinção `python -m ml.train` × treino pela API, decisões D8/D9/D10 |
| `.agents/ESPECIFICACAO-CONSOLIDADA.md` | nota em D3, decisões D8/D9/D10, seção 4 (`artifact_path` por execução), seção 5 (401 nas rotas de dados, `artifacts_dir`, `artifact_path`), seção 6 (RNF03 e exportação), seção 8 (verificação do RNF03), seção 9 (aviso de segurança) |
| `.agents/tasks/mvp-alinhado/design.md` | 3 notas datadas em §4.3, §5.1 e §5.3. **Seção 11 intocada** (`git diff` mostra hunks só nas linhas 716, 808 e 843) |
| `.agents/RELATORIO-IMPLEMENTACAO.md` | nova seção 2.5 com os dois defeitos (sintoma, evidência, causa, correção, verificação); RNF03/RNF05 atualizados; contagem 76 → 86; nota pós-testes removida de 3.1; pendência "Isolamento de testes" marcada como resolvida; roteiro 3.2 (passos 1 e 5); seção 6 |

**Frontend: nenhuma alteração.** A verificação por leitura confirmou que
`frontend/src/api.js` envia `credentials: "include"` em todas as chamadas e que
`ClassificarPage`/`HistoricoPage`/`ModelosPage` são montadas dentro de
`RotaProtegida` (`App.jsx`), que devolve `null` enquanto `GET /auth/me` está em
voo e redireciona para `/login` sem usuário — logo o `useEffect` com
`getFeatureSchema()` da tela Classificar só roda com a sessão já estabelecida.
Nenhuma tela chama rota de dados antes do login, e o build confirmou que nada
quebrou.

---

## Comandos executados e resultado

### 1. Suíte de testes

```
cd c:\Users\isaiaslm\tcc-cancer-mama
python -m unittest discover -s tests -t . -v
```

```
Ran 86 tests in 48.6s
OK
```

86 testes, zero falhas e zero erros (eram 76 antes). Avisos de stderr
pré-existentes e não bloqueantes: `SECRET_KEY não configurada` em ambiente de
teste e `FutureWarning` do scikit-learn.

Depois da suíte, `git status --porcelain ml/artifacts` → **vazio**, e
`ml/artifacts/runs/` não sobrou (limpeza no `tearDown`).

### 2. Pipeline de ML pela linha de comando

```
python -m ml.train
```

Imprimiu a nova linha
`Regenerando os artefatos de referência em ml/artifacts/ (RNF03 — split 80/20, semente 42)`
e reproduziu exatamente os números documentados:

```
Melhor modelo: regressao_logistica
regressao_logistica  teste_padrao    limiar=0.50 acc=0.9649 sens=0.9286 esp=0.9861 auc=0.9960 FN=0.0714
regressao_logistica  teste_operacao  limiar=0.31 acc=0.9825 sens=0.9762 esp=0.9861 auc=0.9960 FN=0.0238
svm                  teste_padrao    limiar=0.50 acc=0.9737 sens=0.9286 esp=1.0000 auc=0.9927 FN=0.0714
svm                  teste_operacao  limiar=0.38 acc=0.9737 sens=0.9524 esp=0.9861 auc=0.9927 FN=0.0476
```

Os `.joblib`, `split.json` e os `_oof.json` saíram **byte-a-byte idênticos** aos
commitados; só `metrics.json` e `train_config.json` diferiram, nos campos
`gerado_em` e `commit_git` (HEAD mudou de `096bc547` para `b96c97c`). Como a
referência commitada precisa ficar intacta nesta etapa, os dois arquivos foram
restaurados com `git checkout -- ml/artifacts` e o report foi regerado em
seguida:

```
python -m ml.report
```

Saída: os 4 PNG em 300 DPI + `metricas.csv` em `ml/artifacts/report/` (diretório
já ignorado pelo git). Estado final confirmado: `test_size=0.2`,
`commit_git=096bc547`, RL limiar 0,31 / sens 0,9762, SVM limiar 0,38 /
sens 0,9524, e `git status --porcelain ml/artifacts` **vazio**.

### 3. Build do frontend

```
cd frontend; npm install; npm run build
```

```
vite v5.4.21 building for production...
✓ 44 modules transformed.
dist/index.html                   0.43 kB
dist/assets/index-ReDIXq6o.css   13.54 kB
dist/assets/index-BVFTWZAz.js   202.44 kB
✓ built in 9.02s
```

Build limpo. O `npm install` repetiu o aviso pré-existente de `npm audit`
(4 vulnerabilidades em dependências transitivas de desenvolvimento), que não
afeta o build.

### 4. Verificação pontual contra o servidor real

Executada com `python app.py` no ar, por script temporário (já removido) usando
`urllib` + `CookieJar`. A verificação completa de runtime é da etapa seguinte;
esta serviu para confirmar as duas correções ponta a ponta.

Sem nenhum cookie de sessão:

```
GET   /api/v1/predictions                -> 401 UNAUTHENTICATED
GET   /api/v1/features/schema            -> 401 UNAUTHENTICATED
GET   /api/v1/models                     -> 401 UNAUTHENTICATED
POST  /api/v1/training-runs              -> 401 UNAUTHENTICATED
GET   /api/v1/models/export?format=csv   -> 401 UNAUTHENTICATED
GET   /health                            -> 200
```

Com sessão (cadastro como **médico**, para exercitar D3):

```
login/register                           -> 201
GET   /api/v1/features/schema            -> 200
GET   /api/v1/predictions                -> 200
GET   /api/v1/models                     -> 200
GET   /api/v1/models/export?format=csv   -> 200
POST  /api/v1/training-runs (test_size=0.3, ambos os modelos)
   -> 201 {"training_run_id": 7, "status": "success",
           "artifacts_dir": "ml/artifacts/runs/7"}
```

O médico autenticado chamou a rota do pesquisador sem nenhuma trava, como D3
determina.

Depois desse treino real com `test_size=0.3`:

```
git status --porcelain ml/artifacts   -> vazio (referência intacta)
ml/artifacts/runs/7/train_config.json -> test_size = 0.3
ml/artifacts/train_config.json        -> test_size = 0.2
ml/artifacts/runs/7/                  -> metrics.json, train_config.json, split.json,
                                         scaler.joblib, os 2 .joblib, os 2 _oof.json,
                                         feature_importance.json e report/
```

É exatamente o defeito 1 reproduzido e agora contido: antes, esse mesmo POST
levava a RL para limiar 0,32 / sens 0,9688 e o SVM para limiar 0,21 /
acc 0,9591 dentro de `ml/artifacts/`.

`python .agents\preparar_demo.py` (script do usuário, **não editado**) continuou
funcionando ponta a ponta: login 200, caso maligno
→ maligno (prob 1,0000, limiar 0,31, 12 ms), caso benigno → benigno (0,0638),
caso identificado 200, promoção do SVM em 0,95 bloqueada com
`SENSITIVITY_BELOW_TARGET` (`obtained` 0,7353 / `required` 0,97) e histórico com
10 avaliações.

Ao final: servidor derrubado, script temporário e `ml/artifacts/runs/` removidos.

---

## Desvios do plano, com justificativa

1. **Item 16 (commits) não executado.** A instrução desta etapa proíbe commits,
   push e PR; os commits ficam para a etapa posterior do workflow. Todas as
   alterações estão na árvore de trabalho.
2. **Item 5, teste de promoção.** O plano previa `sensitivity == 1.0` com
   `threshold=0.01`; o valor real medido é **0,9865** (há probabilidades OOF de
   malignos abaixo de 0,01). A asserção ficou `assertGreaterEqual(..., 0.97)`
   com status 200, o que preserva o propósito do teste: só é possível responder
   200 se o OOF de `runs/{run_id}/` foi encontrado — com o diretório errado, a
   rota devolveria 503 `MODEL_UNAVAILABLE`.
3. **`python -m ml.train` seguido de restauração.** A verificação mínima exige
   rodar o comando, mas a referência commitada (`096bc547`) tem de ficar intacta
   nesta etapa. Rodou-se o comando (saída registrada acima) e restaurou-se
   `ml/artifacts` em seguida; a diferença estava apenas em `gerado_em` e
   `commit_git`.
4. **Observação sobre `ml/__pycache__/*.pyc`.** Três `.pyc` estão **rastreados**
   no repositório desde antes desta correção
   (`ml/__pycache__/{__init__,data,train}.cpython-314.pyc`) e aparecem como
   modificados sempre que o Python recompila `ml/train.py`. Foram restaurados com
   `git checkout -- ml/__pycache__` para deixar a árvore limpa. **Não devem ser
   incluídos nos commits**; destrackeá-los é mudança fora do escopo destas duas
   entregas.

---

## Estado final da árvore

```
 M .agents/ESPECIFICACAO-CONSOLIDADA.md
 M .agents/RELATORIO-IMPLEMENTACAO.md
 M .agents/tasks/mvp-alinhado/design.md
 M .gitignore
 M README.md
 M api/routes.py
 M ml/train.py
 M services/modelos.py
 M tests/base.py
 M tests/test_predictions.py
 M tests/test_training.py
?? .agents/comparar_artefatos.py      <- script do usuário, não tocar
?? .agents/preparar_demo.py           <- script do usuário, não tocar
?? .agents/tasks/correcoes-pos-revisao/
?? tests/test_sessao_obrigatoria.py
```

Nenhuma linha de `ml/artifacts/`: a referência versionada do artigo continua
igual ao commit `096bc547`.
