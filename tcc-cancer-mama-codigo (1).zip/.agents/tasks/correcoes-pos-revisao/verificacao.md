# Verificação das correções pós-revisão

Repositório: `c:\Users\isaiaslm\tcc-cancer-mama`, branch `feat/mvp-alinhado-documentacao`,
HEAD `b96c97c`. Ambiente: Windows / PowerShell, Python 3.14.6, scikit-learn 1.9.1,
Node + Chrome instalados. Data da verificação: 22/10/2026.

Esta etapa **não alterou código de produção e não fez commits**. As únicas escritas no
repositório foram: os PNG em `.agents/tasks/correcoes-pos-revisao/screenshots/` (dentro de
um diretório que já era não rastreado), os artefatos descartáveis de `ml/artifacts/runs/`
(ignorados pelo git e removidos no fim) e dados de demonstração no SQLite de
desenvolvimento `instance/tcc_cancer_mama.db` (ignorado pelo git).

**Placar: 12 PASSOU · 1 FALHOU (item 4e, parcial) · 0 NÃO VERIFICADO.**
Além disso, 3 observações sem veredito próprio (seção "Observações").

| Item | Verificação | Veredito |
|---|---|---|
| 1 | Suíte de testes | PASSOU |
| 2 | `python -m ml.train` e `python -m ml.report` | PASSOU |
| 3 | `npm install` + `npm run build` | PASSOU |
| 4a | 401 `UNAUTHENTICATED` sem sessão | PASSOU |
| 4b | `/api/v1/auth/*` públicas | PASSOU |
| 4c | 200 com sessão válida | PASSOU |
| 4d | Sem autorização por perfil (D3) | PASSOU |
| 4e | Treino sob demanda não altera a referência | PASSOU |
| 4e (cont.) | `artifact_path` da execução + promoção | **FALHOU** no banco de demonstração herdado; PASSOU em banco limpo |
| 4f | 400 `SENSITIVITY_BELOW_TARGET` | PASSOU |
| 5 | As 4 telas no navegador | PASSOU |
| 6 | Scripts do usuário intactos | PASSOU |
| 7 | Métricas de `ml/artifacts/metrics.json` | PASSOU (fonte conferida abaixo) |

---

## 1. Suíte de testes — PASSOU

```
cd c:\Users\isaiaslm\tcc-cancer-mama
python -m unittest discover -s tests -t . -v
```

Saída final (execução completa, duas vezes, com o mesmo resultado):

```
Ran 86 tests in 32.783s
OK
```

`EXITCODE=0` (medido com redirecionamento de stdout/stderr para arquivo, para não
confundir o código de saída com o stderr do `unittest`).

- **86 testes, 0 falhas, 0 erros.** Eram 76 antes das correções.
- Os testes novos de 401/200 estão presentes em `tests/test_sessao_obrigatoria.py` e
  passaram:
  - `TestSessaoObrigatoria.test_todas_as_rotas_de_dados_devolvem_401_sem_sessao`
  - `TestSessaoObrigatoria.test_rotas_de_auth_continuam_publicas`
  - `TestRotasDeDadosComSessao.test_com_sessao_as_rotas_de_dados_respondem_normalmente`
  - `TestSemAutorizacaoPorPerfil.test_medico_acessa_rotas_de_pesquisador`
  - `TestSemAutorizacaoPorPerfil.test_pesquisador_acessa_rota_de_classificacao`
- Os testes de isolamento de artefatos de `tests/test_training.py` também passaram
  (`test_treino_sob_demanda_nao_altera_os_artefatos_de_referencia`,
  `test_artefatos_do_run_ficam_no_diretorio_da_execucao`,
  `test_resposta_informa_o_diretorio_da_execucao`,
  `test_figuras_do_run_nao_sobrescrevem_o_report_de_referencia`,
  `test_promocao_le_o_oof_do_diretorio_da_execucao`).
- Avisos pré-existentes e não bloqueantes no stderr: `SECRET_KEY não configurada` (ambiente
  de teste) e `FutureWarning` do scikit-learn sobre `penalty` na regressão logística.
- Depois da suíte: `git status --porcelain ml/artifacts` **vazio** e
  `ml/artifacts/runs/` inexistente (limpeza do `tearDown` funcionando).

## 2. Pipeline de ML pela linha de comando — PASSOU

```
cd c:\Users\isaiaslm\tcc-cancer-mama
python -m ml.train
```

`EXITCODE=0`. Saída:

```
Regenerando os artefatos de referência em ml/artifacts/ (RNF03 - split 80/20, semente 42)
Melhor modelo: regressao_logistica
regressao_logistica  teste_padrao    limiar=0.50 acc=0.9649 sens=0.9286 esp=0.9861 auc=0.9960 FN=0.0714
regressao_logistica  teste_operacao  limiar=0.31 acc=0.9825 sens=0.9762 esp=0.9861 auc=0.9960 FN=0.0238
svm                  teste_padrao    limiar=0.50 acc=0.9737 sens=0.9286 esp=1.0000 auc=0.9927 FN=0.0714
svm                  teste_operacao  limiar=0.38 acc=0.9737 sens=0.9524 esp=0.9861 auc=0.9927 FN=0.0476
```

Reproduz exatamente os números documentados. Comparação de SHA-256 dos 9 arquivos de
`ml/artifacts/` antes e depois: **7 idênticos byte-a-byte** (`split.json`, `scaler.joblib`,
os dois `.joblib`, os dois `_oof.json`, `feature_importance.json`); só `metrics.json` e
`train_config.json` mudaram, e apenas nos campos de metadado:

```
git diff -U0 -- ml/artifacts
-  "gerado_em": "2026-10-14T20:25:56.084610+00:00"
+  "gerado_em": "2026-10-22T16:35:29.025459+00:00"
-  "commit_git": "096bc54787318a90f40840bd51644a43b6dd4bab"
+  "commit_git": "b96c97cce558e36dbd8aa9f8ce6a3372d1a591f3"
```

Como esta etapa não pode alterar a referência versionada, os dois arquivos foram
restaurados (`git checkout -- ml/artifacts`) e `git status --porcelain ml/artifacts`
voltou a ficar vazio. Em seguida:

```
python -m ml.report
```

`EXITCODE=0`, stderr vazio, gerou os 5 arquivos em `ml/artifacts/report/`
(diretório já ignorado pelo git): `roc_comparacao.png`, `matrizes_confusao.png`,
`importancia_regressao_logistica.png`, `importancia_svm.png`, `metricas.csv`.
`git status --porcelain` depois dos dois comandos: nenhuma linha de `ml/artifacts/`.

## 3. Build do frontend — PASSOU

```
cd c:\Users\isaiaslm\tcc-cancer-mama\frontend; npm install; npm run build
```

```
up to date, audited 67 packages in 2s
EXIT_INSTALL=0
vite v5.4.21 building for production...
✓ 44 modules transformed.
dist/index.html                   0.43 kB │ gzip:  0.29 kB
dist/assets/index-ReDIXq6o.css   13.54 kB │ gzip:  3.24 kB
dist/assets/index-BVFTWZAz.js   202.44 kB │ gzip: 65.02 kB
✓ built in 11.93s
EXIT_BUILD=0
```

Build limpo, sem warning de compilação. O `npm install` repete o aviso pré-existente de
`npm audit` (4 vulnerabilidades, 3 moderadas e 1 alta, em dependências transitivas de
desenvolvimento do Vite); não afeta o build nem o artefato publicado.

## 4. Servidor real

Porta descoberta em `app.py` linha 109 (`create_app().run(debug=True, port=5000)`) e
confirmada no `README.md` ("Sobe na porta 5000"). O servidor foi subido em segundo plano
com `Start-Process python app.py` em `c:\Users\isaiaslm\tcc-cancer-mama` e as requisições
foram feitas contra `http://127.0.0.1:5000` (o nome `localhost` resolve para `::1` nesta
máquina e o Flask só escuta em `127.0.0.1`). As requisições foram disparadas por um script
temporário com `urllib` + `CookieJar` (fora do repositório, já removido), que é o
equivalente ao `curl.exe` com cookie jar.

### 4a. Rota de dados sem sessão devolve 401 `UNAUTHENTICATED` — PASSOU

Cliente sem nenhum cookie:

```
GET    /api/v1/predictions                   -> 401  {"code": "UNAUTHENTICATED", "error": "Autenticação necessária."}
POST   /api/v1/predictions                   -> 401  {"code": "UNAUTHENTICATED", "error": "Autenticação necessária."}
GET    /api/v1/predictions/1                 -> 401  {"code": "UNAUTHENTICATED", "error": "Autenticação necessária."}
GET    /api/v1/models                        -> 401  {"code": "UNAUTHENTICATED", "error": "Autenticação necessária."}
GET    /api/v1/training-runs                 -> 404  {"code": "NOT_FOUND", "error": "Rota não encontrada."}
POST   /api/v1/training-runs                 -> 401  {"code": "UNAUTHENTICATED", "error": "Autenticação necessária."}
GET    /api/v1/training-runs/1               -> 401  {"code": "UNAUTHENTICATED", "error": "Autenticação necessária."}
GET    /api/v1/features/schema               -> 401  {"code": "UNAUTHENTICATED", "error": "Autenticação necessária."}
GET    /api/v1/models/comparison             -> 401  {"code": "UNAUTHENTICATED", "error": "Autenticação necessária."}
GET    /api/v1/models/features               -> 401  {"code": "UNAUTHENTICATED", "error": "Autenticação necessária."}
GET    /api/v1/models/export?format=csv      -> 401  {"code": "UNAUTHENTICATED", "error": "Autenticação necessária."}
PUT    /api/v1/models/1/threshold            -> 401  {"code": "UNAUTHENTICATED", "error": "Autenticação necessária."}
```

Todas as 11 rotas de dados do contrato devolvem 401 sem sessão. Uma ressalva de leitura,
não um defeito: **`GET /api/v1/training-runs` não existe** no contrato (a rota de coleção é
só `POST`; a consulta é `GET /api/v1/training-runs/{id}`), por isso o pedido cai no
catch-all do `app.py` e volta 404 `NOT_FOUND` — sem expor dado nenhum. A rota equivalente
pedida na verificação, `GET /api/v1/training-runs/1`, devolve 401 corretamente.

### 4b. `/api/v1/auth/*` seguem públicas — PASSOU

```
POST   /api/v1/auth/register (medico)        -> 201  {"user": {"id": 5, "email": "verif.medico@demo.local", "profile": "medico", ...}}
GET    /api/v1/auth/me (após register)       -> 200  {"user": {"id": 5, ...}}            # register já abre sessão
POST   /api/v1/auth/login (senha errada)     -> 401  {"code": "UNAUTHENTICATED", "error": "Credenciais inválidas."}
POST   /api/v1/auth/login (senha correta)    -> 200  {"user": {"id": 5, ...}}
POST   /api/v1/auth/logout (sem sessão)      -> 204  (corpo vazio)
GET    /api/v1/auth/me (sem sessão)          -> 401  {"code": "UNAUTHENTICATED", "error": "Sessão não encontrada."}
GET    /health                               -> 200  {"status": "ok"}
```

Cadastro e login funcionam sem sessão prévia; o 401 do login com senha errada vem do
próprio handler (mensagem "Credenciais inválidas"), ou seja, a requisição **chegou** à
view, não foi barrada pelo decorador. `/health` segue pública.

### 4c. Com sessão válida as mesmas rotas devolvem 200 — PASSOU

Sessão de `verif.medico@demo.local` (perfil **médico**):

```
POST   /api/v1/auth/login                    -> 200  {"user": {"id": 5, "profile": "medico"}}
GET    /api/v1/features/schema               -> 200  30 campos; exemplos ["benigno", "maligno"]
POST   /api/v1/predictions                   -> 200  {"evaluation_id": 11, "label": "maligno", "probability": 1.0, "confidence_band": "alta", "elapsed_ms": 193, ...}
GET    /api/v1/predictions                   -> 200  {"total": 11, "items": [... 11 itens ...]}
GET    /api/v1/predictions/11                -> 200  {"features": {...30...}, "created_at": "2026-10-22T17:03:55", ...}
GET    /api/v1/models                        -> 200  {"items": [7 registros]}
GET    /api/v1/models/comparison             -> 200  {"models": ["regressao_logistica", "svm"], ...}
GET    /api/v1/models/features               -> 200  {"best_model": "regressao_logistica", "ranking": [...30...]}
GET    /api/v1/models/export?format=csv      -> 200  CSV "modelo,ponto_operacao,limiar,acuracia,sensibilidade,..."
GET    /api/v1/training-runs/1               -> 200  {"id": 1, "status": "success", "dataset_sha256": "1121850321...", ...}
```

### 4d. Ausência de autorização por perfil continua intencional (D3) — PASSOU

Sessão **médico** chamando rotas do pesquisador:

```
POST   /api/v1/training-runs                 -> 201  {"training_run_id": 8, "status": "success", "artifacts_dir": "ml/artifacts/runs/8"}
GET    /api/v1/models/comparison             -> 200
```

Sessão **pesquisador** (`verif.pesquisador@demo.local`) chamando rotas do médico:

```
POST   /api/v1/auth/register (pesquisador)   -> 201  {"user": {"id": 6, "profile": "pesquisador"}}
POST   /api/v1/predictions                   -> 200  {"evaluation_id": 12, "label": "maligno", ...}
GET    /api/v1/predictions                   -> 200  {"total": 12}
```

Nenhuma trava por perfil, nos dois sentidos — exatamente o que D3 determina. O mesmo
comportamento foi confirmado pela interface (item 5): o médico abre `/laboratorio` por URL
direta e a tela carrega inteira; o `profile` só escolhe os links do menu.

### 4e. `POST /api/v1/training-runs` não modifica os artefatos de referência — PASSOU

`git -C c:\Users\isaiaslm\tcc-cancer-mama status --porcelain` **antes** do POST:

```
 M .agents/ESPECIFICACAO-CONSOLIDADA.md
 M .agents/RELATORIO-IMPLEMENTACAO.md
 M .agents/tasks/mvp-alinhado/design.md
 M .gitignore
 M README.md
 M api/routes.py
 M ml/__pycache__/__init__.cpython-314.pyc
 M ml/__pycache__/data.cpython-314.pyc
 M ml/__pycache__/train.cpython-314.pyc
 M ml/train.py
 M services/modelos.py
 M tests/base.py
 M tests/test_predictions.py
 M tests/test_training.py
?? .agents/comparar_artefatos.py
?? .agents/preparar_demo.py
?? .agents/tasks/correcoes-pos-revisao/
?? tests/test_sessao_obrigatoria.py
```

Requisição:

```
POST /api/v1/training-runs  {"models": ["regressao_logistica", "svm"], "test_size": 0.3, "grid_search": false}
  -> 201  {"training_run_id": 9, "status": "success", "artifacts_dir": "ml/artifacts/runs/9"}
```

`git status --porcelain` **depois** do POST:

```
 M .agents/ESPECIFICACAO-CONSOLIDADA.md
 M .agents/RELATORIO-IMPLEMENTACAO.md
 M .agents/tasks/mvp-alinhado/design.md
 M .gitignore
 M README.md
 M api/routes.py
 M ml/__pycache__/__init__.cpython-314.pyc
 M ml/__pycache__/data.cpython-314.pyc
 M ml/__pycache__/train.cpython-314.pyc
 M ml/train.py
 M services/modelos.py
 M tests/base.py
 M tests/test_predictions.py
 M tests/test_training.py
?? .agents/comparar_artefatos.py
?? .agents/preparar_demo.py
?? .agents/tasks/correcoes-pos-revisao/
?? tests/test_sessao_obrigatoria.py
```

**As duas saídas são idênticas.** Nenhuma linha de `ml/artifacts/`:

```
git -C c:\Users\isaiaslm\tcc-cancer-mama status --porcelain ml/artifacts
(vazio)

git -C c:\Users\isaiaslm\tcc-cancer-mama check-ignore -v ml/artifacts/runs/
.gitignore:12:ml/artifacts/runs/	ml/artifacts/runs/
```

`ml/artifacts/runs/` está ignorado (`.gitignore` linha 12) e recebeu os artefatos das
execuções 8 e 9, inclusive as figuras:

```
ml/artifacts/runs/9/: feature_importance.json, metrics.json, regressao_logistica.joblib,
                      regressao_logistica_oof.json, scaler.joblib, split.json, svm.joblib,
                      svm_oof.json, train_config.json, report/
ml/artifacts/runs/9/report/: roc_comparacao.png, matrizes_confusao.png,
                      importancia_regressao_logistica.png, importancia_svm.png, metricas.csv
ml/artifacts/runs/9/train_config.json -> test_size = 0.3
ml/artifacts/train_config.json        -> test_size = 0.2   (referência intacta)
```

As duas linhas `M ml/__pycache__/*.pyc` presentes nas duas saídas são **bytecode rastreado
desde antes destas correções** (já registrado no `notas-implementacao.md`, desvio 4): o
Python recompila `ml/train.py` em qualquer execução. Elas aparecem igualmente antes e
depois do POST, não têm relação com a rota de treino e foram restauradas
(`git checkout -- ml/__pycache__`) ao fim desta verificação.

### 4e (continuação). `artifact_path` da execução e promoção a produção — FALHOU no banco de demonstração herdado, PASSOU em banco limpo

**O que falhou.** No banco de desenvolvimento atual (`instance/tcc_cancer_mama.db`, que
carrega registros criados **antes** da correção), os dois `trained_models` da execução 9
ficaram com `artifact_path` apontando para a referência, não para o diretório da execução:

```
GET /api/v1/training-runs/9 -> 200
   modelo id=6 name=regressao_logistica artifact_path=ml/artifacts/regressao_logistica.joblib is_production=False
   modelo id=7 name=svm                 artifact_path=ml/artifacts/svm.joblib                 is_production=True
```

Evidência da causa (consulta direta ao SQLite + SHA-256 dos arquivos em disco):

```
trained_models (id, name, training_run_id, artifact_path, artifact_sha256)
(6, 'regressao_logistica', 9, 'ml/artifacts/regressao_logistica.joblib', 'b7ef5641fcf6...')
(7, 'svm',                 9, 'ml/artifacts/svm.joblib',                 '38c3ebcba2d4...')

SHA-256 reais em disco
9ec517d16ebf...  ml/artifacts/regressao_logistica.joblib      <- referência (test_size 0.2)
8bfca2197929...  ml/artifacts/svm.joblib                      <- referência
b7ef5641fcf6...  ml/artifacts/runs/9/regressao_logistica.joblib  <- é o hash gravado em id=6
38c3ebcba2d4...  ml/artifacts/runs/9/svm.joblib                 <- é o hash gravado em id=7
```

Ou seja: o `artifact_sha256` do registro é o do artefato da execução 9, mas o
`artifact_path` aponta para um arquivo cujos bytes são outros. Isso vem da regra de
reaproveitamento por hash de `services/modelos.py` (plano, item 2c): os registros 6 e 7 já
existiam no banco, criados por uma execução **pré-correção** com `test_size=0.3` que ainda
gravava em `ml/artifacts/`; na execução 9 o mesmo hash foi reencontrado, o registro foi
reaproveitado e o `artifact_path` antigo foi mantido porque o arquivo
`ml/artifacts/regressao_logistica.joblib` continua existindo em disco (com conteúdo
diferente). Consequência prática: a promoção desse registro leu o OOF da **referência**, e
não o da execução — `PUT /api/v1/models/6/threshold {"threshold": 0.01}` devolveu
`sensitivity = 0.9941` (OOF de 455 amostras da referência) e não o valor do OOF de
`runs/9/` (455 → 398 amostras no split 0,3).

**O que passou.** Com banco limpo (servidor novo na porta 5001 e
`DATABASE_URL=sqlite:///verif_clean.db`, sem registros legados), o comportamento é
exatamente o especificado:

```
POST /api/v1/training-runs {"models": ["regressao_logistica","svm"], "test_size": 0.35, "grid_search": false}
  -> 201 {"training_run_id": 2, "status": "success", "artifacts_dir": "ml/artifacts/runs/2"}

GET /api/v1/training-runs/2 -> 200  test_size=0.35
   id=3 name=regressao_logistica artifact_path=ml/artifacts/runs/2/regressao_logistica.joblib
   id=4 name=svm                 artifact_path=ml/artifacts/runs/2/svm.joblib

PUT /api/v1/models/3/threshold {"threshold": 0.01} -> 200 {"model": "regressao_logistica", "sensitivity": 0.9927}
   id=3 regressao_logistica threshold=0.01 is_production=True  artifact_path=ml/artifacts/runs/2/regressao_logistica.joblib
   id=4 svm                 threshold=0.34 is_production=False artifact_path=ml/artifacts/runs/2/svm.joblib
```

Confirmado, portanto: o `artifact_path` de registro **novo** aponta para
`ml/artifacts/runs/{training_run_id}/`, a promoção lê o OOF desse diretório (a
sensibilidade 0,9927 só pode vir de `runs/2/regressao_logistica_oof.json`; sem resolver o
diretório, a rota responderia 503 `MODEL_UNAVAILABLE`) e `is_production` passa a `true`
nesse registro, desmarcando os demais. O banco limpo foi apagado no fim da verificação.

**Para a próxima iteração de implementação decidir** (não corrigido aqui): ao reaproveitar
um registro por `artifact_sha256`, o caminho antigo só deveria ser mantido se o arquivo em
`artifact_path` **ainda tiver aquele hash**; caso contrário, repontar para o diretório da
execução atual. Alternativa sem mudança de código: zerar o banco de demonstração
(`instance/tcc_cancer_mama.db`) antes da defesa, já que os registros problemáticos são
resquício de execuções pré-correção.

### 4f. `PUT /api/v1/models/{id}/threshold` abaixo da meta — PASSOU

```
PUT /api/v1/models/7/threshold {"threshold": 0.95}   (svm de referência)
  -> 400 {"code": "SENSITIVITY_BELOW_TARGET", "error": "Sensibilidade obtida abaixo da meta de segurança clínica.", "obtained": 0.7353, "required": 0.97}

PUT /api/v1/models/6/threshold {"threshold": 0.99}   (modelo da execução 9)
  -> 400 {"code": "SENSITIVITY_BELOW_TARGET", "error": "Sensibilidade obtida abaixo da meta de segurança clínica.", "obtained": 0.7412, "required": 0.97}

PUT /api/v1/models/3/threshold {"threshold": 0.99}   (banco limpo, modelo da execução 2)
  -> 400 {"code": "SENSITIVITY_BELOW_TARGET", ..., "obtained": 0.6934, "required": 0.97}
```

Nenhuma promoção aconteceu nesses casos (o registro continuou com o limiar anterior e
`is_production` inalterado). O servidor foi derrubado ao terminar o item 4
(`Stop-Process` no processo `python app.py`; `http://127.0.0.1:5000/health` passou a dar
`URLError` e nenhum processo `app.py`/`flask` restou).

## 5. As 4 telas no navegador — PASSOU

**Havia ferramenta de navegador disponível:** Chrome instalado
(`C:\Program Files\Google\Chrome\Application\chrome.exe`) dirigido em modo headless por
`puppeteer-core` 25.4.0 (já presente em `c:\Users\isaiaslm\sam-dashboard\node_modules`),
por script temporário fora do repositório. O frontend compilado foi servido pelo próprio
Flask em `http://127.0.0.1:5000` (build do item 3), que é o cenário de produção do projeto.
Cada tela foi carregada de verdade, com login real, e o script coletou o console do
navegador e o status de todas as respostas de rede.

Screenshots (1440 px de largura, página inteira):

| Tela | Arquivo |
|---|---|
| Entrada / Seleção de Perfil (sem sessão) | `.agents/tasks/correcoes-pos-revisao/screenshots/01-entrada-login.png` |
| Triagem e Classificação (depois do login) | `.agents/tasks/correcoes-pos-revisao/screenshots/02-triagem-classificacao.png` |
| Histórico | `.agents/tasks/correcoes-pos-revisao/screenshots/03-historico.png` |
| Laboratório de Modelos (médico, por URL direta — D3) | `.agents/tasks/correcoes-pos-revisao/screenshots/04-laboratorio-modelos-medico-url-direta.png` |
| Laboratório de Modelos (pesquisador, pelo menu) | `.agents/tasks/correcoes-pos-revisao/screenshots/05-laboratorio-modelos-pesquisador.png` |

Conferido em cada uma:

- **01** — cartão "Entrar / Cadastrar" com e-mail, senha e o cabeçalho "Não autenticado";
  a única chamada de API antes do login é `GET /api/v1/auth/me -> 401`, que é o 401
  esperado no boot (o `SessionContext` trata com `setUser(null)`).
- **02** — após `POST /auth/login -> 200`, a rota `/classificar` renderiza
  `GET /api/v1/features/schema -> 200` com as **10 medidas base × 3 variações = 30 campos**
  (Raio, Textura, Perímetro, Área, Suavidade, Compacidade, Concavidade, Pontos côncavos,
  Simetria, Dimensão fractal; cada uma com Média, Erro padrão e Pior valor), os botões de
  exemplo/importar CSV, o seletor Anônimo/Identificado e "Classificar tumor". **É a tela
  que a correção poderia ter quebrado e ela carrega o schema normalmente depois do login.**
- **03** — `GET /api/v1/predictions?page=1&limit=15 -> 200`, tabela com 12 avaliações,
  filtros (classificação, registro, datas, faixa de confiança) e paginação "Página 1 de 1".
- **04** — médico autenticado abrindo `/laboratorio` **por URL direta**: a tela carrega
  inteira (`GET /models/comparison -> 200`, `GET /models/features?model=... -> 200`), com
  disparo de treino, comparação dos classificadores, curvas ROC, matrizes de confusão,
  controles de limiar com a regra ≥ 0,97, importância por permutação e bloco de
  reprodutibilidade. Confirma D3 pela interface: não há trava por perfil, apenas um menu
  diferente (menu do médico: "Classificar | Histórico").
- **05** — pesquisador autenticado com o menu "Laboratório de modelos | Histórico",
  mesma tela carregada pelo caminho normal.

Rede e console em todas as navegações:

```
GET /api/v1/auth/me -> 401          (boot sem sessão e logo após logout)
POST /api/v1/auth/login -> 200
GET /api/v1/features/schema -> 200
GET /api/v1/predictions?page=1&limit=15 -> 200
GET /api/v1/auth/me -> 200
GET /api/v1/models/comparison -> 200
GET /api/v1/models/features?model=regressao_logistica -> 200
POST /api/v1/auth/logout -> 204

respostas >= 400: somente os GET /api/v1/auth/me -> 401 citados
console: somente "Failed to load resource: ... 401 (UNAUTHORIZED)", que é o eco do mesmo /auth/me
```

Nenhum erro de JavaScript (`pageerror`) e nenhuma rota de dados barrada por falta de
sessão.

**O que NÃO foi verificado neste item:** não foram exercitadas pela interface as ações de
escrita (submeter uma classificação pelo botão "Classificar tumor", disparar treino pelo
botão do Laboratório, aplicar e promover um limiar pelo slider, baixar o CSV pelo link de
exportação) — todas essas foram verificadas pela API no item 4. Também não houve teste em
outros navegadores, em outras resoluções, nem com leitor de tela.

## 6. Scripts do usuário intactos — PASSOU

```
git -C c:\Users\isaiaslm\tcc-cancer-mama status --porcelain
```

```
 M .agents/ESPECIFICACAO-CONSOLIDADA.md
 M .agents/RELATORIO-IMPLEMENTACAO.md
 M .agents/tasks/mvp-alinhado/design.md
 M .gitignore
 M README.md
 M api/routes.py
 M ml/train.py
 M services/modelos.py
 M tests/base.py
 M tests/test_predictions.py
 M tests/test_training.py
?? .agents/comparar_artefatos.py
?? .agents/preparar_demo.py
?? .agents/tasks/correcoes-pos-revisao/
?? tests/test_sessao_obrigatoria.py
```

`.agents/preparar_demo.py` e `.agents/comparar_artefatos.py` continuam **não rastreados**
(`??`) e inalterados — não foram abertos para escrita em nenhum momento:

```
preparar_demo.py       mtime=2026-10-14 17:30:33  sha256=EEB0AEBC66774D36...
comparar_artefatos.py  mtime=2026-10-22 09:37:40  sha256=DEE091E00EF0F595...
```

Os dois timestamps são anteriores ao início desta etapa de verificação. A árvore voltou
exatamente ao estado descrito no `notas-implementacao.md` (as três linhas
`ml/__pycache__/*.pyc` que apareceram durante a verificação foram restauradas com
`git checkout -- ml/__pycache__`; `ml/artifacts/runs/` e o banco temporário
`instance/verif_clean.db` foram apagados).

## 7. Métricas conferidas em `ml/artifacts/metrics.json` — PASSOU

Fonte: `c:\Users\isaiaslm\tcc-cancer-mama\ml\artifacts\metrics.json` e
`train_config.json`, no estado versionado (commit `096bc54787318a90f40840bd51644a43b6dd4bab`),
verificado intacto ao fim desta etapa. Classe positiva: **maligno**. Meta de
sensibilidade: **0,97**. Melhor modelo: **regressão logística** (critério: maior
sensibilidade no ponto de operação, desempate por AUC e depois por especificidade).

Split / reprodutibilidade (`train_config.json`): `test_size = 0.2`, `random_state = 42`,
`cv_folds = 5`, `grid_search = true`, 30 características, **455 de treino** (285 benignos /
170 malignos) e **114 de teste** (72 benignos / 42 malignos); Python 3.14.6,
scikit-learn 1.9.1, numpy 2.5.0, joblib 1.6.0.

### Ponto de operação (limiar de segurança) — é o que a ferramenta usa

| Modelo | Limiar de segurança | Sensibilidade | Especificidade | Acurácia | Taxa de FN | AUC | Matriz (VN/FP/FN/VP) | Atende meta no teste |
|---|---|---|---|---|---|---|---|---|
| regressão logística ★ | **0,31** | **0,9762** | 0,9861 | 0,9825 | **0,0238** | 0,9960 | 71 / 1 / 1 / 41 | sim |
| SVM (RBF) | **0,38** | 0,9524 | 0,9861 | 0,9737 | 0,0476 | 0,9927 | 71 / 1 / 2 / 40 | não |

### Limiar padrão 0,50 (comparação)

| Modelo | Limiar | Sensibilidade | Especificidade | Acurácia | Taxa de FN | AUC | Matriz (VN/FP/FN/VP) |
|---|---|---|---|---|---|---|---|
| regressão logística ★ | 0,50 | 0,9286 | 0,9861 | 0,9649 | 0,0714 | 0,9960 | 71 / 1 / 3 / 39 |
| SVM (RBF) | 0,50 | 0,9286 | 1,0000 | 0,9737 | 0,0714 | 0,9927 | 72 / 0 / 3 / 39 |

### Validação cruzada (5 folds, treino)

| Modelo | Sensibilidade (média ± desvio) | Especificidade | Acurácia | AUC | Taxa de FN |
|---|---|---|---|---|---|
| regressão logística | 0,9529 ± 0,0446 | 0,9860 ± 0,0192 | 0,9736 ± 0,0167 | 0,9958 ± 0,0052 | 0,0471 ± 0,0446 |
| SVM (RBF) | 0,9588 ± 0,0446 | 0,9860 ± 0,0147 | 0,9758 ± 0,0092 | 0,9949 ± 0,0056 | 0,0412 ± 0,0446 |

Hiperparâmetros vencedores: regressão logística `C=1`, `penalty=l2`, `solver=lbfgs`,
`max_iter=1000`; SVM `C=10`, `kernel=rbf`, `gamma=scale`, `probability=true`. Hashes
SHA-256 dos artefatos de referência: `regressao_logistica.joblib` `9ec517d16ebf…`,
`svm.joblib` `8bfca2197929…`, `scaler.joblib` `d2424258e192…`, dataset `1121850321…`.

---

## Observações (sem veredito próprio)

1. **Bloco "Reprodutibilidade" × métricas exibidas no Laboratório.** Na screenshot 04, com
   um modelo da execução 9 (`test_size=0.3`) promovido, a tela mostra as matrizes de
   confusão da execução (106+1+2+62 = **171 casos de teste**) ao lado do texto de cabeçalho
   "Conjunto de teste (114 casos, 42 malignos)" e de um bloco de reprodutibilidade com
   "455 treino / 114 teste (20% teste)" e commit `096bc54787` — ou seja, números da
   **referência**. É o efeito previsto em D11 (o bloco `reproducibility` descreve os
   artefatos de referência), mas na tela as duas informações ficam lado a lado sem
   distinção, o que pode gerar pergunta na defesa. Vale uma frase no documento ou um rótulo
   na tela.
2. **Bytecode rastreado.** `ml/__pycache__/{__init__,data,train}.cpython-314.pyc` estão
   versionados no repositório e são reescritos a cada execução do Python, poluindo o
   `git status`. Já registrado nas notas de implementação; continua fora do escopo das duas
   correções, mas é o tipo de arquivo que não deveria entrar no commit.
3. **Banco de demonstração com dados pré-correção.** O `instance/tcc_cancer_mama.db` usado
   nesta verificação acumula registros de execuções anteriores (7 `trained_models`,
   12 avaliações) e foi o que expôs o problema do item 4e. Zerá-lo antes da defesa deixa a
   demonstração coerente com o comportamento corrigido.
