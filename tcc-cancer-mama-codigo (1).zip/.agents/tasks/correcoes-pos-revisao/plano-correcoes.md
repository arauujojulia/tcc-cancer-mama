# Plano de implementação — correções pós-revisão (2 entregas)

Branch: `feat/mvp-alinhado-documentacao` (já ativa, 16 commits, só local — **sem push, sem PR**).
Todos os comandos de git devem usar `git -C c:\Users\isaiaslm\tcc-cancer-mama`.

Os dois arquivos **não rastreados** `c:\Users\isaiaslm\tcc-cancer-mama\.agents\preparar_demo.py` e
`c:\Users\isaiaslm\tcc-cancer-mama\.agents\comparar_artefatos.py` são scripts do usuário:
**não commitar, não mover, não editar**. Nunca usar `git add -A` / `git add .` neste repositório.

Ambiente verificado: Python 3.14.6, suíte `python -m unittest discover -s tests -t . -v`
(76 testes), build do frontend `npm run build` em `frontend/`.
Estado atual dos artefatos de referência conferido: `ml/artifacts/train_config.json`
→ `test_size=0.2`, `random_state=42`, `commit_git=096bc54787…`; `metrics.json` →
RL limiar 0,31 / sens 0,9762 / acc 0,9825; SVM limiar 0,38 / sens 0,9524 / acc 0,9737.
**Esse é o estado que precisa continuar intacto no fim da implementação.**

---

## Decisões de projeto desta correção (fechadas aqui, não reabrir na implementação)

- **D8 — `ml/artifacts/` é a referência versionada; execuções da API são isoladas.**
  `POST /api/v1/training-runs` grava em `ml/artifacts/runs/{training_run_id}/`.
  `python -m ml.train` continua gravando em `ml/artifacts/` porque é o caminho
  deliberado de regerar a referência do artigo — isso passa a estar escrito no
  código (docstring + mensagem no `__main__`) e na documentação.
  Motivo: o RNF03 exige partição/hiperparâmetros versionados e o
  `RELATORIO-IMPLEMENTACAO.md` cita sensibilidade 0,9762; um treino disparado na
  defesa não pode alterar silenciosamente esses números.
- **D9 — a inferência (`POST /predictions`) continua usando sempre os artefatos de
  referência de `ml/artifacts/`.** `ml/predict.py:load_bundle` não passa a consultar
  o banco. Motivo: hoje a promoção (`PUT /models/{id}/threshold`) já não altera a
  inferência — ela só grava `threshold`/`is_production` em `trained_models`; o efeito
  que um treino da API tinha sobre a classificação era **apenas** o efeito colateral da
  sobrescrita dos artefatos, que é exatamente o defeito a corrigir. Tornar `predict`
  ciente do banco seria mudança de arquitetura fora do escopo das duas correções.
  Consequência a documentar: promover um modelo treinado sob demanda registra o ponto
  de operação no banco e no Laboratório, mas **não** troca o artefato que classifica;
  para tornar uma execução a nova referência, roda-se `python -m ml.train`.
- **D10 — autenticação (não autorização) exigida nas rotas de dados.** Sessão válida
  obrigatória em `/features/schema`, `/predictions*`, `/models*` e `/training-runs*`;
  sem sessão → **401 `UNAUTHENTICATED`**. `/auth/*` segue pública, `/health` segue
  pública. **Nenhuma verificação de perfil** continua existindo: médico autenticado
  chama rota de pesquisador e vice-versa (D3). Implementado por decorador explícito
  `@exigir_sessao` por rota (fica visível na leitura rota a rota, que é como o
  professor avalia), com um teste que varre `api_bp.url_map` para que nenhuma rota
  nova escape da trava.
- **D11 — provenance visível na comparação.** `GET /models/comparison` passa a expor
  `artifact_path` por modelo (campo aditivo, não contratual, como
  `safety_threshold_triggered`), e o bloco `reproducibility` fica documentado como
  descrevendo **os artefatos de referência** de `ml/artifacts/`; a procedência por
  modelo é `training_run_id` + `artifact_path`. Sem isso, um modelo vindo de
  `runs/{id}` apareceria com métricas da execução ao lado de um bloco de
  reprodutibilidade da referência, sem nada indicando a diferença — exatamente o tipo
  de divergência doc↔código já cobrado.

---

# Entrega 1 — isolar o treino sob demanda dos artefatos de reprodutibilidade (RNF03)

- [ ] 1. **`ml/train.py`: diretório por execução e declaração explícita da referência.**
      Em `c:\Users\isaiaslm\tcc-cancer-mama\ml\train.py`, depois de `ARTIFACTS_DIR`,
      acrescentar `RUNS_DIR = os.path.join(ARTIFACTS_DIR, "runs")` e a função
      `diretorio_execucao(training_run_id) -> str` (devolve `os.path.join(RUNS_DIR, str(training_run_id))`).
      Em `train_and_evaluate`, incluir `"output_dir": output_dir` no dicionário de
      retorno (ao lado de `metrics`, `config`, `split`, `artifact_paths`) — é o canal
      por onde `services/modelos.py` descobre onde os artefatos foram gravados.
      Atualizar o docstring do módulo e o de `train_and_evaluate`: `ARTIFACTS_DIR` é a
      **referência versionada do artigo (split 80/20, semente 42)**, regerada **somente**
      por `python -m ml.train`; a API sempre passa `output_dir=diretorio_execucao(run_id)`.
      No bloco `if __name__ == "__main__":`, imprimir antes do treino a linha
      "Regenerando os artefatos de referência em ml/artifacts/ (RNF03 — split 80/20, semente 42)".
      Nada de mudança de comportamento aqui: é adição + documentação.
      Files: `c:\Users\isaiaslm\tcc-cancer-mama\ml\train.py`
      Verify: `cd c:\Users\isaiaslm\tcc-cancer-mama; python -c "from ml.train import diretorio_execucao; print(diretorio_execucao(7))"`
      imprime caminho terminando em `ml\artifacts\runs\7`; depois
      `python -m unittest discover -s tests -t .` continua com 76 testes OK.

- [ ] 2. **`services/modelos.py`: gravar `artifact_path` da execução e resolver o diretório de um registro.**
      Em `c:\Users\isaiaslm\tcc-cancer-mama\services\modelos.py`:
      (a) extrair de `_caminho_artefato` um helper público `caminho_relativo(caminho) -> str`
      (relpath a partir de `_RAIZ`, com `replace(os.sep, "/")` e o mesmo `except ValueError`
      para volume diferente no Windows) e fazer `_caminho_artefato` usá-lo;
      (b) `concluir_training_run_sucesso(run, resultado, artifacts_dir=None)` passa a
      resolver `artifacts_dir = artifacts_dir or resultado.get("output_dir") or ARTIFACTS_DIR`;
      (c) na reutilização de registro por `artifact_sha256` (o caso "run reproduziu
      byte-a-byte um artefato já registrado"), só sobrescrever `registro.artifact_path`
      quando o registro é novo **ou** quando o caminho atual não aponta para um arquivo
      existente — assim o registro dos modelos de referência continua apontando para
      `ml/artifacts/{nome}.joblib` (bytes idênticos pelo hash, e esse caminho é o
      estável/versionado, enquanto `runs/` é descartável). Comentar essa regra no código;
      (d) acrescentar `diretorio_artefatos_do_registro(registro) -> str`: resolve
      `registro.artifact_path` contra `_RAIZ` quando relativo, devolve o `dirname`; se o
      diretório não existir, devolve `ARTIFACTS_DIR` (degradação segura — a rota de
      promoção devolve 503 se o OOF não estiver lá);
      (e) atualizar o docstring do módulo citando `ml/artifacts/runs/{id}/` como origem
      dos artefatos de treino sob demanda.
      Files: `c:\Users\isaiaslm\tcc-cancer-mama\services\modelos.py`
      Verify: `cd c:\Users\isaiaslm\tcc-cancer-mama; python -m unittest discover -s tests -t .` → 76 OK
      (ainda sem mudança de comportamento: as rotas só passam o novo diretório no item 3).

- [ ] 3. **`api/routes.py`: `POST /training-runs` escreve na pasta da execução; promoção lê o OOF da execução.**
      Em `c:\Users\isaiaslm\tcc-cancer-mama\api\routes.py`:
      (a) importar `diretorio_execucao` de `ml.train`;
      (b) em `criar_training_run`: após `svc_modelos.criar_training_run(...)`, calcular
      `diretorio = diretorio_execucao(run.id)` e chamar
      `train_and_evaluate(output_dir=diretorio, models=..., test_size=..., grid_search=..., hyperparameters=...)`;
      chamar `gerar_figuras(artifacts_dir=diretorio)` (as figuras/CSV 300 DPI do run vão
      para `ml/artifacts/runs/{id}/report/`, não mais para `ml/artifacts/report/`);
      remover a chamada `clear_cache()` deste handler, com comentário explicando que o
      treino sob demanda **não** toca nos artefatos de referência, então o bundle em
      memória continua válido (D9); acrescentar `"artifacts_dir": svc_modelos.caminho_relativo(diretorio)`
      ao corpo 201;
      (c) em `ajustar_threshold`: passar
      `artifacts_dir=svc_modelos.diretorio_artefatos_do_registro(registro)` para
      `svc_modelos.sensibilidade_oof(...)`, para a promoção de um modelo de execução ler
      `runs/{id}/{modelo}_oof.json` (e a dos modelos de referência continuar lendo
      `ml/artifacts/`);
      (d) em `comparar_modelos`, acrescentar `"artifact_path": registro.artifact_path` ao
      item do modelo e um comentário de que o bloco `reproducibility` descreve os
      artefatos de referência de `ml/artifacts/` (D11);
      (e) atualizar o docstring do módulo: artefatos de referência vs. artefatos de
      execução. `clear_cache` permanece importado e usado em `ajustar_threshold`.
      Files: `c:\Users\isaiaslm\tcc-cancer-mama\api\routes.py`
      Verify: `cd c:\Users\isaiaslm\tcc-cancer-mama; python -m unittest tests.test_training -v` → todos OK;
      em seguida `git -C c:\Users\isaiaslm\tcc-cancer-mama status --porcelain ml/artifacts`
      **sem nenhuma linha** (os testes de treino deixam de sujar a referência) e
      `ml/artifacts/runs/` com as pastas das execuções dos testes (remover à mão
      enquanto o item 5 não estiver pronto: `Remove-Item -Recurse -Force c:\Users\isaiaslm\tcc-cancer-mama\ml\artifacts\runs`).

- [ ] 4. **`.gitignore`: ignorar as execuções.**
      Acrescentar `ml/artifacts/runs/` em `c:\Users\isaiaslm\tcc-cancer-mama\.gitignore`,
      logo abaixo da linha `ml/artifacts/report/`, com comentário de uma linha
      ("execuções de treino sob demanda — descartáveis; a referência versionada é ml/artifacts/").
      Files: `c:\Users\isaiaslm\tcc-cancer-mama\.gitignore`
      Verify: criar `ml/artifacts/runs/999/x.json` qualquer e rodar
      `git -C c:\Users\isaiaslm\tcc-cancer-mama status --porcelain` → só as duas linhas
      `?? .agents/comparar_artefatos.py` e `?? .agents/preparar_demo.py`; apagar o arquivo de teste depois.

- [ ] 5. **Testes da Entrega 1: isolamento verificado e limpeza automática.**
      Em `c:\Users\isaiaslm\tcc-cancer-mama\tests\base.py`: no `setUp` do `ApiTestCase`,
      guardar o conjunto de entradas já existentes em `ml.train.RUNS_DIR` (se o diretório
      existir) e, no `tearDown`, remover com `shutil.rmtree(..., ignore_errors=True)` as
      entradas criadas durante o teste — isso fecha a pendência "isolamento de testes"
      registrada no `RELATORIO-IMPLEMENTACAO.md` §4.
      Em `c:\Users\isaiaslm\tcc-cancer-mama\tests\test_training.py`, acrescentar a
      `TestPostTrainingRuns` (helper local que calcula `sha256` de
      `metrics.json`, `train_config.json`, `split.json`, `scaler.joblib`,
      `regressao_logistica.joblib`, `svm.joblib`, `regressao_logistica_oof.json`,
      `svm_oof.json` em `ml/artifacts/`):
      - `test_treino_sob_demanda_nao_altera_os_artefatos_de_referencia`: hashes antes e
        depois de `POST /training-runs` com `{"models": ["regressao_logistica"], "test_size": 0.3, "grid_search": False}`
        são iguais (é o teste que reproduz o defeito relatado);
      - `test_artefatos_do_run_ficam_no_diretorio_da_execucao`: `ml/artifacts/runs/{run_id}/metrics.json`
        existe, o `train_config.json` dessa pasta tem `test_size == 0.3`, enquanto o de
        `ml/artifacts/` segue com `0.2`, e o `TrainedModel.artifact_path` começa com
        `ml/artifacts/runs/{run_id}/`;
      - `test_resposta_informa_o_diretorio_da_execucao`: corpo 201 traz
        `artifacts_dir == f"ml/artifacts/runs/{run_id}"`;
      - `test_figuras_do_run_nao_sobrescrevem_o_report_de_referencia`:
        `ml/artifacts/runs/{run_id}/report/metricas.csv` existe e o conteúdo de
        `ml/artifacts/report/metricas.csv` não mudou.
      Em `TestPutThreshold`, acrescentar
      `test_promocao_le_o_oof_do_diretorio_da_execucao`: treina com `test_size=0.3`,
      `grid_search=False`, chama `PUT /models/{id}/threshold` com `{"threshold": 0.01}`
      **sem** `patch` em `sensibilidade_oof` e espera **200** com `sensitivity == 1.0`
      (se o diretório da execução não fosse resolvido, viria 503 `MODEL_UNAVAILABLE`).
      Files: `c:\Users\isaiaslm\tcc-cancer-mama\tests\base.py`,
      `c:\Users\isaiaslm\tcc-cancer-mama\tests\test_training.py`
      Verify: `cd c:\Users\isaiaslm\tcc-cancer-mama; python -m unittest tests.test_training -v` → todos OK;
      depois `Get-ChildItem c:\Users\isaiaslm\tcc-cancer-mama\ml\artifacts\runs -ErrorAction SilentlyContinue`
      não lista pastas novas e `git -C c:\Users\isaiaslm\tcc-cancer-mama status --porcelain` segue com as 2 linhas `??`.

- [ ] 6. **Verificação ponta a ponta da Entrega 1 contra o servidor real (antes da Entrega 2, enquanto as rotas ainda são públicas).**
      Subir `python app.py` em um terminal; em outro, disparar
      `POST /api/v1/training-runs` com `{"models":["regressao_logistica","svm"],"test_size":0.3,"grid_search":false}`
      (ex.: `python -c` com `urllib.request`, ou `curl.exe`), anotar o `training_run_id`
      e o `artifacts_dir` da resposta.
      Files: nenhum (verificação)
      Verify: `git -C c:\Users\isaiaslm\tcc-cancer-mama status --porcelain ml/artifacts` **vazio**;
      `python .agents\comparar_artefatos.py` mostra COMMITADO e ÁRVORE DE TRABALHO
      idênticos (`test_size=0.2`, RL limiar 0,31 / sens 0,9762, SVM limiar 0,38 / sens 0,9524);
      `ml/artifacts/runs/{id}/train_config.json` com `test_size=0.3`. Derrubar o servidor
      e apagar `ml/artifacts/runs/` ao final.

---

# Entrega 2 — exigir sessão válida nas rotas de dados (401 sem sessão)

- [ ] 7. **`api/routes.py`: decorador `exigir_sessao` aplicado às 11 rotas de dados.**
      Em `c:\Users\isaiaslm\tcc-cancer-mama\api\routes.py`, logo após o helper `_erro`,
      definir:
      `def exigir_sessao(view)` — com `functools.wraps`, devolve
      `_erro("Autenticação necessária.", 401, "UNAUTHENTICATED")` quando
      `svc_auth.current_user() is None`, senão chama a view. Docstring explicitando:
      **autenticação, não autorização** — nenhuma verificação de `profile` (D3); o
      fluxo da Figura 3 (Seleção de Perfil) coloca o login antes de qualquer operação.
      Aplicar o decorador **abaixo** do `@api_bp.route(...)` de cada uma destas views:
      `schema`, `criar_predicao`, `listar_predicoes`, `obter_predicao`, `listar_modelos`,
      `comparar_modelos`, `importancia_features`, `exportar_metricas`,
      `criar_training_run`, `obter_training_run`, `ajustar_threshold`.
      **Não** decorar `register`, `login`, `logout`, `me` (seguem públicas), nem mexer em
      `/health` (está em `app.py`, segue pública).
      Em `criar_predicao`, `svc_auth.current_user_id()` passa a devolver sempre um id —
      manter a chamada (a coluna `evaluations.user_id` segue `nullable=True` pelo
      modelo de dados da especificação §4 e por causa de linhas antigas).
      Atualizar o docstring do módulo: trocar a frase "Classificar não exige sessão —
      quando ela existe, o `user_id` é gravado na avaliação" por "Toda rota de dados
      exige sessão válida (401 `UNAUTHENTICATED` sem ela); `/auth/*` é pública. Nenhuma
      rota é bloqueada por perfil (D3): o `profile` só escolhe o menu do frontend."
      O preflight CORS não quebra: `OPTIONS` é respondido pelo `provide_automatic_options`
      do Flask/Flask-CORS sem entrar na view decorada.
      Files: `c:\Users\isaiaslm\tcc-cancer-mama\api\routes.py`
      Verify: `cd c:\Users\isaiaslm\tcc-cancer-mama; python -m unittest tests.test_auth -v` → OK
      (os testes de `predictions`/`training` quebram neste ponto por falta de sessão; são
      ajustados no item 8, que é a continuação imediata).

- [ ] 8. **Testes existentes: autenticar antes de exercitar rota de dados.**
      Em `c:\Users\isaiaslm\tcc-cancer-mama\tests\base.py`, acrescentar
      `class ApiAutenticadoTestCase(ApiTestCase)` cujo `setUp` chama
      `super().setUp()` e depois `self.user = self.registrar_e_logar()` (o `register` já
      abre a sessão), com docstring dizendo que a sessão é requisito de todas as rotas
      de dados (D10) e que o perfil usado é irrelevante (D3).
      Trocar a base de `TestPredictions` em
      `c:\Users\isaiaslm\tcc-cancer-mama\tests\test_predictions.py` e de
      `TestPostTrainingRuns` / `TestPutThreshold` em
      `c:\Users\isaiaslm\tcc-cancer-mama\tests\test_training.py` para
      `ApiAutenticadoTestCase`. Em `test_predictions.py`, acrescentar ao
      `test_post_predictions_200_grava_evaluation_com_campos_em_ingles` a asserção
      `av.user_id == self.user["id"]` (autoria agora sempre registrada).
      Files: `c:\Users\isaiaslm\tcc-cancer-mama\tests\base.py`,
      `c:\Users\isaiaslm\tcc-cancer-mama\tests\test_predictions.py`,
      `c:\Users\isaiaslm\tcc-cancer-mama\tests\test_training.py`
      Verify: `cd c:\Users\isaiaslm\tcc-cancer-mama; python -m unittest discover -s tests -t . -v` → tudo OK de novo.

- [ ] 9. **Novo arquivo de testes dos dois lados da trava de sessão.**
      Criar `c:\Users\isaiaslm\tcc-cancer-mama\tests\test_sessao_obrigatoria.py` com, no mínimo:
      - `test_todas_as_rotas_de_dados_devolvem_401_sem_sessao`: varre
        `self.app.url_map.iter_rules()`, filtra as regras com `rule.startswith("/api/v1")`
        que **não** começam com `/api/v1/auth`, substitui conversores (`<int:...>` → `1`)
        e, para cada método em `rule.methods - {"HEAD", "OPTIONS"}`, chama o cliente **sem
        sessão** esperando `401` e `code == "UNAUTHENTICATED"` (corpo JSON vazio é
        suficiente: a trava roda antes da validação). Esse teste é a rede de segurança
        contra rota nova sem decorador;
      - `test_rotas_de_auth_continuam_publicas`: `POST /auth/register` → 201,
        `POST /auth/login` com senha errada → 401 `UNAUTHENTICATED` (chega ao handler),
        `POST /auth/logout` → 204 sem sessão, `GET /auth/me` → 401; `GET /health` → 200;
      - `test_com_sessao_as_rotas_de_dados_respondem_normalmente`: autenticado,
        `GET /features/schema` → 200 com 30 campos, `GET /predictions` → 200,
        `GET /models` → 200 `{"items": [...]}`;
      - `test_medico_acessa_rotas_de_pesquisador_e_vice_versa` (D3 — sem autorização):
        logado como `profile="medico"`, `POST /training-runs`
        (`{"models":["regressao_logistica"],"grid_search":false}`) → 201 e
        `GET /models` → 200; logado como `profile="pesquisador"`,
        `POST /predictions` com payload válido → 200. Comentar no teste que isto é
        intencional: D3 removeu a segregação por perfil, não a autenticação.
      Usar `ApiTestCase` (sem sessão) e `ApiAutenticadoTestCase` conforme o caso.
      Files: `c:\Users\isaiaslm\tcc-cancer-mama\tests\test_sessao_obrigatoria.py`
      Verify: `cd c:\Users\isaiaslm\tcc-cancer-mama; python -m unittest tests.test_sessao_obrigatoria -v` → todos OK;
      depois a suíte completa (`python -m unittest discover -s tests -t . -v`) OK, com
      contagem acima de 76.

- [ ] 10. **Verificar o frontend (expectativa: nenhuma mudança de código).**
      Conferir, lendo os arquivos, que nenhuma chamada a rota de dados acontece antes do
      login — e corrigir apenas se a verificação contrariar isso:
      `c:\Users\isaiaslm\tcc-cancer-mama\frontend\src\api.js` envia
      `credentials: "include"` em **todas** as chamadas (função `request`);
      `c:\Users\isaiaslm\tcc-cancer-mama\frontend\src\App.jsx` monta
      `ClassificarPage`/`HistoricoPage`/`ModelosPage` dentro de `RotaProtegida`, que
      devolve `null` enquanto `loading` e redireciona para `/login` sem `user` — por isso
      o `useEffect` com `getFeatureSchema()` em
      `c:\Users\isaiaslm\tcc-cancer-mama\frontend\src\pages\ClassificarPage.jsx` (linhas 52-53)
      **só roda depois** de `GET /auth/me` ter retornado 200, e a tela Classificar não bate
      em `/features/schema` antes do login;
      `c:\Users\isaiaslm\tcc-cancer-mama\frontend\src\SessionContext.jsx` já trata o 401
      de `/auth/me` no boot (catch → `setUser(null)`), que é o único 401 esperado;
      o link de exportação (`URL_EXPORT_CSV`, `ModelosPage.jsx` linha 320) é um `<a href download>`
      de **mesma origem** (`/api/v1/...`, servido pelo Flask em produção e pelo proxy do
      Vite em dev, ver `frontend/vite.config.js`), então o cookie de sessão viaja
      automaticamente.
      Registrar no `RELATORIO-IMPLEMENTACAO.md` (item 13) o comportamento de sessão
      expirada: um 401 em rota de dados aparece como mensagem de erro da tela e o
      recarregamento leva ao `/login` — não foi adicionado interceptador global de 401
      para manter a correção mínima.
      Files: nenhum (verificação); só editar se a leitura mostrar chamada pré-login
      Verify: `cd c:\Users\isaiaslm\tcc-cancer-mama\frontend; npm run build` conclui sem erro;
      com `python app.py` rodando e o build servido em `http://localhost:5000`, conferir
      no DevTools (aba Network, janela anônima) que antes do login só há
      `GET /api/v1/auth/me` (401) e que, após o login, Classificar carrega os 30 campos,
      Histórico lista e o Laboratório abre.

- [ ] 11. **Verificação ponta a ponta da Entrega 2 contra o servidor real.**
      Com `python app.py` rodando: `GET /api/v1/predictions` **sem cookie** →
      401 `UNAUTHENTICATED`; o mesmo para `GET /api/v1/features/schema`,
      `GET /api/v1/models`, `POST /api/v1/training-runs` e `GET /api/v1/models/export?format=csv`.
      Depois, com sessão (cookie jar: `POST /auth/register` ou `/auth/login`),
      as mesmas rotas respondem 200/201. `python .agents\preparar_demo.py` continua
      funcionando ponta a ponta (ele já usa `CookieJar` e loga antes de chamar
      `/features/schema` e `/predictions`) — **não editar esse script**.
      Files: nenhum (verificação)
      Verify: as 5 rotas acima devolvem 401 sem cookie e 200/201 com cookie;
      `python .agents\preparar_demo.py` imprime os casos classificados e a linha do RNF04;
      `git -C c:\Users\isaiaslm\tcc-cancer-mama status --porcelain ml/artifacts` vazio ao final.

---

# Documentação (obrigatória — doc e código não podem divergir)

- [ ] 12. **`README.md`.**
      Em `c:\Users\isaiaslm\tcc-cancer-mama\README.md`:
      (a) reescrever a seção "⚠️ Aviso de segurança": dizer que **todas as rotas de dados
      exigem sessão válida** (401 `UNAUTHENTICATED` sem ela) e que **não há controle de
      acesso por perfil** (D3) — logo, **qualquer usuário autenticado**, médico ou
      pesquisador, lê o histórico identificado inteiro, dispara treinos e promove
      modelos; manter e manter explícito que nome e prontuário do modo identificado
      ficam em texto puro (D2) e que a aplicação não deve ser exposta fora de ambiente
      controlado;
      (b) na tabela do contrato da API, marcar quais rotas exigem sessão (coluna ou
      sufixo "exige sessão") e manter `/auth/*` como públicas;
      (c) no mapa de pastas, acrescentar
      `ml/artifacts/runs/{training_run_id}/  # artefatos de cada treino sob demanda (não versionado)`
      e anotar em `ml/artifacts/` que é a **referência versionada (RNF03)**;
      (d) no passo "3. Treinar e avaliar os modelos", avisar que `python -m ml.train`
      **regenera a referência** e que treinos pela tela do Laboratório **não** a alteram;
      (e) no passo "4. Gerar as figuras", anotar que as figuras de uma execução ficam em
      `ml/artifacts/runs/{id}/report/`;
      (f) em "Outras decisões técnicas", acrescentar os parágrafos de D8/D9/D10
      (isolamento por execução; inferência sempre pela referência; sessão obrigatória
      sem verificação de perfil).
      Files: `c:\Users\isaiaslm\tcc-cancer-mama\README.md`
      Verify: `Select-String -Path c:\Users\isaiaslm\tcc-cancer-mama\README.md -Pattern "exige sessão|runs/"`
      acha as novas passagens e nenhuma frase antiga afirma que classificar não exige
      sessão; revisão de leitura confirmando que o aviso de segurança descreve o estado
      pós-correção.

- [ ] 13. **`.agents\ESPECIFICACAO-CONSOLIDADA.md`.**
      Em `c:\Users\isaiaslm\tcc-cancer-mama\.agents\ESPECIFICACAO-CONSOLIDADA.md`:
      (a) na linha D3 da tabela de decisões, acrescentar a nota "D3 removeu segregação
      por perfil e trava de autorização; **não** removeu a necessidade de estar
      autenticado — ver D10";
      (b) na seção 2, acrescentar as decisões **D8, D9 e D10** com a mesma redação
      resumida deste plano;
      (c) na seção 5, trocar "O `profile` retornado define o menu do frontend. Nenhuma
      rota é bloqueada por perfil." por essa frase **mais** "Todas as rotas fora de
      `/auth/*` exigem sessão válida; sem sessão, 401 `UNAUTHENTICATED`. A trava é de
      autenticação, não de autorização.", e repetir a marcação nas três tabelas de rotas
      (triagem, histórico, laboratório);
      (d) na seção 5, no parágrafo de `POST /training-runs`, trocar
      "salva `artifacts/{model_id}.joblib`" por "salva os artefatos em
      `ml/artifacts/runs/{training_run_id}/` (nunca sobrescreve a referência de
      `ml/artifacts/`)" e citar o campo aditivo `artifacts_dir` na resposta 201;
      (e) na seção 6, no item de Reprodutibilidade (RNF03), explicitar que
      `ml/artifacts/` é a referência versionada regerada só por `python -m ml.train` e
      que execuções sob demanda são isoladas e não versionadas; ajustar o item de
      Exportação científica citando `ml/artifacts/runs/{id}/report/` para execuções;
      (f) na seção 8, na linha do RNF03, acrescentar a verificação "treino pela API não
      altera `ml/artifacts/` (`git status` limpo)";
      (g) na seção 9, reescrever o "Aviso de segurança a constar no README" com a
      redação corrigida do item 12(a).
      Files: `c:\Users\isaiaslm\tcc-cancer-mama\.agents\ESPECIFICACAO-CONSOLIDADA.md`
      Verify: leitura das seções 2, 5, 6, 8 e 9 sem nenhuma afirmação contrária ao
      código; `Select-String -Path ... -Pattern "D8|D9|D10|runs/"` acha as inclusões.

- [ ] 14. **`.agents\tasks\mvp-alinhado\design.md` — corrigir só o que ficou contrário ao código.**
      Em `c:\Users\isaiaslm\tcc-cancer-mama\.agents\tasks\mvp-alinhado\design.md`,
      **sem reabrir nem reescrever a seção 11** (decisões fechadas nas 3 rodadas de
      revisão de design):
      (a) na seção 4.3, substituir a decisão "não exigir login para classificar" por uma
      nota datada: "**Revisto (correções pós-revisão, D10):** todas as rotas de dados
      passam a exigir sessão válida (401 `UNAUTHENTICATED`); `/auth/*` segue pública. O
      RF07 (histórico sem exigir identificação **do paciente**) continua atendido pelo
      modo anônimo; `evaluations.user_id` passa a ser sempre preenchido. Continua sem
      qualquer trava por perfil (D3)." — manter o parágrafo original visível como
      histórico da decisão anterior, marcado como superado;
      (b) na seção 5.1, no parágrafo da exportação 300 DPI (finding 4 da 2ª rodada),
      acrescentar nota: "**Revisto (D8):** o treino sob demanda grava em
      `ml/artifacts/runs/{training_run_id}/` e as figuras/CSV do run vão para
      `.../report/` dessa pasta; `ml/artifacts/report/` segue refletindo a referência
      versionada, regerada por `python -m ml.report`";
      (c) na seção 5.3, anotar que o `{model}_oof.json` lido é o do diretório do próprio
      registro (`ml/artifacts/` para a referência, `ml/artifacts/runs/{id}/` para
      execuções).
      Files: `c:\Users\isaiaslm\tcc-cancer-mama\.agents\tasks\mvp-alinhado\design.md`
      Verify: `Select-String -Path ... -Pattern "Revisto \(D8\)|Revisto \(correções pós-revisão"`
      retorna as 3 notas; a seção 11 permanece byte-a-byte igual
      (`git -C c:\Users\isaiaslm\tcc-cancer-mama diff -- .agents/tasks/mvp-alinhado/design.md`
      mostra alterações só nas seções 4.3, 5.1 e 5.3).

- [ ] 15. **`.agents\RELATORIO-IMPLEMENTACAO.md` — nova seção sobre os dois defeitos corrigidos.**
      Em `c:\Users\isaiaslm\tcc-cancer-mama\.agents\RELATORIO-IMPLEMENTACAO.md`:
      (a) acrescentar a seção **"2.5 Defeitos encontrados na revisão e corrigidos"**, com
      um bloco por defeito: sintoma, evidência, causa, correção e verificação.
      Defeito 1 (RNF03): `POST /api/v1/training-runs` gravava em `ml/artifacts/`;
      um treino com `test_size=0.3` sobrescreveu a referência 80/20 —
      `regressao_logistica` limiar 0,31→0,32, sens 0,9762→0,9688, FN 0,0238→0,0312;
      `svm` limiar 0,38→0,21, acurácia 0,9737→0,9591. Correção: diretório por execução
      `ml/artifacts/runs/{training_run_id}/`, `artifact_path` apontando para lá,
      promoção lendo o OOF da execução, `ml/artifacts/runs/` no `.gitignore`, e
      `python -m ml.train` mantido como único caminho (agora explícito no código) de
      regerar a referência. Verificação: teste de hash dos 8 artefatos antes/depois do
      POST, `git status` limpo em `ml/artifacts` após treino real e
      `.agents/comparar_artefatos.py` mostrando HEAD == árvore de trabalho.
      Defeito 2 (autenticação): `GET /api/v1/predictions` devolvia 200 sem cookie
      enquanto `GET /api/v1/auth/me` devolvia 401. Correção: decorador `exigir_sessao`
      nas 11 rotas de dados → 401 `UNAUTHENTICATED` sem sessão, `/auth/*` pública,
      **sem** nenhuma verificação de perfil (D3 preservada: médico acessa rota de
      pesquisador e vice-versa). Verificação: teste que varre todas as regras de
      `/api/v1` fora de `/auth`, testes dos dois lados (401/200) e requisições reais;
      (b) atualizar a seção 1 (RNF03) citando o isolamento por execução, e a seção 1
      (RNF05) / seção 4 onde o texto depender do estado antigo;
      (c) em "3.1 Sequência de comandos", **remover** a nota "Após rodar a suíte de
      testes, re-execute `python -m ml.train`" — os testes não sujam mais a referência;
      (d) em "4. Pendências", marcar a pendência "Isolamento de testes" como
      **resolvida** (limpeza no `tearDown` + diretório por execução);
      (e) no roteiro de demonstração (3.2), no passo 5, acrescentar a frase de efeito
      para a defesa: o treino disparado na tela grava em
      `ml/artifacts/runs/{id}/` e **não** altera os números do artigo (mostrar
      `git status` limpo); no passo 1, lembrar que agora é obrigatório estar logado para
      qualquer tela de dados;
      (f) atualizar a contagem de testes (76 → o número real após os itens 5, 8 e 9) e a
      seção 6 com os commits desta correção;
      (g) registrar a nota de sessão expirada do item 10 e a decisão D9 (promoção de
      modelo de execução não troca o artefato que classifica).
      Files: `c:\Users\isaiaslm\tcc-cancer-mama\.agents\RELATORIO-IMPLEMENTACAO.md`
      Verify: leitura da nova seção 2.5 com os números batendo com os artefatos reais
      (`python .agents\comparar_artefatos.py`) e com a saída da suíte; nenhuma menção
      remanescente à necessidade de re-treinar depois dos testes
      (`Select-String -Path ... -Pattern "re-execute .python -m ml.train"` sem resultado).

---

# Fechamento

- [ ] 16. **Verificação final e commits locais.**
      Rodar, em `c:\Users\isaiaslm\tcc-cancer-mama`:
      `python -m unittest discover -s tests -t . -v` (tudo OK);
      `cd frontend; npm run build` (conclui limpo);
      `git -C c:\Users\isaiaslm\tcc-cancer-mama status --porcelain` deve listar **apenas**
      os arquivos de código/doc alterados por este plano **mais** as duas linhas
      `?? .agents/comparar_artefatos.py` e `?? .agents/preparar_demo.py`, e **nenhuma**
      linha de `ml/artifacts/` (referência intacta, commit `096bc54…`).
      Commitar localmente, em dois commits, **nomeando os arquivos um a um** (nunca
      `git add -A`, para os dois scripts do usuário continuarem fora do índice):
      1. `fix: isola artefatos do treino sob demanda em ml/artifacts/runs (RNF03)` —
         `ml/train.py`, `services/modelos.py`, `api/routes.py`, `.gitignore`,
         `tests/base.py`, `tests/test_training.py`;
      2. `fix: exige sessao valida nas rotas de dados (401 UNAUTHENTICATED)` —
         `api/routes.py`, `tests/base.py`, `tests/test_predictions.py`,
         `tests/test_training.py`, `tests/test_sessao_obrigatoria.py`;
      3. `docs: registra as duas correcoes pos-revisao` — `README.md`,
         `.agents/ESPECIFICACAO-CONSOLIDADA.md`,
         `.agents/tasks/mvp-alinhado/design.md`,
         `.agents/RELATORIO-IMPLEMENTACAO.md`,
         `.agents/tasks/correcoes-pos-revisao/plano-correcoes.md`.
      (Se um arquivo aparecer em mais de um commit, commitar na ordem acima com os
      trechos já prontos; não usar `--amend` depois de hook falhando.)
      **Sem `git push` e sem abrir PR.**
      Files: nenhum novo
      Verify: `git -C c:\Users\isaiaslm\tcc-cancer-mama log --oneline -4` mostra os três
      commits novos no topo de `b96c97c`; `git -C c:\Users\isaiaslm\tcc-cancer-mama status --porcelain`
      termina com apenas as duas linhas `??`;
      `git -C c:\Users\isaiaslm\tcc-cancer-mama diff 096bc54 HEAD --stat -- ml/artifacts`
      sem nenhuma linha.

---

## Suposições registradas

1. **A inferência não passa a consultar o banco** (D9). Se o professor cobrar que
   "promover" deve trocar o modelo que classifica, o caminho documentado é
   `python -m ml.train` + reinício; mudar `ml/predict.py` para ler `trained_models` é
   trabalho de outra entrega.
2. **O campo `artifacts_dir` na resposta 201 e o `artifact_path` em
   `/models/comparison` são aditivos** e não quebram o contrato da especificação §5
   (mesmo padrão já aceito para `safety_threshold_triggered`).
3. **`ml/artifacts/runs/` não é versionado.** Execuções de treino são descartáveis;
   o que o artigo cita continua sendo só a referência em `ml/artifacts/`.
4. **A trava é por decorador, não por `before_request`.** O decorador é explícito rota
   a rota (melhor para a avaliação doc↔código) e o teste que varre `url_map` cobre o
   risco de uma rota futura nascer sem ele.
