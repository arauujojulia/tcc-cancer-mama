# Design técnico — Alinhamento do MVP à especificação consolidada

Fonte da verdade: `.agents/ESPECIFICACAO-CONSOLIDADA.md`. Este documento define,
sem reescrever o código, como migrar o estado atual do repositório
(`/api/avaliacoes` em português, modelo `Medico`/`Pesquisador`/`ModeloTreinado`/
`Avaliacao`, criptografia AES-256-GCM) para o contrato `/api/v1`, o modelo de
dados `users`/`evaluations`/`trained_models`/`training_runs`, autenticação simples
e o treino sob demanda com promoção condicionada à sensibilidade ≥ 0,97.

Todo texto de interface e mensagens em português do Brasil. Identificadores de
API, nomes de rota e colunas de banco em inglês.

## Visão geral

A arquitetura de quatro camadas da especificação (React → Flask → scikit-learn /
SQLAlchemy) já existe no código. O que muda é o **contrato** entre elas e o
**vocabulário** das entidades. A estratégia é uma migração de contrato, não uma
reescrita: a lógica de inferência (`ml/predict.py`), o treino e as métricas
(`ml/train.py`, `ml/report.py`), a validação de características (`services/
validation.py`) e a regra de limiar de segurança (`ml/train.py:
escolher_limiar_seguranca`) estão corretas e são reaproveitadas quase intactas.
As mudanças concentram-se em: renomear rotas e campos para inglês sob o prefixo
`/api/v1`; renomear tabelas e colunas; **remover a criptografia** (D2); **remover
JWT/RBAC/auditoria** (D3) e introduzir cadastro/login simples (D4); tornar o
treino **sob demanda** gravando `training_runs` (D6); e expor a promoção de modelo
com a trava de sensibilidade (RNF04). O frontend é redesenhado para quatro telas
com um sistema de design clínico sóbrio e acessível (WCAG AA).

A tecnologia fica travada após a aprovação deste design: **backend** Python 3.14 +
Flask + Flask-SQLAlchemy + scikit-learn + `pandas` + joblib + matplotlib +
`psycopg` (driver PostgreSQL) + `python-dotenv` + `werkzeug.security` (já vem com
Flask); **frontend** Node 24 + React 18 + Vite 5 + `react-router-dom` (adicionado —
ver seção 7). Nenhuma dependência nova de ML. `pandas` é dependência existente e
**permanece** — `ml/data.py` o usa (`pd.read_csv`) para carregar o WDBC e montar o
`feature_schema`; não confundir com `cryptography`, que **sai** (seção 3). `wandb`
não é usado (D7).

---

## 1. Migração do contrato de API (`/api/avaliacoes` → `/api/v1`)

### 1.1 Mudança estrutural do blueprint

O blueprint em `api/routes.py` passa de `url_prefix="/api"` para
`url_prefix="/api/v1"`. O envelope de erro muda de `{"erro", "codigo"}` para
`{"error", "code"}` (seção 5 da especificação). A função auxiliar `_erro(...)`
passa a emitir essas chaves em inglês e os `errorhandler` continuam capturando
`ErroValidacao` e `ModeloIndisponivel`, mas mapeando para os **códigos em inglês**
da tabela da especificação:

| Situação | HTTP | `code` |
|----------|------|--------|
| Entrada inválida | 400 | `VALIDATION_ERROR` |
| Sessão ausente em `/auth/me` | 401 | `UNAUTHENTICATED` |
| Recurso não encontrado | 404 | `NOT_FOUND` |
| Modelo não carregado | 503 | `MODEL_UNAVAILABLE` |
| Inferência acima de 2 s | 504 | `TIMEOUT` |
| Promoção abaixo da meta | 400 | `SENSITIVITY_BELOW_TARGET` |
| Falha não tratada | 500 | `INTERNAL_ERROR` |

O código `MEDICO_NAO_ENCONTRADO` e `AVALIACAO_NAO_ENCONTRADA` colapsam em
`NOT_FOUND`. O código `MODELO_DESCONHECIDO` colapsa em `NOT_FOUND`.

**Fallback de SPA em `app.py:frontend()` (correção do finding 3 da revisão).** Os
dois retornos JSON dessa função hoje usam chaves em português e um código fora da
tabela da seção 5 da especificação:
`{"erro": "Rota não encontrada.", "codigo": "ROTA_NAO_ENCONTRADA"}` e
`{"erro": "Frontend não compilado...", "codigo": "FRONTEND_AUSENTE"}`. Como esses
retornos ficam **fora** do blueprint `/api/v1`, não são tocados pelo `_erro(...)`
do blueprint; é preciso corrigi-los no próprio `app.py`. Decisão: **ambos passam a
usar o envelope `{"error", "code"}` em inglês**, idêntico ao do resto da API, para
não haver duas convenções de erro no mesmo serviço. O mapeamento fica:

| Retorno de `app.py:frontend()` | HTTP | corpo novo |
|-------------------------------|------|------------|
| requisição a `api`/`api/...` sem rota correspondente | 404 | `{"error": "Rota não encontrada.", "code": "NOT_FOUND"}` |
| `frontend/dist` ausente (build não rodado) | 404 | `{"error": "Frontend não compilado. Rode 'npm run build' em frontend/.", "code": "NOT_FOUND"}` |

O código `ROTA_NAO_ENCONTRADA` deixa de existir; o `FRONTEND_AUSENTE` também — o
"frontend não compilado" é um caso de recurso não encontrado e usa `NOT_FOUND`
(não há código próprio na tabela da seção 5 e não vale criar um). A mensagem em
português permanece (é texto de UI, não identificador). Opção de implementação:
extrair um helper local `_erro_app(mensagem, code, status)` em `app.py` que emite
`{"error", "code"}`, para os dois retornos compartilharem a mesma forma.

### 1.2 Mapa rota a rota

| Rota antiga (código atual) | Rota nova (especificação) | O que acontece |
|----------------------------|---------------------------|----------------|
| `GET /api/features/schema` | `GET /api/v1/features/schema` | só o prefixo muda; resposta ganha rótulos em português, unidade e exemplo por campo (seção 1.3) |
| `POST /api/biopsias/classificar` | `POST /api/v1/predictions` | renomeada; payload em inglês (seção 1.4) |
| `GET /api/avaliacoes` | `GET /api/v1/predictions` | renomeada; filtros em inglês (seção 1.5) |
| `GET /api/avaliacoes/{id}` | `GET /api/v1/predictions/{id}` | só prefixo + nome |
| `GET /api/metricas` | `GET /api/v1/models/comparison` | renomeada (seção 4) |
| `GET /api/metricas/features` | `GET /api/v1/models/features?model=&top=` | parâmetro `modelo`→`model` |
| `GET /api/metricas/export` | `GET /api/v1/models/export?format=csv` | só prefixo + nome |
| `GET /api/modelos` | `GET /api/v1/models` | só prefixo + nome |
| *(não existe)* | `POST /api/v1/training-runs` | **nova** — treino sob demanda (seção 5) |
| *(não existe)* | `GET /api/v1/training-runs/{id}` | **nova** — status da execução |
| *(não existe)* | `PUT /api/v1/models/{id}/threshold` | **nova** — ajuste de limiar + promoção (seção 5.3) |
| *(não existe)* | `POST /api/v1/auth/register` | **nova** (seção 4-auth do spec / seção 4 deste doc) |
| *(não existe)* | `POST /api/v1/auth/login` | **nova** |
| *(não existe)* | `POST /api/v1/auth/logout` | **nova** |
| *(não existe)* | `GET /api/v1/auth/me` | **nova** |

### 1.3 `GET /api/v1/features/schema`

Reaproveita `ml/data.py: feature_schema()`. A especificação pede, por campo:
`nome`, rótulo em português, unidade, `min`, `max`, exemplo. O schema atual já
devolve `nome`, `grupo`, `medida`, `min_observado`, `max_observado`, `min_aceito`,
`max_aceito` e `exemplos`. Ajuste em `feature_schema()`:

- Adicionar a cada campo `label` (rótulo em português derivado de
  `format.js: MEDIDAS`+`GRUPOS`, mas calculado no backend para o schema ser
  autossuficiente — ex.: `"Raio (média)"`) e `unit`.
- As unidades do WDBC são adimensionais/derivadas (medidas de forma e textura em
  pixels e razões). Como a base não publica unidades físicas, `unit` recebe `null`
  para todas; o frontend não exibe unidade quando `null`. Registrar isso como
  comentário no código para não dar a impressão de dado faltando.
- **Adicionar `exemplo` a cada campo (correção do finding 2 da revisão 3):** a
  especificação pede, por característica, um campo `exemplo`. O valor adotado é o
  do exemplo **maligno** daquela característica (`exemplos["maligno"][nome]`), que
  já existe no dicionário top-level `exemplos` do schema. Ou seja,
  `feature_schema()` acrescenta a cada item de `campos` um campo `exemplo` com o
  valor numérico correspondente do caso maligno. O objeto top-level `exemplos`
  (maligno/benigno) **permanece** no payload para o frontend poder preencher o
  formulário inteiro de uma vez (seletor "Exemplo Maligno" / "Exemplo Benigno");
  o `exemplo` individual apenas satisfaz a especificação ao nível de cada campo.
- **Mapeamento de `min`/`max` do contrato (correção do finding 3 da revisão 3):**
  a especificação pede `min` e `max` por característica. O schema real expõe dois
  pares: `min_observado`/`max_observado` (faixa do WDBC) e
  `min_aceito`/`max_aceito` (observado ± 20%). O contrato mapeia `min` →
  `min_observado` e `max` → `max_observado`, satisfazendo a especificação
  literalmente. Os campos `min_aceito`/`max_aceito` são **mantidos como campos
  adicionais** no payload, pois são o que a validação do servidor e do cliente
  efetivamente usam (faixa com tolerância de 20%, já implementada em
  `MARGEM_FAIXA = 0.20`). Resumindo, cada campo do schema expõe: `min` (=
  `min_observado`), `max` (= `max_observado`), `min_aceito`, `max_aceito`.

Chaves de resposta permanecem as já consumidas (`campos`, `exemplos`,
`n_caracteristicas`, `margem_faixa`); acrescenta-se `label`, `unit` e `exemplo`
por campo, e os campos `min`/`max` são acrescentados como aliases de
`min_observado`/`max_observado` (os quatro ficam no payload — `min`/`max` para o
contrato, `min_aceito`/`max_aceito` para a validação com tolerância). Não renomear
`campos`→`fields` para não quebrar sem necessidade: é payload interno, não contrato
de banco; o frontend é reescrito junto e consome as chaves atuais. **Decisão:**
manter as chaves do schema em português interno (`campos`, `grupo`, `medida`)
porque não são identificadores de recurso REST nem colunas; o custo de renomear
supera o ganho.

### 1.4 `POST /api/v1/predictions`

Substitui `classificar()`. Payload da especificação:

```json
{ "features": { "mean_radius": 17.99, "...": "(30 campos)" },
  "mode": "anonimo",
  "patient_name": null, "patient_record": null }
```

Mudanças em relação ao handler atual:

- O objeto de características deixa de ser `caracteristicas`/raiz e passa a
  `features`. O compatibilizador da Sprint 1 (aceitar características na raiz) é
  removido — contrato único.
- `modo` → `mode` (valores mantidos `anonimo`/`identificado`, que são do domínio
  em português e aparecem na coluna `mode`).
- Paciente deixa de ser objeto aninhado `paciente.{nome,prontuario}` e passa a dois
  campos planos `patient_name` e `patient_record`, como no diagrama de sequência e
  na coluna de banco.
- `medico_id` é **removido** do payload. A associação ao usuário vem da sessão
  (seção 4): o backend lê `user_id` da sessão e grava em `evaluations.user_id`
  (nullable — se não houver sessão, fica nulo, preservando RF07 "sem exigir
  identificação").

`services/validation.py` é adaptado:

- `validar_caracteristicas()` continua idêntica (opera sobre o dicionário de 30
  chaves; só muda quem o extrai do payload: `payload["features"]`).
- `validar_paciente(modo, paciente)` vira `validar_paciente(mode, patient_name,
  patient_record)` recebendo os dois campos planos. Mantém a regra: modo anônimo
  descarta qualquer dado de paciente; modo identificado exige ambos não vazios,
  com limites de tamanho (200/100). Retorna `(identificado, patient_name,
  patient_record)`.

Resposta 200 (campos em inglês da especificação):

```json
{ "evaluation_id": 1, "label": "maligno", "probability": 0.983,
  "confidence_band": "alta", "model_name": "svm", "threshold_used": 0.42,
  "elapsed_ms": 118, "disclaimer": "Ferramenta de apoio. Não substitui o laudo
  histopatológico nem a avaliação médica." }
```

Mapeamento do dicionário que `ml/predict.py: predict()` já devolve para os campos
da resposta:

| `predict()` devolve | resposta `/predictions` |
|---------------------|-------------------------|
| `classificacao` (`benigno`/`maligno`) | `label` |
| `probabilidade_maligno` | `probability` |
| `faixa_confianca` (`alta`/`media`/`baixa`) | `confidence_band` |
| `modelo_utilizado` | `model_name` |
| `limiar_utilizado` | `threshold_used` |
| *(medido no handler)* | `elapsed_ms` |
| *(fixo)* | `disclaimer` |

`predict()` **não muda**: mantém `P(maligno) >= limiar` (nunca `predict()`),
`StandardScaler` antes da inferência, faixas de confiança `alta`/`media`/`baixa`.
O rótulo da faixa `media` é normalizado para exibição no frontend como "média".
O campo interno `acionou_limiar_seguranca` continua útil para a nota de UI e pode
ir na resposta como extra não contratual, mas **não** faz parte do contrato — o
frontend o trata como opcional.

Comportamento obrigatório mantido/ajustado:
- Timeout: se `elapsed_ms > 2000`, retornar **504 `TIMEOUT`** com log estruturado,
  **em vez de** apenas marcar `excedeu_limite_tempo` como hoje. Decisão: a
  especificação (seção 5) e o diagrama tratam estouro de 2 s como erro 504, então
  o handler passa a devolver 504 quando o relógio estoura. Como a inferência em
  memória é de milissegundos, isso é um guarda de segurança; o teste de RNF02
  (seção 8) verifica o caminho feliz < 2 s e, com um modelo falso lento, o 504.
  Em ambos os casos de falha (503/504) a resposta não grava `evaluations`.
- Modelo ausente → 503 `MODEL_UNAVAILABLE` (via `ModeloIndisponivel`).
- Gravação transacional: a avaliação só é persistida após `predict()` ter êxito; o
  commit precede a resposta (já é assim em `services/avaliacoes.py: registrar`).

### 1.5 `GET /api/v1/predictions` (histórico) e `/{id}`

Substituem `listar_avaliacoes()` e `obter_avaliacao()`. Os filtros passam para o
vocabulário em inglês da especificação, e `services/validation.py:
validar_filtros_historico()` é reescrita para esse vocabulário:

| Filtro antigo | Filtro novo (spec) | Observação |
|---------------|--------------------|------------|
| `pagina` | `page` | default 1 |
| `limite` | `limit` | default 25, máx. 100 (hoje default 25/máx. 100 já) |
| `classificacao` (`benigno`/`maligno`) | `label` | mesmos valores |
| `identificado` (`true`/`false`) | `mode` (`anonimo`/`identificado`) | passa a filtrar por `mode`, coerente com a coluna |
| `data_inicio` | `date_from` | `AAAA-MM-DD`, início do dia |
| `data_fim` | `date_to` | `AAAA-MM-DD`, inclusiva (limite aberto no dia seguinte, lógica atual mantida) |
| `confianca_min` | `confidence_min` | 0–1 |
| `confianca_max` | `confidence_max` | 0–1 |

Resposta passa do formato atual
`{"itens", "paginacao": {pagina, limite, total, paginas}}` para o formato da
especificação:

```json
{ "items": [...], "page": 1, "limit": 25, "total": 137 }
```

Ou seja, `itens`→`items` e os campos de paginação sobem para a raiz com nomes em
inglês. `services/avaliacoes.py: listar()` é ajustado para montar esse envelope.
O número de páginas deixa de ser enviado (o cliente calcula a partir de `total`,
`limit`), simplificando o contrato conforme a especificação.

Cada item do histórico expõe, em inglês, as colunas de `evaluations`
(seção 2.2). O detalhe de paciente aparece **em texto** (sem decifragem, pois a
criptografia é removida — seção 3): `patient_name` e `patient_record` vêm direto
da coluna quando `mode == "identificado"`, ou `null` quando anônimo. O caminho de
"indisponível/ilegível" do código atual é removido.

Exemplo de item da lista (correção do finding 11 da revisão — inclui `confidence`,
a coluna numérica mantida na seção 2.2 que sustenta os filtros
`confidence_min/max`):

```json
{ "id": 42, "label": "maligno", "probability": 0.983, "confidence": 0.983,
  "confidence_band": "alta", "model_name": "svm", "threshold_used": 0.42,
  "mode": "identificado", "patient_name": "Fulana de Tal",
  "patient_record": "PRT-0042", "elapsed_ms": 118,
  "created_at": "2026-10-09T21:24:00-03:00" }
```

Para um item anônimo, `mode: "anonimo"` e `patient_name`/`patient_record` são
`null`. O valor de `confidence_band` é sempre a chave de API **sem acento**
(`alta`/`media`/`baixa`); nenhum filtro ou payload usa a forma acentuada "média" —
ela existe só na exibição do frontend (finding 12 da revisão; ver também seção 10,
pendência 3).

### 1.6 O que reaproveitar de cada service

- **`services/validation.py`** — reaproveitado quase inteiro. `validar_
  caracteristicas()` fica idêntica. `validar_paciente()` muda a assinatura para
  campos planos. `validar_filtros_historico()` muda os nomes dos parâmetros para
  inglês (tabela 1.5) e troca o filtro `identificado` por `mode`. Os helpers
  `_int_param`, `_float_param`, `_data_param` ficam idênticos. Códigos de erro de
  `ErroValidacao` passam a `VALIDATION_ERROR` por padrão.
- **`services/avaliacoes.py`** — reaproveitado. `registrar()` perde os parâmetros
  `nome_cif`/`prontuario_cif` e a chamada a `crypto.cifrar`; grava `patient_name`/
  `patient_record` em texto. `medico_id` vira `user_id`. **`elapsed_ms` passa a ser
  gravado como inteiro** (correção do finding 7 da revisão): o código atual grava
  `tempo_resposta_ms=round(tempo_ms, 2)` (Float) numa coluna `db.Float`; como a
  coluna nova `elapsed_ms` é `Integer` (seção 2.2) e o contrato mostra
  `"elapsed_ms": 118` (inteiro, seção 1.4), `registrar()` passa a gravar
  `elapsed_ms=round(tempo_ms)` (inteiro de milissegundos), sem casas decimais.
  `paciente_decifrado()`
  é **excluída** (não há mais o que decifrar); `listar()`/`obter()` passam a ler os
  campos de paciente direto do registro e a montar o envelope `items/page/limit/
  total`. `medico_existe()` é removida (associação vem da sessão).
- **`services/modelos.py`** — reaproveitado como camada de leitura/sincronização de
  `trained_models`. `sincronizar_modelos()` passa a popular a tabela
  `trained_models` com as novas colunas (seção 2.3) e a ligar cada modelo ao
  `training_run_id` correspondente. `modelo_registrado_mais_recente()` passa a
  consultar `trained_models`. Ganha funções novas para o treino sob demanda
  (seção 5).

---

## 2. Migração do modelo de dados

A troca de nomes vale para tabela, colunas e relacionamentos. Como SQLite não
suporta `ALTER` rico e o banco de desenvolvimento é descartável, **não há
migração de linhas**: `db.create_all()` recria o schema novo em banco limpo.
Registrar no README que bancos antigos devem ser recriados (apagar o `.db` local;
no PostgreSQL, recriar o schema). Não é um sistema em produção com dados a
preservar (ver aviso de segurança da seção 9 da especificação).

### 2.1 Compatibilidade PostgreSQL ↔ SQLite (D5)

Regras de tipos que funcionam nos dois bancos via SQLAlchemy, sem dialeto
específico:

- **JSON**: usar `db.JSON` (SQLAlchemy mapeia para `JSONB`/`JSON` no PostgreSQL e
  para `TEXT` com serialização automática no SQLite). Já é o tipo usado hoje.
  Evitar `postgresql.JSONB` explícito, que quebra no SQLite.
- **Datas**: `db.DateTime(timezone=True)` com default em `datetime.now(timezone.
  utc)` (helper `_agora` atual). No SQLite o tz é preservado como string ISO; no
  PostgreSQL vira `timestamptz`. Manter.
- **Boolean, Integer, Float, String, Text**: portáveis sem ajuste.
- **Chave primária**: `Integer primary key autoincrement` (padrão do SQLAlchemy),
  portável.
- **Índices compostos**: declarados via `db.Index` em `__table_args__`, portáveis.
- **Unicidade**: `unique=True` em `users.email` e `trained_models.artifact_sha256`,
  portável.
- Não usar `server_default` com SQL específico de dialeto; usar `default` no nível
  Python.

A seleção do banco permanece em `app.py`: `DATABASE_URL` quando presente, senão
`sqlite:///tcc_cancer_mama.db` (D5). O driver PostgreSQL passa de
`psycopg2-binary` para `psycopg` (v3), coerente com a seção 9 da especificação
("psycopg"); a URL `postgresql+psycopg://...` seleciona o driver v3. Documentar as
duas formas de URL no `.env.example`.

### 2.2 `Medico` + `Pesquisador` + `Avaliacao` → `users` + `evaluations`

As duas tabelas de ator viram uma só, `users`, com a coluna `profile`
discriminando o papel (D3 — perfil declarado, sem trava). `Avaliacao` vira
`evaluations`.

Classe `User` (`users`):

| coluna | tipo | origem/observação |
|--------|------|-------------------|
| `id` | Integer PK | — |
| `name` | String(120) | de `Medico.nome` |
| `email` | String(120) unique not null | de `Medico.email` |
| `password_hash` | String(255) | **novo** (seção 4). 255 cobre o hash pbkdf2 do werkzeug |
| `profile` | String(20) not null | `"medico"` \| `"pesquisador"` |
| `created_at` | DateTime(tz) default agora | **novo** |

Classe `Evaluation` (`evaluations`) — imutável (os listeners `before_update`/
`before_delete` que hoje bloqueiam alteração são **mantidos**, pois a
especificação diz "não pode ser alterado nem removido pela aplicação"):

| coluna atual (`avaliacoes`) | coluna nova (`evaluations`) | tipo |
|-----------------------------|-----------------------------|------|
| `id` | `id` | Integer PK |
| `medico_id` (FK medicos) | `user_id` (FK users, nullable) | Integer |
| `caracteristicas` | `features` | JSON (as 30) |
| `classificacao` | `label` | String(10) (`benigno`/`maligno`) |
| `probabilidade_maligno` | `probability` | Float |
| `faixa_confianca` | `confidence_band` | String(10) |
| `modelo_id` → nome via join | `model_name` | String(60) |
| `limiar_utilizado` | `threshold_used` | Float |
| `identificado` (bool) + modo | `mode` | String(15) (`anonimo`/`identificado`) |
| `paciente_nome_cifrado` | `patient_name` | Text, nullable, **texto puro** |
| `paciente_prontuario_cifrado` | `patient_record` | Text, nullable, **texto puro** |
| `tempo_resposta_ms` | `elapsed_ms` | Integer (RNF02) |
| `criado_em` | `created_at` | DateTime(tz) |
| `confianca` (float) | *(removida)* | — veja nota |
| `modelo_id` (FK) | *(removida)* | substituída por `model_name` |

Nota sobre `confidence`/`confianca`: a especificação (seção 2.2 do spec) lista
`probability` e `confidence_band`, mas **não** uma coluna numérica de confiança. O
filtro de histórico, porém, pede `confidence_min`/`confidence_max` (seção 5 do
spec). **Pendência detectada na especificação** (ver seção 10): sem uma coluna
numérica de confiança não há como filtrar por faixa de confiança no banco. Decisão
de design: **manter uma coluna `confidence` (Float)** em `evaluations`, derivada
como hoje (`P` se maligno, `1-P` se benigno), para suportar `confidence_min/max`.
Ela não precisa ir no corpo contratual da predição (o `confidence_band` basta para
exibição), mas existe no banco e nos itens do histórico. Isso resolve a lacuna sem
contrariar o espírito da especificação; a seção 10 registra a correção a aplicar
no arquivo-fonte.

`mode` substitui o par `identificado`+implícito: `anonimo` quando o registro é
anônimo, `identificado` quando tem paciente. O booleano deixa de existir; o
frontend e os filtros usam `mode`.

Índices de `evaluations` (correção do finding 8 da revisão). Os dois índices
atuais de `Avaliacao` **são removidos** porque referenciam colunas renomeadas e um
filtro que mudou de forma:

- `ix_avaliacoes_criado_classe` (`criado_em`, `classificacao`) → **removido**
  (substituído por `ix_evaluations_label_created` sobre as colunas em inglês).
- `ix_avaliacoes_classe_confianca` (`classificacao`, `confianca`) → **removido**
  (substituído por `ix_evaluations_label_confidence`, abaixo).

O `__table_args__` de `Evaluation` passa a declarar explicitamente (lista
completa, sem herança do schema antigo):

```python
db.Index("ix_evaluations_created_at", "created_at")                 # ordenação padrão
db.Index("ix_evaluations_label_created", "label", "created_at")     # filtro por classe + período
db.Index("ix_evaluations_mode_created", "mode", "created_at")       # filtro por modo + período
db.Index("ix_evaluations_label_confidence", "label", "confidence")  # filtro combinado classe + confiança
```

Os três primeiros vêm direto da seção 2.2 do spec (Figura do Histórico). O quarto
é **decisão deste design**: como o filtro `confidence_min`/`confidence_max`
permanece (apoiado na coluna `confidence`, ver nota abaixo) e costuma combinar com
`label`, mantém-se um índice `(label, confidence)` — herdeiro funcional do antigo
`(classificacao, confianca)` — para não degradar esse filtro. Não há índice só por
`confidence` isolado: o uso previsto é sempre com `label` ou com período, já
cobertos.

A ordenação "mais recentes primeiro" usa `created_at desc, id desc` (desempate
estável), como hoje.

### 2.3 `ModeloTreinado` → `trained_models` + nova `training_runs`

`ModeloTreinado` vira `trained_models` e ganha colunas que hoje não existem
(métricas desagregadas, limiar operacional, ROC e matriz, caminho do artefato,
ligação à execução). Surge `training_runs` para registrar cada disparo de treino
(D6).

Classe `TrainedModel` (`trained_models`):

| coluna | tipo | origem/observação |
|--------|------|-------------------|
| `id` | Integer PK | — |
| `training_run_id` | Integer FK training_runs | **novo** |
| `name` | String(60) index | de `nome` (`regressao_logistica`/`svm`) |
| `accuracy` | Float | de `metricas.teste_operacao.acuracia` |
| `sensitivity` | Float | de `teste_operacao.sensibilidade` |
| `specificity` | Float | de `teste_operacao.especificidade` |
| `auc` | Float | de `teste_operacao.auc` |
| `false_negative_rate` | Float | de `teste_operacao.taxa_falsos_negativos` (RNF04) |
| `threshold` | Float | ponto de operação vigente (começa = `safety_threshold`) |
| `safety_threshold` | Float | de `limiar_seguranca` |
| `hyperparameters` | JSON | de `hiperparametros` |
| `random_seed` | Integer | de `semente` (42) |
| `artifact_path` | String(255) | **novo** — `artifacts/{model_id}.joblib` |
| `artifact_sha256` | String(64) unique | de `hash_sha256` |
| `is_production` | Boolean default False | de `em_producao` |
| `roc_points` | JSON | de `metrics.json: modelos[nome].roc` — **mesmo objeto** `{"fpr":[...],"tpr":[...]}` (ver nota abaixo) |
| `confusion_matrix` | JSON | de `teste_operacao.matriz_confusao` |
| `trained_at` | DateTime(tz) | de `treinado_em` |

A distinção `threshold` (vigente, ajustável via `PUT .../threshold`) vs
`safety_threshold` (o limiar calculado no treino) permite ao pesquisador mover o
ponto de operação pelo slider, sempre validado pela regra dos 0,97.

> **Nota de 22/10/2026 (D11/D12) — acréscimos ao esquema, sem reabrir decisão.**
> A tabela acima ganhou a coluna `train_oof_sensitivity` (Float, nullable):
> sensibilidade das predições out-of-fold do **treino** avaliada no `threshold`
> da própria linha, que é o portão do RNF04. As colunas `accuracy`,
> `sensitivity`, `specificity`, `false_negative_rate` e `confusion_matrix`
> passaram a significar, **sem exceção**, conjunto de teste no `threshold`
> vigente — vale a invariante `sensitivity == vp/(vp+fn)` e
> `false_negative_rate == fn/(vp+fn)` sobre a própria matriz. Antes, o `PUT`
> gravava o valor out-of-fold em `sensitivity` e deixava as outras métricas do
> limiar anterior, misturando dois conjuntos de avaliação na mesma linha.
>
> `artifact_sha256` **perdeu** o `unique` e ficou apenas como procedência
> (RNF03), com índice. A unicidade passou a ser a restrição de tabela
> `UniqueConstraint("training_run_id", "name", name="uq_trained_models_run_name")`
> — uma linha por (execução, modelo). Motivo: dois treinos deterministas com a
> mesma semente e os mesmos dados produzem legitimamente os mesmos bytes, e o
> desvio de "reaproveitar o registro quando o hash coincide" fazia
> `artifact_path` apontar para a referência 80/20 em modelos nascidos de
> execuções 70/30. Restrição de tabela declarada em `__table_args__` é criada
> igual por `create_all()` em PostgreSQL e em SQLite, coerente com §2.1.
> Aplicação por recriação de schema, como já previsto em §2 (sem Alembic).

**Forma fixa de `roc_points` (correção do finding 3 da revisão).** A coluna
`trained_models.roc_points` armazena **exatamente o mesmo objeto** que
`ml/train.py` já produz em `metrics.json: modelos[nome].roc`, ou seja
`{"fpr": [...], "tpr": [...]}` — duas listas paralelas de mesmo comprimento (os
pontos da curva ROC), **não** uma lista de pares `[[fpr, tpr], ...]`. Essa forma é
preservada ponta a ponta: a sincronização/treino grava o objeto como veio do
artefato, e `GET /models/comparison` (§5.4) o expõe sob a chave `roc_points` com a
mesma estrutura `{"fpr", "tpr"}`. Decisão deliberada de **não** reformatar: o
frontend (`RocChart`/`charts.jsx`) e `ml/report.py: gerar_figuras()` já consomem
`r["roc"]["fpr"]`/`r["roc"]["tpr"]`; manter a forma evita quebrar o gráfico e a
exportação. O único renome é a *chave de nível superior* no corpo da API
(`roc` → `roc_points`); o objeto interno `{"fpr","tpr"}` fica intacto.

Classe `TrainingRun` (`training_runs`) — **nova**:

| coluna | tipo | observação |
|--------|------|------------|
| `id` | Integer PK | retornado por `POST /training-runs` |
| `models_requested` | JSON | ex.: `["regressao_logistica","svm"]` |
| `test_size` | Float | de `train_config.test_size` |
| `random_seed` | Integer | 42 |
| `grid_search` | Boolean | se usou GridSearchCV |
| `dataset_sha256` | String(64) | SHA-256 de `data/wdbc.data` |
| `split` | JSON | índices das partições (de `split.json`) |
| `library_versions` | JSON | de `train_config.json: versoes` — exatamente as 4 chaves já existentes: `python`, `scikit_learn`, `numpy`, `joblib` (ver nota) |
| `git_commit` | String(40) | de `_commit_git()` |
| `status` | String(10) | `running`\|`success`\|`failed` |
| `error_message` | Text nullable | quando `failed` |
| `started_at` | DateTime(tz) | — |
| `finished_at` | DateTime(tz) nullable | — |

**Escopo de `library_versions` (correção do finding 7 da revisão).** O campo reusa
**exatamente** as quatro chaves que `ml/train.py` já grava em
`train_config.json["versoes"]` — `python`, `scikit_learn`, `numpy`, `joblib` — sem
incluir Flask, pandas ou matplotlib. É suficiente para a reprodutibilidade do
**experimento de ML** (que é o que RNF03 cobra: semente, partições,
hiperparâmetros e versões das bibliotecas *de treino/avaliação*), e o design não
amplia o conjunto para não introduzir divergência entre o que o treino registra e
o que a coluna guarda. Se o avaliador exigir o ambiente completo, a ampliação é um
ajuste pontual em `ml/train.py` (acrescentar as versões ao dicionário `versoes`),
mas fica **fora** deste escopo por ora.

Relacionamento: um `TrainingRun` tem muitos `TrainedModel`
(`training_run_id` FK). `Evaluation.model_name` guarda apenas o nome do modelo que
classificou (string), não uma FK — a especificação lista `model_name` como texto,
e isso evita acoplar o histórico imutável ao ciclo de vida dos modelos.

### 2.4 `app.py` e sincronização inicial

`db.create_all()` passa a criar `users`, `evaluations`, `trained_models`,
`training_runs`. Na subida, `sincronizar_modelos()` (seção 5.4) importa os
artefatos pré-treinados existentes em `ml/artifacts/` para `trained_models`,
criando um `TrainingRun` sintético de `status="success"` que os representa (origem
"treino inicial versionado"), de modo que a predição funcione imediatamente após
clonar o repositório, sem exigir um treino sob demanda primeiro. O modelo marcado
`is_production` é o `melhor_modelo` do `metrics.json`.

**Origem por coluna do `TrainingRun` sintético (correção do finding 1 da revisão
3).** Como `training_run_id` é FK **obrigatória** em `trained_models`, a
sincronização só consegue popular `trained_models` se cada campo do `TrainingRun`
sintético tiver origem definida. O run sintético é montado a partir dos artefatos
já versionados (`metrics.json`, `train_config.json`, `split.json`), coluna a
coluna:

| coluna de `training_runs` | valor no run sintético |
|---------------------------|------------------------|
| `status` | `'success'` |
| `models_requested` | `list(metrics['modelos'].keys())` |
| `test_size` | `train_config['test_size']` |
| `random_seed` | `train_config['random_state']` |
| `grid_search` | `False` (os artefatos versionados não usaram `GridSearchCV`) |
| `dataset_sha256` | `train_config['hashes_sha256']['dataset']` |
| `split` | conteúdo de `split.json` |
| `library_versions` | `train_config['versoes']` |
| `git_commit` | `train_config['commit_git']` |
| `started_at` | `metrics['gerado_em']` |
| `finished_at` | `metrics['gerado_em']` |
| `error_message` | `None` |

Como o run sintético representa um treino já concluído (os artefatos existem),
`started_at` e `finished_at` recebem ambos o instante `metrics['gerado_em']`, e
`error_message` é nulo por ser `status='success'`.

**Regeneração do vetor out-of-fold na sincronização (correção do finding 1 da
revisão).** A regra de promoção `PUT /models/{id}/threshold` (seção 5.3) recalcula
a sensibilidade a partir das predições out-of-fold do treino, lidas de
`{model}_oof.json` (seção 6). Esse arquivo **não existe** hoje em `ml/artifacts/`
(só há `metrics.json`, `feature_importance.json`, `split.json`,
`train_config.json`, `scaler.joblib`, `{model}.joblib`) — ele passa a ser gravado
pelo treino sob demanda (seção 6), mas os modelos pré-semeados importados na subida
nasceriam **sem** OOF, e a promoção falharia justamente no estado padrão pós-clone.
Decisão: **a sincronização inicial recomputa e grava `{model}_oof.json` quando ele
estiver ausente**, de forma determinística, a partir dos artefatos já versionados.

**Chaves reais dos artefatos (correção dos findings 1 e 2 da revisão).** O
`ml/artifacts/split.json` versionado **não** usa `train_idx`/`test_idx`: as chaves
reais, gravadas por `ml/train.py`, são `random_state`, `treino` e `teste` (em
português, listas de índices das linhas do dataset). O design **mantém** essas
chaves em português no `split.json` — não as renomeia — porque o arquivo já está
versionado e os modelos pré-semeados dependem dele; renomear quebraria a leitura
no estado padrão pós-clone sem ganho. (A coluna `training_runs.split`, essa sim em
inglês no banco, recebe o conteúdo de `split.json` como JSON, sem exigir que as
chaves internas mudem.)

Além disso, o `modelo_base` do OOF **não** vem de `metrics.json`: esse artefato
**não contém hiperparâmetros** (só `limiar_padrao`/`limiar_seguranca`,
`teste_padrao`, `teste_operacao`, `validacao_cruzada`, `roc`). Os estimadores
efetivamente ajustados estão persistidos nos próprios `.joblib`, e os
hiperparâmetros também em `train_config.json["hiperparametros"][model]`. Para o OOF
ser **idêntico** ao do treino, o `modelo_base` é obtido clonando o estimador
carregado do `.joblib` (`clone(joblib.load(ml/artifacts/{model}.joblib))`), que já
traz todos os `get_params()` persistidos — não se remonta o objeto a partir de um
dicionário parcial de hiperparâmetros:

```python
# para cada modelo pré-semeado sem {model}_oof.json:
#   split      = json.load(ml/artifacts/split.json)   # chaves: random_state, treino, teste
#   idx_treino = split["treino"]                       # índices das linhas de treino
#   X_train, y_train = X[idx_treino], y[idx_treino]
#   modelo_base = clone(joblib.load(ml/artifacts/{model}.joblib))  # mesmos get_params do treino
#   oof = cross_val_predict(
#       make_pipeline(StandardScaler(), modelo_base),
#       X_train, y_train,
#       cv=StratifiedKFold(n_splits=5, shuffle=True, random_state=42),
#       method="predict_proba")[:, 1]
#   grava {model}_oof.json = {"y_true": y_train.tolist(), "proba": oof.tolist()}
```

Como a semente é 42, o `split.json` fixa os índices de treino e o `modelo_base`
sai do próprio `.joblib`, o OOF regenerado é idêntico ao que o treino produziria —
não há risco de divergência. Alternativa considerada e **rejeitada**: versionar os
`{model}_oof.json` junto aos artefatos — rejeitada porque exigiria regerar e
commitar binários a cada treino e deixaria o repositório inconsistente se alguém
retreinasse localmente sem recommit; a regeneração determinística na subida é mais
robusta e não depende de nada fora de `split.json` + `scaler.joblib` +
`{model}.joblib`. Em qualquer caso, uma vez gravado, o `{model}_oof.json` é
reutilizado nas subidas seguintes (não recomputa a cada boot).

---

## 3. Remoção da criptografia AES-256-GCM (D2)

A criptografia sai **inteira**. Itens a remover, com o efeito de cada um:

1. **`services/crypto.py`** — arquivo excluído por completo (classes
   `CryptoConfigError`, `CryptoDecryptError`, funções `gerar_chave`,
   `_carregar_chave`, `cifrar`, `decifrar`, `__main__`).
2. **`services/avaliacoes.py`** — remover `from services import crypto`; em
   `registrar()`, remover o bloco que cifra nome/prontuário e gravar
   `patient_name`/`patient_record` em texto; excluir `paciente_decifrado()`;
   `listar()`/`obter()` leem os campos direto.
3. **`api/routes.py`** — remover `from services import crypto`, o
   `@api_bp.errorhandler(crypto.CryptoConfigError)` e seu handler, a chamada
   "falha cedo" `crypto.cifrar("verificacao")`, e o código de erro
   `ENCRYPTION_UNAVAILABLE` (deixa de existir).
4. **`.env.example`** — remover a variável `PACIENTE_ENCRYPTION_KEY` e o comentário
   de geração de chave. Resultado: `DATABASE_URL` (com as duas formas de URL
   PostgreSQL/psycopg documentadas), `CORS_ORIGINS` (origens explícitas do frontend,
   seção 4.0), `SECRET_KEY` (assinatura da sessão, seção 4) e, opcionalmente,
   `SESSION_COOKIE_SECURE`. Nenhuma variável de criptografia permanece.
5. **`app.py`** — remover do docstring a menção a `PACIENTE_ENCRYPTION_KEY`.
6. **`requirements.txt`** — remover `cryptography`. Confirmar que nenhum outro
   módulo a importa (busca por `import cryptography`/`from cryptography`); hoje só
   `services/crypto.py` usa, então fica órfã e é removida.
7. **Frontend** — na tela Classificar, remover a frase "armazenados cifrados
   (AES-256-GCM), conforme a LGPD"; substituir por aviso honesto de que, no modo
   identificado, nome e prontuário são gravados em texto e a ferramenta não deve
   ser exposta fora de ambiente controlado (coerente com o aviso de segurança da
   seção 9 da especificação).

O modo identificado **continua existindo**: a diferença é só que os campos são
persistidos em claro. A validação de paciente (campos obrigatórios, limites de
tamanho) é preservada.

---

## 4. Autenticação simples (D3, D4)

Sem JWT, sem RBAC, sem auditoria. Apenas cadastro e login com **sessão de servidor
baseada em cookie** (`flask.session`, assinada por `SECRET_KEY`). Decisão entre
sessão de cookie e token: a especificação fala em "cookie de sessão" no `POST
/login`, então usa-se `flask.session` — simples, sem dependência nova, e o cookie
`HttpOnly` já vem assinado. `SECRET_KEY` entra como variável de ambiente
(`.env.example`), com fallback de desenvolvimento gerado em memória (com aviso em
log quando ausente).

Novo módulo `services/auth.py` e novo arquivo de rotas de auth dentro de
`api/routes.py` (ou um blueprint auxiliar registrado sob o mesmo `/api/v1`).

### 4.0 CORS e cookie de sessão entre origens (correção do finding 2 da revisão)

O cookie de sessão (seção 7.5 do frontend usa `credentials: "include"`) só
funciona entre origens distintas — em desenvolvimento o Vite serve em
`http://localhost:5173` e o Flask em `http://localhost:5000` — se o CORS for
ajustado. A configuração atual de `app.py`
(`CORS(app, resources={r"/api/*": {"origins": os.environ.get("CORS_ORIGINS","*").split(",")}})`)
é **incompatível** com credenciais: com origem curinga `*` e **sem**
`supports_credentials`, o navegador recusa a resposta e não envia o cookie,
quebrando o login em dev. Correções obrigatórias em `app.py`:

- `CORS(app, resources={r"/api/*": {"origins": <lista explícita>}}, supports_credentials=True)`.
  Com credenciais, `origins` **nunca** pode ser `*`; passa a ler `CORS_ORIGINS`
  como lista de origens explícitas (default de dev: `http://localhost:5173`), e o
  valor `*` deixa de ser aceito nesse contexto.
- Configuração de cookie coerente com dev: `SESSION_COOKIE_SAMESITE = "Lax"` e
  `SESSION_COOKIE_SECURE = False` em desenvolvimento (HTTP). Em produção atrás de
  HTTPS, `SESSION_COOKIE_SECURE = True`; se front e API ficarem em origens
  cross-site reais, `SameSite="None"` + `Secure=True`. Esses valores vêm de
  variável de ambiente com default de dev, e o aviso de segurança da seção 9 da
  especificação (não expor fora de ambiente controlado) permanece.
- `.env.example` passa a documentar `CORS_ORIGINS` (ex.: `http://localhost:5173`),
  `SECRET_KEY` e, opcionalmente, `SESSION_COOKIE_SECURE`.

Em produção servindo o frontend compilado pelo próprio Flask (mesma origem, seção
2.4 / rota `frontend`), o CORS deixa de ser exercido e o cookie viaja same-site
naturalmente — o ajuste acima é o que mantém o fluxo de dev funcional sem reduzir
a segurança (nunca `*` com credenciais).

### 4.1 Senha (D4)

Hash com `werkzeug.security.generate_password_hash` (pbkdf2 por padrão) e
verificação com `check_password_hash`. Nunca texto puro. Sem bcrypt (era parte do
pacote JWT removido). O `password_hash` cabe em `String(255)`.

### 4.2 Rotas

- `POST /api/v1/auth/register` — corpo `{name, email, password, profile}`.
  Validação: `name` não vazio (≤120); `email` formato simples e único (checar
  duplicidade → 400 `VALIDATION_ERROR` com mensagem "e-mail já cadastrado");
  `password` mínimo 8 caracteres; `profile ∈ {medico, pesquisador}`. Cria o
  usuário com `password_hash`, abre sessão e devolve **201** `{user: {id, name,
  email, profile}}` (sem `password_hash`).
- `POST /api/v1/auth/login` — `{email, password}`. Se e-mail não existe ou senha
  não confere → **401** `UNAUTHENTICATED` com mensagem genérica ("credenciais
  inválidas", sem revelar qual campo falhou). Sucesso → **200** `{user}` + cookie
  de sessão.
- `POST /api/v1/auth/logout` — limpa a sessão → **204**.
- `GET /api/v1/auth/me` — usuário da sessão (`{user}`), ou **401**
  `UNAUTHENTICATED` se não autenticado.

### 4.3 Sem trava de autorização

Nenhuma rota é bloqueada por perfil. `/predictions`, `/training-runs`,
`/models/*`, `/predictions` (histórico) são acessíveis a qualquer sessão. O
`profile` serve só para o frontend decidir o menu (seção 7). O `user_id` da sessão
é gravado em `evaluations.user_id` quando houver sessão; requisições sem sessão
ainda classificam e gravam com `user_id = null` (RF07). Decisão: **não exigir
login para classificar** mantém o RF07 ("mantém histórico, sem exigir
identificação do paciente") e o espírito de "sem trava"; o login existe para
personalizar o menu e associar autoria quando presente. Registrar essa escolha no
README.

> **Superado — decisão anterior mantida acima apenas como histórico.**
>
> **Revisto (correções pós-revisão, D10):** todas as rotas de dados passam a
> exigir sessão válida (401 `UNAUTHENTICATED`); `/auth/*` segue pública. O RF07
> (histórico sem exigir identificação **do paciente**) continua atendido pelo
> modo anônimo; `evaluations.user_id` passa a ser sempre preenchido (a coluna
> segue `nullable=True` pelo modelo de dados e por causa de linhas antigas).
> Continua sem qualquer trava por perfil (D3): um médico autenticado chama as
> rotas do pesquisador e vice-versa. O motivo da revisão: as rotas de dados
> respondiam 200 sem nenhum cookie, e o modo identificado grava nome e
> prontuário de paciente em texto (D2).

### 4.4 Invariantes e sua camada de dono

- Unicidade de e-mail: dono é o banco (`unique=True`) + checagem amigável no
  service antes do insert (para devolver 400 em vez de 500 em corrida perdida, o
  `IntegrityError` é capturado e convertido em `VALIDATION_ERROR`).
- Imutabilidade de `evaluations`: dono é a camada ORM (listeners
  `before_update`/`before_delete`).
- "Senha nunca em texto": dono é `services/auth.py` (único ponto que grava
  `password_hash`); nenhuma rota aceita gravar senha crua.

---

## 5. Treino sob demanda e promoção (D6, RNF04)

### 5.1 `POST /api/v1/training-runs`

Corpo: `{ "models": ["regressao_logistica", "svm"], "test_size": 0.2,
"grid_search": true, "hyperparameters": {...} }`. Resposta **201**
`{training_run_id}`.

**Validação do corpo e erros (correção do finding 6 da revisão).** Antes de criar
o `training_runs`, o handler valida o corpo e, em qualquer falha, devolve **400
`VALIDATION_ERROR`** sem iniciar treino:

| Campo | Regra | Falha → `VALIDATION_ERROR` |
|-------|-------|----------------------------|
| `models` | subconjunto **não vazio** de `{"regressao_logistica", "svm"}` | vazio, nome desconhecido, não-lista |
| `test_size` | float em `(0, 0.5]`, default `0.2` | fora da faixa, não numérico |
| `grid_search` | boolean, default `true` | tipo não booleano |
| `hyperparameters` | objeto opcional; chaves que **não** correspondem às grades da seção 5.2 são **ignoradas** (não erro) | não-objeto |

Decisão sobre falha **durante** o treino (exceção do scikit-learn, dataset
ausente): o `training_runs` já criado é atualizado para `status="failed"` com
`error_message` preenchido, e a resposta é **201** com o corpo do run falho
(`{training_run_id, status: "failed", error_message}`). Justificativa: coerente com
a execução síncrona (o run existe e é consultável) e com o `GET /training-runs/{id}`,
que reflete o mesmo `status`. Não se usa 500 `INTERNAL_ERROR` aqui porque a falha
de treino é um resultado esperado e registrado, não um erro não tratado do
servidor; `INTERNAL_ERROR` fica reservado para exceções fora do fluxo de treino
(ex.: falha ao gravar o próprio `training_runs`).

Execução: **síncrona** dentro do request. Justificativa da escolha entre síncrono
e assíncrono: treinar os dois modelos sobre 569 linhas com `GridSearchCV` de 5
folds leva segundos em CPU; não há volume que justifique fila ou worker, e manter
síncrono evita introduzir Celery/thread-pool (fora do escopo e do prazo). O
registro `training_runs` é criado com `status="running"` **antes** de treinar
(commit imediato, para o `GET /training-runs/{id}` refletir o andamento se o
cliente consultar), e atualizado para `success`/`failed` ao final. Como é
síncrono, a resposta 201 só volta quando o treino termina; o `status` no corpo
reflete o resultado. O `GET` existe para o frontend reconsultar e para o caso de
falha.

O treino reusa `ml/train.py` com uma refatoração mínima: `train_and_evaluate()`
passa a aceitar `models` (subconjunto de `MODELS`), `test_size`, `grid_search` e
`hyperparameters`, e a **retornar** o dicionário de métricas + o caminho dos
artefatos, em vez de só escrever em disco. A escrita dos artefatos
(`{model}.joblib`, `scaler.joblib`, `{model}_oof.json`, os JSON) é mantida para a
exportação científica e a reprodutibilidade (RNF03).

**Exportação científica em 300 DPI acionada pelo treino (correção do finding 4 da
revisão).** A especificação §6/RNF03 exige "curvas ROC, matrizes de confusão e
ranking de características em **300 DPI**, mais CSV, em `ml/artifacts/report/`",
produzidos por `ml/report.py: gerar_figuras()` (que usa `DPI = 300`). Como o treino
sob demanda pode gerar métricas diferentes das versionadas (outro `test_size`,
subconjunto de modelos, grade), as figuras versionadas ficariam defasadas em
relação ao run. Decisão: **o handler de `POST /training-runs`, ao concluir o treino
com `status="success"`, chama `ml/report.gerar_figuras()` (que também regera o CSV
via `metricas_csv()`), regerando `ml/artifacts/report/*` a partir do `metrics.json`
recém-escrito**, para que a exportação reflita o run mais recente. `gerar_figuras()`
lê os artefatos de `ml/artifacts/` que o treino acabou de gravar, então a chamada
vem **depois** da escrita de `metrics.json`/`feature_importance.json` e antes de
marcar o run como `success`. Se `gerar_figuras()` falhar (ex.: backend matplotlib
indisponível no ambiente de execução), isso **não** derruba o run — o treino em si
teve êxito e os modelos foram gravados em `trained_models`; a falha de figura é
registrada em log estruturado (nível `warning`) e o run permanece `success`. As
figuras são artefato de exportação, não condição de sucesso do treino; essa
separação evita que um problema de renderização bloqueie a promoção de um modelo
válido. O `GET /models/export?format=csv` (§5.4) continua servindo o CSV, agora
coerente com o último run.

> **Revisto (D8):** o treino sob demanda grava em
> `ml/artifacts/runs/{training_run_id}/` e as figuras/CSV do run vão para
> `.../report/` dessa pasta; `ml/artifacts/report/` segue refletindo a
> referência versionada, regerada por `python -m ml.report`. Por consequência,
> `GET /models/export?format=csv` passa a servir sempre o CSV **da
> referência**: era a sobrescrita dos artefatos versionados que fazia os dois
> coincidirem, e é exatamente o defeito corrigido (RNF03).

### 5.2 GridSearchCV (D6)

Quando `grid_search=true`, cada modelo é ajustado com `GridSearchCV` sobre o
conjunto de treino, com `StratifiedKFold(n_splits=5, shuffle=True,
random_state=42)` e `scoring="recall"` (sensibilidade — a métrica certa dado o
custo assimétrico do falso negativo). As grades padrão (sobrescrevíveis por
`hyperparameters`):

- `regressao_logistica`: `C ∈ {0.01, 0.1, 1, 10}`, `penalty="l2"`,
  `max_iter=1000`.
- `svm`: `C ∈ {0.1, 1, 10}`, `gamma ∈ {"scale", 0.01, 0.1}`, `kernel="rbf"`,
  `probability=True`.

A padronização entra no pipeline do `GridSearchCV` (`make_pipeline(StandardScaler,
modelo)`) para não vazar escala entre folds — o padrão já usado em `_cv_metrics`.
A semente 42 é registrada no `training_runs` e em `train_config.json`. Quando
`grid_search=false`, usa os hiperparâmetros padrão de `MODELS` (comportamento
atual).

### 5.3 `PUT /api/v1/models/{id}/threshold` — a trava de segurança (RNF04)

Corpo: `{ "threshold": 0.42 }`. A rota:

1. Carrega o `TrainedModel` por `id` (404 `NOT_FOUND` se não existir).
2. Recalcula a **sensibilidade no ponto de operação pedido** usando as predições
   **out-of-fold** do treino daquele modelo (nunca o conjunto de teste — seção 6),
   isto é, a sensibilidade de `(oof_proba >= threshold)` contra `y_true`. Os
   vetores `oof_proba`/`y_true` vêm do `{model}_oof.json` do **diretório do
   próprio registro** (`ml/artifacts/` para os modelos de referência,
   `ml/artifacts/runs/{training_run_id}/` para um treino sob demanda — D8;
   resolvido a partir de `trained_models.artifact_path`)
   (`{"y_true", "proba"}`), que o treino sob demanda grava e que a sincronização
   inicial regenera deterministicamente para os modelos pré-semeados (seções 2.4 e
   6) — por isso a rota funciona inclusive no estado padrão logo após clonar, sem
   re-treinar. Se, por qualquer motivo, o `{model}_oof.json` estiver ausente e não
   for possível regenerá-lo (ex.: `split.json` corrompido), a rota devolve **503
   `MODEL_UNAVAILABLE`** em vez de arriscar uma sensibilidade incorreta — a
   promoção nunca ocorre sem o vetor OOF.
3. Se `sensibilidade >= 0,97`: atualiza `trained_models.threshold`, marca
   `is_production=True` neste modelo e `False` nos demais, e recarrega o bundle em
   memória (`ml/predict.py: clear_cache()`), devolvendo **200** com o modelo
   promovido e a sensibilidade obtida.
4. Se `sensibilidade < 0,97`: devolve **400 `SENSITIVITY_BELOW_TARGET`** com
   `{obtained: 0.95, required: 0.97}` e **não altera nada** (sem commit).

Essa é a materialização do RNF04. A constante `SENSIBILIDADE_MINIMA = 0.97` já
existe em `ml/train.py` e é reusada.

> **Nota de 22/10/2026 (D11) — portão × métricas reportadas.** Os passos 2 e 4
> acima ficam **como estão**: o portão continua sendo a sensibilidade das
> predições out-of-fold do treino, porque validar limiar pelo conjunto de teste
> vazaria informação. O que mudou é o passo 3: o valor do portão passou a ser
> gravado em `trained_models.train_oof_sensitivity` (coluna nova, §2.3) e
> **nunca** em `sensitivity`. Além de `threshold`, a rota agora reescreve, em
> conjunto, todas as métricas reportadas (`accuracy`, `sensitivity`,
> `specificity`, `auc`, `false_negative_rate`, `confusion_matrix`) recalculadas
> no **conjunto de teste** daquela execução no limiar novo, via
> `services.modelos.metricas_teste_no_limiar`, que reusa
> `ml.train.compute_metrics`. O insumo é o artefato novo
> `{model}_test_proba.json` (§6).
>
> Degradação: se esse arquivo estiver ausente e não for possível regenerá-lo, a
> rota devolve **503 `MODEL_UNAVAILABLE` antes de qualquer escrita** — mesmo
> contrato do `{model}_oof.json` no passo 2 — porque uma linha meio atualizada
> (limiar novo com métricas do limiar antigo) era exatamente o defeito corrigido.
>
> Corpo de resposta do 200:
> `{model, threshold, train_oof_sensitivity, test_metrics{accuracy, sensitivity,
> specificity, auc, false_negative_rate, confusion_matrix}}`. A chave
> `sensitivity` de nível superior saiu: era o portão disfarçado de métrica.

### 5.4 Leitura e sincronização

Estado "sem modelos" e fonte autoritativa (correção dos findings 5 e 10 da
revisão). Regra fixada para quando `trained_models` está vazia (banco recém-criado
antes da sincronização, ou um `training-run` que falhou e não gerou modelos) ou
não há artefato em `ml/artifacts/`:

- `GET /api/v1/models` — lista `trained_models`. **Nunca** erra por lista vazia:
  devolve **200** `{"items": []}` quando não há modelo. Fonte: a tabela
  `trained_models` (de `services/modelos.py`).
- `GET /api/v1/models/comparison` — assume o papel do antigo `/metricas`: para cada
  modelo, as métricas nos dois pontos de operação e os `roc_points`. **Fonte
  autoritativa:** a tabela `trained_models` para as métricas escalares já
  persistidas (`accuracy`, `sensitivity`, `specificity`, `auc`,
  `false_negative_rate`, `threshold`, `safety_threshold`, `confusion_matrix`,
  `roc_points`); os JSON do run (`metrics.json`/`train_config.json`) **apenas**
  complementam os detalhes de validação cruzada e reprodutibilidade (semente,
  versões, partições) que não têm coluna própria. Quando não há modelo em produção
  nem artefato legível, devolve **503 `MODEL_UNAVAILABLE`** (mantém o
  comportamento e o código que a rota já tinha via `load_bundle`/`ModeloIndisponivel`).
- `GET /api/v1/models/features?model=&top=` — importância por permutação (US06),
  reusa `feature_importance.json` / `ml/report.py`. `modelo`→`model`. **Regras de
  parâmetro (finding 10):** `top` é inteiro em `[1, 30]` com *clamp*
  (`max(1, min(top, 30))`, comportamento atual); `top` não inteiro → 400
  `VALIDATION_ERROR`; `model` ausente ou desconhecido → 404 `NOT_FOUND`; sem
  artefato de importância → 503 `MODEL_UNAVAILABLE`.
- `GET /api/v1/models/export?format=csv` — reusa `ml/report.py: metricas_csv()`.
  Sem artefato/modelo → **503 `MODEL_UNAVAILABLE`**.
- `sincronizar_modelos()` passa a popular `trained_models` com as novas colunas e a
  criar o `TrainingRun` correspondente (sintético na subida; real no treino sob
  demanda).

> **Nota de 22/10/2026 (D11/D12) — `comparison` dirigido pelo banco.** A fonte
> autoritativa segue sendo `trained_models`, mas o **laço** da rota passou a ser
> dirigido pelo banco, não pelo `metrics.json` da referência: um item por nome de
> modelo, a **linha mais recente** (ordenada por `trained_at desc, id desc`). O
> `{m.name: m for m in TrainedModel.query.all()}` anterior escolhia "o último do
> dict", que é arbitrário — e com D12 a tabela passa a ter várias linhas do mesmo
> nome.
>
> Campos aditivos por item: `test_size` (da execução), `test_set_size` e
> `test_set_malignant` derivados da própria `confusion_matrix` (`vn+fp+fn+vp` e
> `vp+fn`; `null` sem matriz), `train_oof_sensitivity` e
> `gate_meets_sensitivity_target`. No topo: `test_partitions_mixed` e
> `test_partitions`. Motivo: a tela exibia "Conjunto de teste (114 casos, 42
> malignos)", da referência, ao lado de linhas de execuções com outra partição;
> comparar métricas entre partições distintas não é válido e isso tem de ficar
> visível.
>
> `default_point`, `cross_validation` e `safety_threshold_reached_target` passam a
> vir do `metrics.json` **da execução daquele registro** e são `null` quando o
> diretório da execução já não existe — nunca da referência, que é outra
> partição. O bloco `reproducibility` continua descrevendo os artefatos de
> referência de `ml/artifacts/`, agora dito explicitamente na tela.

---

## 6. Limiar de segurança com predições out-of-fold

A regra já está correta em `ml/train.py: escolher_limiar_seguranca()` e é
**mantida**: varre a grade de limiares de 0,01 a 0,50 (passo 0,01), do maior para o
menor, e escolhe o **maior limiar ≤ 0,5** cuja sensibilidade das predições
*out-of-fold* do treino ainda seja ≥ 0,97. Se nenhum atinge, usa o menor limiar da
grade (máxima cautela) e sinaliza `atingiu_meta=False`. As predições out-of-fold
vêm de `cross_val_predict(make_pipeline(StandardScaler, modelo), X_train, y_train,
cv=StratifiedKFold(5), method="predict_proba")`, sem tocar no conjunto de teste.

Esse mesmo vetor out-of-fold é persistido por modelo em
`ml/artifacts/{model}_oof.json` para que `PUT /models/{id}/threshold` (seção 5.3)
recalcule a sensibilidade em qualquer ponto pedido sem re-treinar. **O treino sob
demanda passa a gravar esse arquivo** (`{"y_true": [...], "proba": [...]}`) junto
dos demais artefatos — é a refatoração mínima de `ml/train.py: train_and_evaluate`
que o finding 1 exige, já que hoje o `oof` é calculado em memória
(`cross_val_predict(... method="predict_proba")[:, 1]`) e descartado após escolher
o limiar. Para os modelos pré-semeados que ainda não têm o arquivo, a
sincronização inicial o regenera deterministicamente (seção 2.4). O conjunto de
teste nunca é usado para escolher ou validar limiar — só para reportar as métricas
finais nos dois pontos de operação.

O formato de `{model}_oof.json` fica, assim, **autoritativo** para a sensibilidade
usada na promoção: duas origens o produzem (treino sob demanda e sincronização
inicial), ambas com `StratifiedKFold(5, shuffle=True, random_state=42)` sobre os
índices de treino lidos de `split.json["treino"]` (chave em português, mantida como
está — ver §2.4), garantindo o mesmo vetor. O corpo do arquivo é
`{"y_true": [0,1,...], "proba": [0.02, 0.98, ...]}` (duas listas paralelas na ordem
de `split.json["treino"]`).

> **Nota de 22/10/2026 (D11) — um segundo artefato, ao lado do OOF.** A regra
> acima fica intacta: o conjunto de teste continua nunca escolhendo nem validando
> limiar. O que faltava era reportar as métricas de teste no limiar vigente
> **sempre que ele muda**, e para isso `train_and_evaluate` passou a persistir
> `{model}_test_proba.json` no diretório da execução, com a mesma forma do OOF:
> `{"y_true": [...], "proba": [...]}`, agora na ordem de `split.json["teste"]`.
>
> Mesma estrutura de degradação do OOF: para os modelos pré-semeados que ainda
> não têm o arquivo, `services.modelos.regenerar_test_proba_ausentes` o regenera
> deterministicamente a partir de `split.json["teste"]`, `scaler.joblib` e
> `{model}.joblib` (`modelo.predict_proba(scaler.transform(X[idx_teste]))`), e
> sem qualquer um dos três ele retorna sem gravar — quem depende do arquivo
> devolve 503. A escolha de persistir em vez de recomputar sob demanda segue o
> precedente já fechado aqui para o OOF: evita um segundo padrão de artefato,
> mantém o `PUT /threshold` em leitura de JSON (114–171 floats, sem sklearn nem
> dataset) e sobrevive à divergência de versão do sklearn, que é o que RNF03
> cobra.
>
> Validado: as métricas recalculadas de `{model}_test_proba.json` no
> `limiar_seguranca` batem com `metrics.json: modelos[nome].teste_operacao` em
> 1e-9, para os dois modelos de referência
> (`tests/test_metricas_coerentes.py::test_regeneracao_reproduz_as_metricas_da_referencia`).

---

## 7. Redesign do frontend (React + Vite)

### 7.1 Stack e roteamento

Adiciona-se **`react-router-dom`** ao `package.json` (hoje a navegação é por estado
local em `App.jsx`). Justificativa: a especificação exige "filtros do histórico
refletidos na URL" e quatro telas com rotas próprias (incluindo Login/Cadastro
como rota distinta); roteamento real por URL é a forma correta, e `react-router`
é o padrão do ecossistema React/Vite. É a única dependência de frontend nova.

Rotas:

| Caminho | Tela | Perfil |
|---------|------|--------|
| `/login` | Login / Cadastro | — (público) |
| `/classificar` | Classificar | Médico (menu) |
| `/historico` | Histórico | Médico e Pesquisador |
| `/laboratorio` | Laboratório de Modelos | Pesquisador (menu) |

Um "guarda de UI" (não de autorização — D3) redireciona para `/login` quando não
há sessão (`GET /auth/me` 401) e esconde do menu as telas que não pertencem ao
`profile`. **Não** há bloqueio de rota por perfil no servidor; se o usuário digitar
a URL de outra tela, ela carrega (sem trava), coerente com D3. O estado de sessão
vem de `GET /auth/me` no boot, guardado em um contexto React simples.

### 7.2 Sistema de design clínico sóbrio

Um arquivo de tokens (`styles.css` reescrito, ou um `theme.css` com variáveis CSS)
define a identidade visual, para que a interface pareça produto e não protótipo:

- **Paleta**: fundo neutro claro, superfícies em branco, azul clínico sóbrio para
  ação primária, cinzas para texto. **Benigno** e **maligno** nunca comunicados só
  por cor: cada um tem **cor + texto + ícone** (ex.: maligno = vermelho +
  rótulo "Maligno" + ícone de alerta; benigno = verde-azulado + "Benigno" + ícone
  de check). Os pares de cor passam contraste **WCAG AA** (≥ 4,5:1 em texto).
- **Tipografia e espaçamento**: escala tipográfica e espaçamento por variáveis;
  componentes reutilizáveis (cartão, botão, campo, selo, tabela, alerta).
- **Estados**: carregamento (skeleton/placeholder), vazio e erro tratados em todas
  as telas.
- **Responsivo**: o formulário de 30 campos usa grade fluida; em telas estreitas
  colapsa para uma coluna.

### 7.3 Acessibilidade (WCAG AA) — invariantes

Donos de cada regra (camada de componente):

- **Contraste AA**: tokens de cor (nenhum par abaixo de 4,5:1 em texto, 3:1 em
  elementos gráficos/ícones).
- **Teclado**: toda ação alcançável e operável por teclado; ordem de foco lógica;
  slider de limiar operável por setas.
- **Foco visível**: outline de foco explícito em todos os controles (nunca
  `outline:none` sem substituto).
- **`label` por campo**: cada input tem `label` associado (já feito via
  `<label><span>…</span><input/></label>`).
- **Erro via `aria-describedby`**: mensagem de erro ligada ao campo
  (`aria-invalid` + `aria-describedby` → `id` da mensagem), padrão já presente em
  `ClassificarPage` e estendido a todos os formulários (login, cadastro, filtros).
- **Cor + texto + ícone** para o resultado da classificação e para os selos do
  histórico (nunca só cor).
- **`aria-live`** nas regiões de resultado e nos contadores que atualizam.
- Aviso permanente (RNF01) com `role="note"`.

### 7.4 As quatro telas

**Login / Cadastro** (`/login`) — alterna entre entrar e cadastrar. Cadastro com
`name`, `email`, `password`, e escolha de `profile` (médico/pesquisador) por
radiogroup acessível. Validação no cliente (campos obrigatórios, e-mail, senha ≥ 8)
e exibição dos erros do servidor (e-mail duplicado, credenciais inválidas) ligados
aos campos. Em sucesso, redireciona para a primeira tela do perfil.

**Classificar** (`/classificar`, menu do Médico) — reaproveita a lógica de
`ClassificarPage.jsx` com estes ajustes:
- Chama `GET /api/v1/features/schema` e `POST /api/v1/predictions` (payload em
  inglês: `features`, `mode`, `patient_name`, `patient_record`).
- **Formulário de 30 campos agrupado pelas 10 características base nas 3 variações**:
  em vez de três `fieldset` por variação (mean/se/worst) como hoje, o agrupamento
  passa a ser **pelas 10 medidas base**, cada uma com os três campos (média, erro
  padrão, pior valor) lado a lado — é o que a tarefa pede ("agrupado pelas 10
  características base nas 3 variações"). Mantém `fieldset`/`legend` por grupo para
  acessibilidade.
- **Importação de CSV**: reaproveita `parseCsv()` (aceita cabeçalho com nomes, 30
  valores em sequência, ou o formato original do WDBC com id+diagnóstico).
- **Validação no cliente com margem de 20%** contra `/features/schema`
  (`min_aceito`/`max_aceito`), já implementada em `validarCampo`.
- Resultado com **cor + texto + ícone**, grau de confiança (faixa + percentual),
  modelo e limiar, aviso legal. Em erro de classificação (503/504), **não limpa o
  formulário** (comportamento atual preservado).
- Remove a frase sobre AES-256-GCM (seção 3).

**Histórico** (`/historico`, Médico e Pesquisador) — reaproveita `HistoricoPage.
jsx`, com os **filtros em inglês refletidos na URL** via `react-router`
(`useSearchParams`): `page`, `limit`, `label`, `mode`, `date_from`, `date_to`,
`confidence_min`, `confidence_max`. A tabela mostra os campos em inglês do item
(`label`, `confidence_band`, `probability`, `model_name`, `mode`,
`patient_name`/`patient_record` quando identificado — em texto). Selo de
classificação com cor + texto + ícone. Estados de vazio/erro/carregando.

**Laboratório de Modelos** (`/laboratorio`, menu do Pesquisador) — reaproveita
`ModelosPage.jsx` e adiciona o que faltava:
- **Disparar treino**: formulário que faz `POST /api/v1/training-runs` (seleção de
  modelos, `test_size`, `grid_search`, hiperparâmetros opcionais) e acompanha o
  `status` via `GET /training-runs/{id}`.
- **Tabela comparativa** e **curvas ROC sobrepostas** (reusa `RocChart`, que já
  distingue séries por cor **e** tracejado — bom para daltônicos).
- **Slider de limiar** com a regra dos 0,97: ao soltar, faz `PUT /models/{id}/
  threshold`; em 400 `SENSITIVITY_BELOW_TARGET`, mostra alerta de não conformidade
  com a sensibilidade obtida vs exigida, sem promover.
- **Ranking de características** (importância por permutação) e **exportar CSV**.
- Consome `GET /models/comparison`, `/models/features`, `/models/export`.

### 7.5 Camada `api.js`

Reescrita para o prefixo `/api/v1`, com `credentials: "include"` em todas as
chamadas (para o cookie de sessão viajar), o envelope de erro em inglês
(`{error, code}`) e as funções novas: `register`, `login`, `logout`, `me`,
`predict`, `getPredictions`, `getPrediction`, `getModels`, `getComparison`,
`getFeatures`, `createTrainingRun`, `getTrainingRun`, `putThreshold`, e a URL de
export. `ApiError` passa a ler `code`/`error`.

**Parâmetro `top` de `getFeatures` (correção do finding 6 da revisão).** A
assinatura é `getFeatures(model, top)`: quando o Laboratório oferecer um seletor de
"quantas características exibir" no ranking de permutação, `getFeatures` monta a
query `GET /api/v1/models/features?model=<model>&top=<top>`, passando `top` só
quando houver valor selecionado (omitido quando o usuário não escolhe, deixando o
backend usar o default). Assim o parâmetro `top` do contrato (§5.4 — inteiro em
`[1,30]` com clamp; não inteiro → 400) é de fato exercitável pelo frontend, e não
fica apenas no servidor. O `getImportancia` atual, que nunca enviava `top`, é
substituído por essa `getFeatures(model, top)`.

---

## 8. Testabilidade

Framework: `unittest` (já é o escolhido — seção 9 da especificação:
`python -m unittest discover -s tests`). O diretório `tests/` está vazio; os testes
são criados na implementação.

**Unitário (sem banco, sem Flask):**
- `ml/predict.py`: dado um bundle de teste, `predict()` decide por `P >= limiar`,
  calcula `confidence_band` correta nas três faixas, e nunca usa `predict()`.
- `ml/train.py: escolher_limiar_seguranca()`: casos sintéticos — quando há limiar
  ≤ 0,5 com sensibilidade ≥ 0,97 escolhe o maior; quando não há, cai no menor e
  marca `atingiu_meta=False`.
- `services/validation.py`: 30 campos faltando/não numéricos/fora da faixa com
  margem de 20%; filtros de histórico em inglês (defaults, limites, datas, faixas
  de confiança invertidas).
- `ml/data.py: feature_schema()`: 30 campos, `min_aceito/max_aceito` com 20%,
  `label`/`unit`.

**Integração (app de teste + SQLite em memória, `TESTING=True`):**
- `POST /api/v1/auth/register`→201, duplicidade de e-mail→400, `login`→200/401,
  `me`→200/401, `logout`→204.
- `POST /api/v1/predictions`: 200 com `evaluation_id` e campos em inglês; grava
  `evaluations`; modo identificado grava `patient_name`/`patient_record` em texto;
  **RNF02**: `elapsed_ms` presente e, no caminho feliz, < 2000; com um modelo falso
  lento, 504 `TIMEOUT` e nada gravado; modelo ausente → 503 `MODEL_UNAVAILABLE`.
- `GET /api/v1/predictions`: paginação (`items/page/limit/total`), filtros em
  inglês, ordenação mais-recente-primeiro; imutabilidade (tentativa de update/
  delete via ORM levanta erro).
- `POST /api/v1/training-runs`: cria `training_runs` com `status` final; grava
  `trained_models`; registra semente/hashes/versões/commit (RNF03).
- `PUT /api/v1/models/{id}/threshold`: **RNF04** — abaixo de 0,97 → 400
  `SENSITIVITY_BELOW_TARGET` sem alterar nada; ≥ 0,97 → promove e recarrega o
  bundle.

**Frontend:** sem framework de teste JS no projeto hoje; a tarefa não pede um. A
verificação de frontend é `npm run build` (compila) e checagem manual de
acessibilidade (contraste, teclado, foco) — WCAG completo exige teste manual com
tecnologia assistiva, fora do escopo automatizável. `parseCsv()` é a única função
pura de frontend que merece teste; pode ser coberta com um teste leve se um runner
for adicionado, mas não é obrigatório para esta entrega.

**Verificação de build obrigatória na implementação:** `python -m unittest
discover -s tests -t . -v` (backend) e `npm run build` em `frontend/` (frontend).

---

## 9. Vocabulário e armadilhas que já custaram nota

Para a implementação não reintroduzir erros apontados pelo professor:

- A base WDBC é **tabular**: 30 medidas numéricas extraídas de **punção aspirativa
  por agulha fina (FNA)**. **Nunca** escrever "imagens de biópsia" em comentário,
  texto de UI, README ou docstring.
- Nome correto do dataset: **"Wisconsin Diagnostic Breast Cancer Dataset"** (com
  "Cancer"). Usar essa grafia em qualquer menção.
- **`wandb` não é usado** (D7). Nenhum import, dependência ou menção.
- As características são: raio, textura, perímetro, área, suavidade, compacidade,
  concavidade, pontos côncavos, simetria e dimensão fractal — nas variações média,
  erro padrão e pior valor. Nunca "tamanho do tumor, taxa de mitose, atipia
  nuclear" (não são desta base).
- **RNF01** (aviso permanente em todas as telas) e **RNF04** (taxa de falsos
  negativos reportada + trava de sensibilidade 0,97) são os pontos mais sensíveis:
  o aviso fica no layout raiz (visível em `/login`, `/classificar`, `/historico`,
  `/laboratorio`), e a trava dos 0,97 é a única porta para `is_production`.

---

## 10. Pendências detectadas na especificação consolidada

A tarefa pede apontar aqui o que estiver ambíguo ou incorreto na própria
`.agents/ESPECIFICACAO-CONSOLIDADA.md`, para corrigir no arquivo junto com o
código:

1. **Coluna de confiança numérica ausente no modelo de `evaluations`.** A seção 4
   do spec lista `probability` e `confidence_band`, mas a seção 5 define os filtros
   `confidence_min`/`confidence_max`, que precisam de um valor numérico de
   confiança para filtrar. **Correção a aplicar no spec:** acrescentar a coluna
   `confidence` (Float) à tabela `evaluations` na seção 4, derivada como
   `P(maligno)` se maligno, `1 − P(maligno)` se benigno. Este design já adota essa
   coluna (seção 2.2).

2. **Driver PostgreSQL.** A seção 9 lista `psycopg` (v3), mas o `requirements.txt`
   atual traz `psycopg2-binary` (v2). **Correção a aplicar junto ao código:**
   padronizar em `psycopg` v3 e usar a URL `postgresql+psycopg://...`; ajustar o
   `.env.example`. (Não é erro do spec, e sim divergência código↔spec; registrado
   para não passar batido.)

3. **Rótulo da faixa de confiança "média".** `ml/predict.py` emite
   `faixa_confianca="media"` (sem acento, por ser chave interna), enquanto o texto
   do spec usa "média". Não é incorreção, mas a implementação deve exibir "média"
   na UI mantendo `media` como valor de API — registrado para evitar
   "correções" equivocadas que quebrem o contrato.

Essas três pendências são de documentação/configuração, não bloqueiam o design, e
devem ser corrigidas no `.agents/ESPECIFICACAO-CONSOLIDADA.md` (itens 1 e 3) e no
`requirements.txt`/`.env.example` (item 2) na mesma leva da implementação, conforme
a regra "se uma mudança de código contrariar este arquivo, este arquivo deve ser
atualizado junto".

---

## 11. Respostas à revisão do design (`design-review.json` / `.md`)

### 11.1 Primeira rodada de revisão

Veredito recebido: **CHANGES_REQUESTED** (3 HIGH, 5 MEDIUM, 4 NIT). Cada finding
foi conferido contra o código-fonte real e **endereçado**; nenhum foi backlogado
nem ignorado. As correções são coerentes com a `ESPECIFICACAO-CONSOLIDADA.md`
(RNF04, RNF01, contrato `/api/v1` em inglês, D2–D7).

| # | Sev. | Resolução | Onde no design |
|---|------|-----------|----------------|
| 1 | HIGH | **Endereçado.** A sincronização inicial regenera `{model}_oof.json` deterministicamente (`cross_val_predict` + `StratifiedKFold(5, shuffle, random_state=42)` sobre `split.json`) quando ausente, e o treino sob demanda passa a gravá-lo. `PUT threshold` lê desse arquivo; sem OOF e sem como regenerar, 503. Rejeitada a alternativa de versionar binários OOF, com justificativa. | §2.4, §5.3 (passo 2), §6 |
| 2 | HIGH | **Endereçado.** Nova §4.0: CORS com `supports_credentials=True` e `CORS_ORIGINS` explícito (nunca `*` com credenciais); `SESSION_COOKIE_SAMESITE=Lax`/`SECURE` coerentes com dev; `.env.example` documenta `CORS_ORIGINS`/`SECRET_KEY`. | §4.0, §3 (item 4) |
| 3 | HIGH | **Endereçado.** Os dois retornos de `app.py:frontend()` passam a `{"error","code"}`; 404 de rota de API e "frontend ausente" → `NOT_FOUND`; `ROTA_NAO_ENCONTRADA` e `FRONTEND_AUSENTE` deixam de existir. | §1.1 |
| 4 | MED | **Endereçado.** `pandas` incluído explicitamente na lista de dependências travadas do backend, com nota de que **permanece** (ao contrário de `cryptography`). | Visão geral |
| 5 | MED | **Endereçado.** `GET /models` → 200 com lista possivelmente vazia; `comparison`/`features`/`export` → 503 `MODEL_UNAVAILABLE` sem modelo/artefato; declarada a fonte autoritativa de cada campo de `comparison` (tabela `trained_models`, JSON do run só complementa). | §5.4 |
| 6 | MED | **Endereçado.** Regras de validação de `POST /training-runs` (`models` subconjunto não vazio; `test_size` em `(0,0.5]`; `grid_search` bool; `hyperparameters` opcional, chaves estranhas ignoradas) e falha de treino → 201 com `status:"failed"`+`error_message`. | §5.1 |
| 7 | MED | **Endereçado.** `registrar()` passa a gravar `elapsed_ms=round(tempo_ms)` (inteiro); coluna `Integer`; resposta expõe inteiro, coerente com `"elapsed_ms": 118`. | §1.6, §2.2 |
| 8 | MED | **Endereçado.** Listada a remoção dos dois índices antigos e definido o `__table_args__` completo: três índices da spec + `ix_evaluations_label_confidence (label, confidence)` para o filtro combinado que permanece. | §2.2 |
| 9 | NIT | **Mantida a decisão original, com justificativa.** As chaves internas do `features/schema` (`campos`/`grupo`/`medida`) seguem em português por não serem identificadores de recurso REST nem colunas de banco; `label`/`unit` em inglês são adições de payload. A revisão classifica como inconsistência estética consciente sem correção obrigatória; não renomear evita retrabalho sem ganho de contrato. | §1.3 |
| 10 | NIT | **Endereçado.** `top` inteiro em `[1,30]` com clamp; não inteiro → 400 `VALIDATION_ERROR`; `model` inválido → 404 `NOT_FOUND`. | §5.4 |
| 11 | NIT | **Endereçado.** Exemplo de item do histórico acrescentado, com `confidence` e `confidence_band`. | §1.5 |
| 12 | NIT | **Endereçado como nota de implementação.** Registrado que `confidence_band` é sempre `alta`/`media`/`baixa` (sem acento) em API e filtros; "média" só na UI. | §1.5, §10 (pendência 3) |

Observação sobre a verificação do revisor: todas as "Unverified / Wrong
Assumptions" apontadas (OOF inexistente nos artefatos, CORS incompatível, envelope
do fallback em português, `pandas` omitido, `elapsed_ms` como Float no gravador)
foram confirmadas no código e corrigidas neste documento. Nenhuma suposição
incorreta remanesce no design.

### 11.2 Segunda rodada de revisão

Veredito recebido: **CHANGES_REQUESTED** (2 HIGH, 2 MEDIUM, 4 NIT). Esta rodada
revisou as correções da primeira e apontou imprecisões técnicas no pseudocódigo e
nos nomes de artefatos. Cada finding foi reconferido contra os artefatos reais
(`ml/artifacts/split.json`, `train_config.json`, `metrics.json`, `ml/train.py`,
`ml/report.py`) e **endereçado**; nenhum foi backlogado nem ignorado.

| # | Sev. | Resolução | Onde no design |
|---|------|-----------|----------------|
| 1 | HIGH | **Endereçado.** O pseudocódigo de regeneração do OOF passa a usar `split["treino"]` (não `split["train_idx"]`), e o design fixa que `split.json` mantém as chaves em português `random_state`/`treino`/`teste`, sem renomear (compatível com os modelos pré-semeados versionados). A coluna `training_runs.split` recebe esse JSON como está. | §2.4, §6 |
| 2 | HIGH | **Endereçado.** O `modelo_base` do OOF passa a ser `clone(joblib.load(ml/artifacts/{model}.joblib))` (traz os `get_params()` efetivamente treinados), **não** hiperparâmetros do `metrics.json` — que, confirmado no artefato, **não** contém hiperparâmetros (ficam em `train_config.json["hiperparametros"]` e no `.joblib`). Frase corrigida. | §2.4 |
| 3 | MED | **Endereçado.** Fixada a forma de `trained_models.roc_points`: é **o mesmo objeto** `{"fpr":[...],"tpr":[...]}` de `metrics.json: modelos[nome].roc`, preservado ponta a ponta; `GET /models/comparison` o expõe sob `roc_points` com essa estrutura, mantendo o consumo atual de `RocChart` e `ml/report.py`. Só a chave de topo é renomeada (`roc`→`roc_points`); o objeto interno fica intacto. | §2.3 (nota), §5.4 |
| 4 | MED | **Endereçado.** `POST /training-runs`, ao concluir com `status="success"`, chama `ml/report.gerar_figuras()` + `metricas_csv()` para regerar `ml/artifacts/report/*` em 300 DPI e o CSV a partir do `metrics.json` do run, atendendo §6/RNF03. Falha de figura (ex.: matplotlib indisponível) é `warning` em log e **não** derruba o run — figura é exportação, não condição de sucesso. | §5.1 |
| 5 | NIT | **Sem mudança no design, conforme a revisão.** Nota reforçada ao implementador: `confidence_band` emite `media` sem acento como valor de API; "média" só na UI — não "corrigir" o acento no valor de API. | §1.5, §10 (pendência 3) |
| 6 | NIT | **Endereçado.** §7.5 passa a listar `getFeatures(model, top)` com o parâmetro `top` enviado quando houver seletor de quantidade no Laboratório (omitido caso contrário), tornando o `top` do contrato exercitável pelo frontend; substitui o antigo `getImportancia`, que nunca enviava `top`. | §7.5 |
| 7 | NIT | **Endereçado.** Nota esclarecendo que `library_versions` reusa **exatamente** as quatro chaves já gravadas em `train_config.json["versoes"]` (`python`, `scikit_learn`, `numpy`, `joblib`), sem ampliar o escopo; ampliar seria ajuste pontual em `ml/train.py`, fora deste escopo. | §2.3 (nota) |
| 8 | NIT | **Mantida a decisão original, com justificativa (sem ação obrigatória, conforme a revisão).** Falha **durante** o treino devolve 201 com `status:"failed"`, coerente com a execução síncrona e o `GET /training-runs/{id}`: o recurso `training_runs` de fato foi criado. Reconsiderar o status code fica como opção, não requisito. | §5.1 |
