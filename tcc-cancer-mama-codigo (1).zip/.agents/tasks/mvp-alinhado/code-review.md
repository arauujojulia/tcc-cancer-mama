# Code review — MVP alinhado à especificação consolidada

Branch `feat/mvp-alinhado-documentacao` vs `main`. Critério: fidelidade à
especificação (`ESPECIFICACAO-CONSOLIDADA.md`, `design.md`, `FEAT-00{1,2,3}.json`,
`verificacao.md`). Revisão por leitura do diff e dos arquivos-fonte; as suítes de
teste não foram reexecutadas (conforme instrução).

**Veredito: APPROVED** — nenhum achado HIGH ou MEDIUM. Dois NITs não bloqueantes,
abaixo, registrados apenas para transparência.

---

## Conferência dos pontos sensíveis (todos conformes)

**RNF04 — taxa de falsos negativos e limiar de segurança.**
`ml/train.py:compute_metrics` reporta `taxa_falsos_negativos` explicitamente, e ela
é propagada a `trained_models.false_negative_rate` (`db/models.py`) e à API em
`operating_point`/`default_point` (`api/routes.py:comparar_modelos`, mapa
`_METRICAS_PT_EN`). O limiar de segurança usa predições out-of-fold **do treino**:
`escolher_limiar_seguranca` recebe o vetor de `_oof_proba` (via
`cross_val_predict` sobre `X_train`/`y_train`), e o teste nunca entra nessa escolha
(`ml/train.py`, passos 3 e 4 de `train_and_evaluate`). O
`PUT /api/v1/models/{id}/threshold` (`api/routes.py:ajustar_threshold`) recalcula a
sensibilidade com `services/modelos.py:sensibilidade_oof` (lê `{model}_oof.json`,
leitura pura) e, quando `< 0,97`, devolve **400 `SENSITIVITY_BELOW_TARGET`** com
`obtained`/`required` **antes** de qualquer mutação — `promover_modelo` só é chamado
no ramo `>=`. Confirmado em `ml/artifacts/metrics.json`: melhor modelo
(regressao_logistica) sensibilidade 0,9762 ≥ 0,97, FN 0,0238.

**RNF01 — aviso permanente nas 4 telas.** `frontend/src/App.jsx` renderiza a
`disclaimer-bar` (`role="note"`) no `app-shell`, acima do `<Routes>`, logo visível
em `/login`, `/classificar`, `/historico` e `/laboratorio`.

**D2 / D3 — criptografia, JWT, RBAC, auditoria removidos.** `services/crypto.py`
não existe mais no repositório. `git grep` por
`crypto|AESGCM|AES-256|PACIENTE_ENCRYPTION_KEY|ENCRYPTION_UNAVAILABLE|cryptography`
em código ativo não retorna nada (as únicas ocorrências de "JWT" são negações do
tipo "sem JWT" em `README.md`/`services/auth.py`). `requirements.txt` não traz
`cryptography` e usa `psycopg` (v3); `.env.example` não traz
`PACIENTE_ENCRYPTION_KEY`. Autenticação é só sessão de cookie
(`services/auth.py`), sem trava por perfil (`api/routes.py` não bloqueia rota;
`App.jsx` usa menu por perfil como guarda de UI). Nenhuma tabela de auditoria em
`db/models.py`.

**Contrato — rotas, payloads, campos, códigos de erro.** `api/routes.py` expõe o
blueprint sob `/api/v1`, envelope `{"error","code"}`, com as rotas e os códigos da
seção 5 do spec (`VALIDATION_ERROR`, `UNAUTHENTICATED`, `NOT_FOUND`,
`MODEL_UNAVAILABLE`, `TIMEOUT`, `SENSITIVITY_BELOW_TARGET`, `INTERNAL_ERROR`). A
classe é decidida por `P(maligno) >= limiar` em `ml/predict.py:predict`; o
`.predict()` do estimador nunca é usado para classe (confirmado por `git grep`: as
únicas ocorrências de `.predict(` são o guard do `tests/test_predict.py`).

**Histórico — imutável, paginação e filtros.** Listeners `before_update`/
`before_delete` em `db/models.py:Evaluation` barram alteração/remoção.
`services/avaliacoes.py:listar` monta `{items,page,limit,total}`, ordena por
`created_at desc, id desc` e aplica cada filtro (label, mode, date_from,
date_to_exclusive, confidence_min/max) sobre a coluna `confidence`.
`frontend/src/pages/HistoricoPage.jsx` reflete os filtros na URL via
`useSearchParams`.

**Vocabulário.** Nenhuma descrição da base como "imagens de biópsia" — a única
menção em `README.md:7` é a negação explícita ("uma base tabular... não de imagens
de biópsia"). Dataset citado como "Wisconsin Diagnostic Breast Cancer Dataset".
Nenhuma menção a `wandb` em código, config ou `.gitignore`.

**Acessibilidade.** `frontend/src/components/ui.jsx:ResultBadge` comunica
benigno/maligno por cor + texto + ícone (`AlertTriangleIcon`/`CheckCircleIcon`).
Campos têm `label` e, em erro, `aria-invalid` + `aria-describedby` apontando para o
`id` da mensagem (`ClassificarPage.jsx`; slider de limiar com `aria-describedby` em
`ModelosPage.jsx`).

**Coerência com `verificacao.md`.** Nenhuma afirmação de `verificacao.md` é
contradita pelo código: `{model}_oof.json` versionados e gravados/regenerados
(`ml/train.py`, `services/modelos.py:regenerar_oof_ausentes`); `elapsed_ms` inteiro
(`avaliacoes.py:registrar`); envelope e códigos de erro; `confidence_band` emite
`media` sem acento na API (`ml/predict.py:faixa_confianca`) e a UI exibe "média"
(`format.js:rotuloFaixaConfianca`).

---

## Achados

### NIT-1 — `npm audit`: vulnerabilidades em dependências transitivas de dev
`frontend/package-lock.json` (via `vite`/`esbuild` e `react-router-dom`). Não
afeta o build de produção nem a aplicação servida pelo Flask (o aviso do `esbuild`
é do dev-server; o de SSR do react-router não se aplica a esta SPA). Já registrado
e justificado em `verificacao.md` §5. **Não bloqueia.** Correção, se desejada, só
via upgrade breaking da stack travada no design §7.1 — fora do escopo sem pedido
explícito.

### NIT-2 — `.pyc` versionados em `ml/__pycache__/`
Herdados de um autor anterior e deliberadamente deixados fora dos commits desta
entrega (registrado em `FEAT-002`/`FEAT-003` findings). Não afetam a avaliação de
fidelidade. Sugestão opcional: adicionar `__pycache__/` ao `.gitignore` e remover
os `.pyc` do índice. **Não bloqueia.**
