# Plano de implementação — Alinhamento do MVP à especificação consolidada

Fontes da verdade: `.agents/ESPECIFICACAO-CONSOLIDADA.md` (contrato do produto) e
`.agents/tasks/mvp-alinhado/design.md` (design técnico já revisado em 3 rodadas,
§11). Este plano apenas sequencia o design; não reabre decisões D1–D7.

Convenções: interface, comentários, commits e documentação em **português do
Brasil**; identificadores de API, rotas e colunas de banco em **inglês**. Base WDBC
é **tabular** (30 medidas de FNA), nunca "imagens". `wandb` nunca é usado (D7).

Pré-requisitos de ambiente (uma vez): `pip install -r requirements.txt` após o
item 1 (que troca `cryptography`→nada e `psycopg2-binary`→`psycopg`), e
`npm install` em `frontend/` após o item 11 (que adiciona `react-router-dom`).
Verificação de backend: `python -m unittest discover -s tests -t . -v`.
Verificação de frontend: `npm run build` em `frontend/`.

Como não há dados de produção, o schema novo é recriado do zero (`db.create_all()`
em banco limpo; apagar `tcc_cancer_mama.db` local). Sem migração de linhas.

---

## Parte A — Modelo de dados e remoção da criptografia

- [ ] 1. Reescrever `db/models.py` para o modelo em inglês do design (§2.2–2.3).
      Remover `Medico`, `Pesquisador`, `ModeloTreinado`, `Avaliacao`. Criar `User`
      (`users`), `Evaluation` (`evaluations`, com coluna `confidence` Float — §2.2 e
      pendência 1 da §10), `TrainedModel` (`trained_models`) e `TrainingRun`
      (`training_runs`). Manter os listeners `before_update`/`before_delete` em
      `Evaluation` (imutabilidade). Declarar o `__table_args__` completo de
      `Evaluation` com os 4 índices da §2.2 (`ix_evaluations_created_at`,
      `ix_evaluations_label_created`, `ix_evaluations_mode_created`,
      `ix_evaluations_label_confidence`). Tipos portáveis PostgreSQL↔SQLite (§2.1):
      `db.JSON`, `db.DateTime(timezone=True)`, sem `server_default` de dialeto.
      Files: `db/models.py`
      Verify: `python -c "import db.models"` sem erro (após `pip install`); o item 10
      roda os testes de integração que exercem o schema.

- [ ] 2. Remover a criptografia AES-256-GCM por completo (§3, D2).
      Excluir `services/crypto.py`. Remover `cryptography` de `requirements.txt` e
      confirmar que nenhum outro módulo a importa. Trocar `psycopg2-binary` por
      `psycopg` (v3) em `requirements.txt` (pendência 2 da §10). Remover
      `PACIENTE_ENCRYPTION_KEY` do `.env.example` e do docstring de `app.py`;
      documentar no `.env.example` as duas formas de `DATABASE_URL`
      (`postgresql+psycopg://...`), `CORS_ORIGINS` (lista explícita, default
      `http://localhost:5173`), `SECRET_KEY` e `SESSION_COOKIE_SECURE` opcional.
      Files: `services/crypto.py` (excluir), `requirements.txt`, `.env.example`,
      `app.py` (docstring)
      Verify: busca por `cryptography` e `PACIENTE_ENCRYPTION_KEY` no repo não
      retorna nenhuma referência de código ativa; `pip install -r requirements.txt`
      conclui.

## Parte B — Serviços e contrato da API `/api/v1`

- [ ] 3. Adaptar `services/validation.py` ao vocabulário em inglês (§1.4, §1.5).
      `validar_caracteristicas()` fica idêntica (opera sobre dict de 30 chaves).
      `validar_paciente(mode, patient_name, patient_record)` recebe campos planos.
      `validar_filtros_historico()` passa a `page/limit/label/mode/date_from/
      date_to/confidence_min/confidence_max`; `label` em `{benigno,maligno}`, `mode`
      em `{anonimo,identificado}`. Código de erro padrão de `ErroValidacao` passa a
      `VALIDATION_ERROR`.
      Files: `services/validation.py`
      Verify: coberto pelos testes unitários do item 10.

- [ ] 4. Adaptar `services/avaliacoes.py` (§1.6, §2.2).
      Remover `from services import crypto` e `paciente_decifrado()`; remover
      `medico_existe()`. `registrar()` grava `patient_name`/`patient_record` em
      texto, `user_id` (da sessão), `confidence`, `elapsed_ms=round(tempo_ms)`
      (inteiro). `listar()`/`obter()` leem paciente direto e montam o envelope
      `{items, page, limit, total}`. Ordenação `created_at desc, id desc`.
      Files: `services/avaliacoes.py`
      Verify: coberto pelos testes de integração do item 10.

- [ ] 5. Criar `services/auth.py` e migrar `services/modelos.py` (§4, §5.4).
      `services/auth.py`: `register`, `authenticate`, `current_user` usando
      `werkzeug.security.generate_password_hash`/`check_password_hash` (pbkdf2),
      unicidade de e-mail com captura de `IntegrityError`→`VALIDATION_ERROR`.
      `services/modelos.py`: `sincronizar_modelos()` popula `trained_models` com as
      novas colunas (§2.3) e cria o `TrainingRun` sintético `status="success"`
      (origem coluna a coluna da tabela da §2.4) ligando `training_run_id`; regenera
      `{model}_oof.json` determinístico quando ausente (§2.4, §6);
      `modelo_registrado_mais_recente()` consulta `trained_models`.
      Files: `services/auth.py` (novo), `services/modelos.py`
      Verify: coberto pelos testes do item 10 (register/login e sincronização).

- [ ] 6. Migrar `api/routes.py` para o blueprint `/api/v1` com erros em inglês
      (§1.1–1.6). Mudar `url_prefix` para `/api/v1`; `_erro` emite `{error, code}`;
      mapear os códigos da tabela da §1.1; remover o handler de
      `crypto.CryptoConfigError` e `ENCRYPTION_UNAVAILABLE`. Migrar rota a rota
      conforme §1.2: `features/schema`, `POST /predictions`, `GET /predictions` e
      `/{id}`, `models`, `models/comparison`, `models/features`, `models/export`.
      `POST /predictions`: payload `features/mode/patient_name/patient_record`, lê
      `user_id` da sessão, estouro de 2 s → **504 `TIMEOUT`** sem gravar, modelo
      ausente → 503.
      Files: `api/routes.py`
      Verify: coberto pelos testes de integração do item 10.

- [ ] 7. Adicionar as rotas de autenticação sob `/api/v1` (§4.2).
      `POST /auth/register` (201 `{user}` + sessão), `POST /auth/login` (200/401
      genérico), `POST /auth/logout` (204), `GET /auth/me` (200/401). Sem trava de
      autorização por perfil (§4.3). Usar `flask.session`.
      Files: `api/routes.py` (ou blueprint auxiliar registrado sob `/api/v1`)
      Verify: coberto pelos testes de auth do item 10.

- [ ] 8. Ajustar `app.py`: schema novo, CORS com credenciais e cookie de sessão
      (§2.4, §4.0). `db.create_all()` cria as 4 tabelas novas. `CORS(...,
      supports_credentials=True)` com `CORS_ORIGINS` como lista explícita (nunca
      `*`). `SECRET_KEY` da env com fallback de dev + aviso em log.
      `SESSION_COOKIE_SAMESITE="Lax"`, `SESSION_COOKIE_SECURE` da env. Corrigir os
      dois retornos de `frontend()` para `{error, code}` com `NOT_FOUND` (§1.1).
      Files: `app.py`
      Verify: `python -c "from app import create_app; create_app({'TESTING': True})"`
      sobe sem erro (após `pip install`); testes do item 10.

## Parte C — ML sob demanda e promoção

- [ ] 9. Refatorar `ml/train.py` e expor treino sob demanda + promoção (§5, §6).
      `train_and_evaluate()` passa a aceitar `models`, `test_size`, `grid_search`,
      `hyperparameters` e a **retornar** métricas + caminhos; grava
      `{model}_oof.json` (`{"y_true", "proba"}`). GridSearchCV
      `StratifiedKFold(5, shuffle, random_state=42)`, `scoring="recall"`, grades
      padrão da §5.2. Rotas novas em `api/routes.py`: `POST /training-runs`
      (validação do corpo da §5.1, execução síncrona, grava `training_runs` e
      `trained_models`, chama `ml/report.gerar_figuras()` ao final sem derrubar o
      run se a figura falhar), `GET /training-runs/{id}`, `PUT /models/{id}/threshold`
      (recalcula sensibilidade OOF; `>=0,97` promove e `clear_cache()`; `<0,97` →
      **400 `SENSITIVITY_BELOW_TARGET`** com `{obtained, required}` sem alterar nada).
      `ml/predict.py` permanece intacto (não usar `predict()`; `P>=limiar`).
      Files: `ml/train.py`, `api/routes.py`, `services/modelos.py` (helpers de
      treino/promoção)
      Verify: coberto pelos testes de `escolher_limiar_seguranca`, `POST
      /training-runs` e `PUT threshold` do item 10.

## Parte D — Testes do backend

- [ ] 10. Criar a suíte `unittest` do backend (§8).
      Unitários (sem Flask/banco): `ml/predict.predict()` nas três faixas e
      `P>=limiar`; `escolher_limiar_seguranca()` casos sintéticos;
      `services/validation` (30 campos, filtros em inglês); `ml/data.feature_schema`
      (30 campos, margem 20%, `label`/`unit`/`exemplo`). Integração (app de teste +
      SQLite, `TESTING=True`): auth (register 201/dup 400, login 200/401, me,
      logout 204); `POST /predictions` (200, grava `evaluations`, identificado em
      texto, RNF02 `elapsed_ms<2000`, modelo falso lento→504 nada gravado, ausente→
      503); `GET /predictions` (paginação `items/page/limit/total`, filtros,
      imutabilidade); `POST /training-runs` (status final, grava `trained_models`,
      RNF03); `PUT threshold` (RNF04: `<0,97`→400 sem alterar; `>=0,97` promove).
      Files: `tests/test_*.py` (novos), `tests/__init__.py`
      Verify: `python -m unittest discover -s tests -t . -v` — todos os testes
      passam.

## Parte E — Frontend React de qualidade de defesa

- [ ] 11. Adicionar `react-router-dom` e reescrever o shell com rotas e o aviso
      permanente (§7.1, RNF01). `package.json` ganha `react-router-dom`. `App.jsx`/
      `main.jsx` passam a usar `BrowserRouter` com as rotas `/login`, `/classificar`,
      `/historico`, `/laboratorio`. Layout raiz com o aviso RNF01 (`role="note"`)
      visível em **todas** as telas e menu renderizado por `profile` (guarda de UI,
      sem trava — D3). Contexto de sessão alimentado por `GET /auth/me` no boot.
      Files: `frontend/package.json`, `frontend/src/App.jsx`,
      `frontend/src/main.jsx`
      Verify: `npm install` e `npm run build` em `frontend/` compilam sem erro.

- [ ] 12. Reescrever `frontend/src/api.js` para `/api/v1` com `credentials:
      "include"` (§7.5). Envelope de erro `{error, code}` em `ApiError`; funções
      `register/login/logout/me/predict/getPredictions/getPrediction/getModels/
      getComparison/getFeatures(model, top)/createTrainingRun/getTrainingRun/
      putThreshold` e a URL de export.
      Files: `frontend/src/api.js`
      Verify: `npm run build` compila; as telas (itens 13–16) consomem estas funções.

- [ ] 13. Sistema de design clínico sóbrio e acessível (§7.2, §7.3).
      Reescrever `frontend/src/styles.css` com tokens (paleta, tipografia,
      espaçamento), componentes reutilizáveis (cartão, botão, campo, selo, tabela,
      alerta), foco visível, contraste WCAG AA. Padronizar o selo benigno/maligno
      como **cor + texto + ícone** (nunca só cor) em `format.js`/`charts.jsx`.
      Files: `frontend/src/styles.css`, `frontend/src/components/format.js`,
      `frontend/src/components/charts.jsx`
      Verify: `npm run build` compila; checagem manual de contraste/teclado/foco
      (WCAG completo exige teste manual com tecnologia assistiva — fora do
      automatizável).

- [ ] 14. Tela Login/Cadastro (`/login`, §7.4). Alterna entrar/cadastrar; cadastro
      com `name/email/password/profile` (radiogroup acessível); validação no cliente
      e exibição de erros do servidor ligados aos campos via `aria-describedby`.
      Files: `frontend/src/pages/LoginPage.jsx` (novo)
      Verify: `npm run build` compila.

- [ ] 15. Tela Classificar (`/classificar`, §7.4, §3). Payload em inglês;
      formulário de 30 campos **agrupado pelas 10 medidas base × 3 variações**;
      importação CSV; validação com margem de 20% contra `/features/schema`;
      resultado com cor+texto+ícone, faixa de confiança (exibir "média"), aviso
      legal; erro de classificação **não limpa** o formulário; remover a frase sobre
      AES-256-GCM.
      Files: `frontend/src/pages/ClassificarPage.jsx`
      Verify: `npm run build` compila.

- [ ] 16. Telas Histórico e Laboratório (`/historico`, `/laboratorio`, §7.4).
      Histórico: filtros em inglês refletidos na URL (`useSearchParams`), tabela com
      selo cor+texto+ícone, estados vazio/erro/carregando. Laboratório: disparar
      treino (`POST /training-runs` + acompanhar `GET /training-runs/{id}`), tabela
      comparativa, curvas ROC sobrepostas (`RocChart`), slider de limiar com a regra
      dos 0,97 (`PUT threshold`; 400 mostra sensibilidade obtida vs exigida), ranking
      por permutação, exportar CSV.
      Files: `frontend/src/pages/HistoricoPage.jsx`,
      `frontend/src/pages/ModelosPage.jsx`
      Verify: `npm run build` compila.

## Parte F — Documentação e fecho

- [ ] 17. Atualizar `README.md` e corrigir a especificação (§9, §10).
      README: aviso de segurança (sem controle de acesso por perfil, dados
      identificados em texto — não expor fora de ambiente controlado), recriação do
      banco, comandos de build/test, nome correto "Wisconsin Diagnostic Breast
      Cancer Dataset" (tabular/FNA, nunca "imagens"). Aplicar na
      `ESPECIFICACAO-CONSOLIDADA.md` as pendências 1 e 3 da §10 (coluna `confidence`;
      nota do rótulo "média"). Varrer o repositório para garantir que nenhum texto
      menciona criptografia, JWT, RBAC, auditoria, `wandb` ou "imagens".
      Files: `README.md`, `.agents/ESPECIFICACAO-CONSOLIDADA.md`
      Verify: `python -m unittest discover -s tests -t . -v` e `npm run build`
      continuam verdes; busca por `AES|JWT|RBAC|wandb|imagens de biópsia` não
      retorna menção ativa.

---

## Requisitos × onde são atendidos (nenhum dispensado)

- RF01 (30 características validadas): itens 3, 15. RF02 (benigno/maligno): 6, 15.
  RF03 (grau de confiança): 6, 15. RF04/RF05 (treina e compara, métricas): 9, 16.
  RF06 (importância por permutação): 9, 16. RF07 (histórico sem exigir
  identificação): 4, 6 (`user_id` nullable).
- RNF01 (aviso permanente em todas as telas): item 11 (layout raiz).
  RNF02 (<2 s, `elapsed_ms`, teste): 4, 6, 10. RNF03 (reprodutibilidade): 5, 9, 10.
  RNF04 (taxa de falsos negativos + trava 0,97): 9, 10, 16. RNF05 (alterado por D2
  — modo identificado sem criptografia): 2, 4, 17 (doc).
- D1 (`/api/v1`): 6. D2 (remover criptografia): 2. D3/D4 (auth simples, sem trava,
  hash pbkdf2): 5, 7, 11. D5 (PostgreSQL/SQLite): 1, 2, 8. D6 (GridSearchCV 5-fold
  recall): 9. D7 (sem `wandb`): garantido em todo o escopo; verificado no item 17.
- Mudanças do WhatsApp: remover AES (2), sem segregação travada de perfil (7, 11),
  banco PostgreSQL (1,2,8), paginação com filtros (3,4,16), promoção condicionada a
  sensibilidade ≥ 0,97 (9,16).
