# Revisão de design — MVP alinhado (`design.md`)

Fonte da verdade: `.agents/ESPECIFICACAO-CONSOLIDADA.md`.
Documento revisado: `.agents/tasks/mvp-alinhado/design.md`.

Esta revisão foi feita sem o contexto que produziu o design: o documento foi
lido isoladamente e cada afirmação sobre o código-fonte foi conferida lendo os
arquivos reais do repositório. O objetivo é bloquear qualquer ambiguidade,
lacuna ou suposição não verificada que impediria uma implementação fiel.

---

## Verificações realizadas no código-fonte

Arquivos lidos e conferidos contra as afirmações do design:

- `ml/train.py` — funções, constantes, chaves de artefatos.
- `ml/predict.py` — contrato de `predict()`, faixas de confiança, `clear_cache`.
- `ml/report.py` — `gerar_figuras()`, `metricas_csv()`, `DPI = 300`.
- `ml/data.py` — `feature_schema()` e suas chaves.
- `ml/artifacts/split.json` — chaves reais.
- `ml/artifacts/metrics.json` — estrutura, forma de `roc`, ausência de hiperparâmetros.
- `services/avaliacoes.py`, `services/validation.py`, `services/modelos.py`.
- `api/routes.py` — rotas, envelope de erro, handlers.
- `app.py` — CORS, fallback `frontend()`, `create_all`.
- `db/models.py` — tabelas, índices, listeners de imutabilidade.
- `requirements.txt`.
- `frontend/src/api.js`, `frontend/src/pages/ClassificarPage.jsx`.

---

## Achados

### 1. HIGH — Falta a especificação da sincronização do `TrainingRun` sintético: campos obrigatórios sem valor de origem

Em §2.4 o design cria "um `TrainingRun` sintético de `status="success"`" para os
modelos pré-semeados importados na subida. Porém a classe `TrainingRun` (§2.3)
declara vários campos **não triviais** e o design não especifica de onde vêm os
valores na sincronização inicial:

- `test_size` → existe em `train_config.json` (`test_size`). OK.
- `random_seed` → `train_config.json` (`random_state`). OK.
- `grid_search` (Boolean) → **indefinido**: os artefatos versionados foram gerados
  pelo `train.py` atual, que **não** usa GridSearchCV. O design não diz se o
  `TrainingRun` sintético grava `grid_search=false`.
- `models_requested` → **indefinido** (presumivelmente as chaves de `metrics.modelos`,
  mas não está dito).
- `started_at`/`finished_at` → **indefinido** para o run sintético.
- `dataset_sha256` → `train_config.json["hashes_sha256"]["dataset"]`. OK, mas não citado.

Como `training_run_id` é FK obrigatória em `trained_models` (§2.3), a
sincronização **não pode** popular `trained_models` sem antes materializar
corretamente o `TrainingRun`. A ausência de regra concreta para cada coluna é uma
lacuna que trava a implementação fiel.

**Correção concreta:** adicionar em §2.4 a tabela de origem do `TrainingRun`
sintético, por ex.:

```
status           = "success"
models_requested = list(metrics["modelos"].keys())
test_size        = train_config["test_size"]
random_seed      = train_config["random_state"]
grid_search      = False            # artefatos versionados não usaram GridSearchCV
dataset_sha256   = train_config["hashes_sha256"]["dataset"]
split            = conteúdo de split.json
library_versions = train_config["versoes"]
git_commit       = train_config["commit_git"]
started_at = finished_at = metrics["gerado_em"]
error_message    = None
```

---

### 2. MEDIUM — `GET /api/v1/features/schema` não entrega o campo `exemplo` por característica exigido pelo spec

O spec §5 define, textualmente, para `/features/schema`:
"30 características: nome, rótulo em português, unidade, `min`, `max`, **exemplo**."
Ou seja, **um exemplo por característica**.

O design §1.3 descreve o schema atual (`feature_schema()` em `ml/data.py`,
verificado) que retorna `exemplos` **no nível superior** (um objeto
`{maligno: {...}, benigno: {...}}`), e manda **acrescentar `label` e `unit` por
campo** — mas **não** menciona um campo `exemplo` por característica. Fica
ambíguo se o requisito do spec é atendido pelo `exemplos` global ou se falta um
valor por campo.

**Correção concreta:** decidir e registrar em §1.3 uma das duas opções:
(a) acrescentar `exemplo` a cada campo (ex.: o valor do exemplo maligno daquela
característica), satisfazendo literalmente o spec; ou
(b) declarar explicitamente que o requisito "exemplo" do spec §5 é atendido pelo
objeto `exemplos` de nível superior (maligno/benigno), e que o frontend extrai o
exemplo por campo a partir dele. Sem essa decisão a implementação pode divergir
do contrato.

---

### 3. MEDIUM — Regra `min`/`max` do `/features/schema`: qual par vai para o contrato?

O spec §5 pede, por campo, `min` e `max`. O schema real expõe **dois pares**:
`min_observado`/`max_observado` (faixa WDBC) e `min_aceito`/`max_aceito`
(observado ± 20%). O design §1.3 diz "manter `min_aceito`/`max_aceito`" para a
validação, mas **não** define quais valores são expostos como os `min`/`max`
nominais do contrato do spec, nem renomeia nada. A validação-cliente de 20% usa
`min_aceito`/`max_aceito` (verificado em `ClassificarPage.jsx: validarCampo`),
mas a exibição de "faixa esperada" ao usuário pode querer `min_observado`.

**Correção concreta:** registrar em §1.3 que o contrato do spec mapeia
`min → min_observado` e `max → max_observado` (a faixa real da base), enquanto
`min_aceito`/`max_aceito` permanecem como campos adicionais usados pela validação
com tolerância de 20%. Assim ambos os papéis (exibir a faixa, validar com folga)
ficam inequívocos.

---

### 4. NIT — Payload de `/features/schema`: `grupo`/`medida` em português vs. `label` em inglês

Decisão consciente registrada em §1.3/§11 (finding 9 da rodada anterior): manter
`campos`/`grupo`/`medida` como chaves internas em português e adicionar
`label`/`unit`. É inconsistência estética assumida, sem impacto de contrato (não
são recursos REST nem colunas). Sem ação obrigatória; registrado para o
implementador não "corrigir" por conta própria.

---

### 5. NIT — Valor de API `confidence_band` sem acento (`media`) vs. UI "média"

Confirmado em `ml/predict.py: faixa_confianca()` → emite `media` (sem acento) e em
`ClassificarPage.jsx` a UI exibe "média". O design cobre isso em §1.5 e §10
(pendência 3). Sem ação obrigatória; registrado para não haver "correção" que
quebre o contrato.

---

## Suposições verificadas (confirmadas corretas no código)

1. **`split.json` usa `random_state`/`treino`/`teste`** (não `train_idx`/`test_idx`).
   Confirmado em `ml/train.py` (gravação) e `ml/artifacts/split.json` (conteúdo).
   O design §2.4/§6 está correto ao manter essas chaves em português.
2. **`metrics.json` NÃO contém hiperparâmetros**; eles estão em
   `train_config.json["hiperparametros"]` e nos `.joblib`. Confirmado. A correção
   do design (clonar o estimador do `.joblib` para o OOF) é fundada.
3. **Forma de `roc`** em `metrics.json`/`train.py: _roc_pontos` é
   `{"fpr":[...], "tpr":[...]}` (listas paralelas), não lista de pares. Confirmado.
   `ml/report.py: gerar_figuras()` consome `r["roc"]["fpr"]`/`["tpr"]`. O design
   §2.3 (nota roc_points) está correto.
4. **`{model}_oof.json` NÃO existe hoje** em `ml/artifacts/`; o OOF é calculado em
   memória em `train.py` e descartado. Confirmado (apenas `metrics.json`,
   `feature_importance.json`, `split.json`, `train_config.json`, `scaler.joblib`,
   `{model}.joblib`). A necessidade de regenerá-lo (§2.4/§6) é real.
5. **CORS com `*` e sem `supports_credentials`** em `app.py`. Confirmado — é
   incompatível com cookie de sessão cross-origin. A correção §4.0 é necessária e
   correta.
6. **`app.py: frontend()`** retorna envelopes em português com códigos
   `ROTA_NAO_ENCONTRADA`/`FRONTEND_AUSENTE` fora da tabela do spec. Confirmado. A
   correção §1.1 é necessária.
7. **`cryptography` em `requirements.txt`** e `services/crypto.py` como único
   consumidor (`avaliacoes.py`, `api/routes.py` importam crypto). Confirmado. A
   remoção §3 é consistente.
8. **`psycopg2-binary`** em `requirements.txt` (não `psycopg` v3). Confirmado;
   divergência código↔spec corretamente registrada em §10.
9. **`elapsed_ms` hoje é Float**: `avaliacoes.py` grava `tempo_resposta_ms=round(
   tempo_ms, 2)` em coluna `db.Float` (`db/models.py`). Confirmado. A migração para
   `Integer` + `round(tempo_ms)` (§1.6/§2.2) é correta.
10. **Índices atuais de `Avaliacao`**: `ix_avaliacoes_criado_classe` e
    `ix_avaliacoes_classe_confianca`. Confirmado em `db/models.py`. A substituição
    §2.2 é correta.
11. **Listeners de imutabilidade** `before_update`/`before_delete` existem em
    `db/models.py`. Confirmado; §2.2 corretamente os mantém.
12. **`DPI = 300`** em `ml/report.py`. Confirmado; §5.1 é correto.
13. **`SENSIBILIDADE_MINIMA = 0.97`** e `escolher_limiar_seguranca()` (maior
    limiar ≤ 0,5 com sensibilidade OOF ≥ 0,97, fallback no menor limiar com
    `atingiu_meta=False`) em `ml/train.py`. Confirmado; §5.3/§6 corretos.
14. **`predict()`** decide por `P(maligno) >= limiar_seguranca`, aplica
    `StandardScaler`, faixas `alta`/`media`/`baixa`, nunca usa `.predict()`.
    Confirmado em `ml/predict.py`; mapeamento de resposta §1.4 correto.
15. **Frase AES-256-GCM/LGPD** presente em `ClassificarPage.jsx`
    ("armazenados cifrados (AES-256-GCM), conforme a LGPD"). Confirmado; a remoção
    §3 item 7 / §7.4 tem alvo real.
16. **`parseCsv()`** aceita cabeçalho com nomes, 30 valores em sequência e o
    formato WDBC com id+diagnóstico. Confirmado em `ClassificarPage.jsx`; §7.4
    correto.
17. **Agrupamento atual do formulário** é por `ORDEM_GRUPOS = [mean, se, worst]`
    (três fieldsets por variação). Confirmado; a mudança §7.4 (reagrupar pelas 10
    medidas base) tem base real.
18. **`feature_schema()`** retorna `campos` com `nome/grupo/medida/min_observado/
    max_observado/min_aceito/max_aceito` e `exemplos` top-level. Confirmado; base
    para os achados 2 e 3.
19. **GridSearchCV não está no código atual** (`train.py` usa `MODELS` fixo). A
    introdução sob demanda (§5.2) é adição coerente com D6.
20. **`wandb` não aparece** em nenhum arquivo lido (requirements, código ML,
    frontend). Consistente com D7/§9.
21. **Base descrita como tabular** e dataset "Wisconsin Diagnostic Breast Cancer
    Dataset" — §9 do design reforça corretamente; `ml/data.py` trata CSV tabular
    (FNA), sem imagens.

---

## Suposições incorretas / não verificadas

Nenhuma afirmação do design sobre o código-fonte foi encontrada incorreta. Todas
as alegações conferidas (chaves de artefatos, ausência de OOF e de
hiperparâmetros em `metrics.json`, forma de `roc`, CORS, fallback do `app.py`,
`elapsed_ms` como Float, índices atuais, dependências, frase AES na UI, estrutura
de `parseCsv` e do formulário) foram confirmadas verdadeiras.

A única lacuna de verificação diz respeito ao próprio escopo do design, não a uma
afirmação falsa: o design **não especifica** a materialização completa do
`TrainingRun` sintético (achado 1) nem resolve literalmente o campo `exemplo` e o
par `min`/`max` do contrato de `/features/schema` (achados 2 e 3).

---

## Veredito

Contagem: **1 HIGH, 2 MEDIUM, 2 NIT**.

Como há achados HIGH e MEDIUM (> 0), o veredito é **CHANGES_REQUESTED**.
