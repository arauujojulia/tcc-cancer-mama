# Verificação ponta a ponta — MVP alinhado à especificação consolidada

Executada em 2026-10-14, branch `feat/mvp-alinhado-documentacao` (HEAD `c8a9867`),
primeira iteração do loop de convergência. FEAT-001, FEAT-002 e FEAT-003 já
constavam como `completed`/`done` nos respectivos `.agents/tasks/mvp-alinhado/
features/FEAT-00{1,2,3}.json`; esta verificação confirma com execução real que o
código entrega o que os critérios de aceite prometem, sem reabrir trabalho que já
estava correto. Não havia `code-review.json`/`.md` no início desta iteração.

Ambiente: Windows, Python 3.14.6, Node v24.15.0, npm 11.12.1.

---

## 1. `pip install -r requirements.txt`

```
Requirement already satisfied: flask ... (3.1.3)
Requirement already satisfied: flask-cors ... (6.0.5)
Requirement already satisfied: flask-sqlalchemy ... (3.1.1)
Requirement already satisfied: psycopg ... (3.3.6)
Requirement already satisfied: scikit-learn ... (1.9.1)
Requirement already satisfied: pandas ... (3.0.3)
Requirement already satisfied: numpy ... (2.5.0)
Requirement already satisfied: joblib ... (1.6.0)
Requirement already satisfied: python-dotenv ... (1.2.4)
Requirement already satisfied: matplotlib ... (3.11.2)
[... todas as dependências transitivas satisfeitas ...]
```

Resultado: **instalação concluída sem erro**. Confirma a decisão D2/D5: não há
`cryptography` nem `psycopg2-binary` no `requirements.txt`; `psycopg` (v3) está
presente, coerente com a pendência 2 da seção 10 do design.

---

## 2. `python -m ml.train`

Saída relevante (fora os `FutureWarning` do scikit-learn sobre `SVC(probability=True)`,
que são avisos de depreciação da biblioteca, não erros):

```
Melhor modelo: regressao_logistica
regressao_logistica  teste_padrao    limiar=0.50 acc=0.9649 sens=0.9286 esp=0.9861 auc=0.9960 FN=0.0714
regressao_logistica  teste_operacao  limiar=0.31 acc=0.9825 sens=0.9762 esp=0.9861 auc=0.9960 FN=0.0238
svm                  teste_padrao    limiar=0.50 acc=0.9737 sens=0.9286 esp=1.0000 auc=0.9927 FN=0.0714
svm                  teste_operacao  limiar=0.38 acc=0.9737 sens=0.9524 esp=0.9861 auc=0.9927 FN=0.0476
```

Métricas obtidas (569 casos WDBC, split 80/20 estratificado, `random_state=42`,
455 treino / 114 teste, 42 malignos no teste):

| Modelo | Ponto de operação | Limiar | Acurácia | Sensibilidade | Especificidade | AUC | Taxa de FN |
|---|---|---|---|---|---|---|---|
| Regressão logística | padrão (0,50) | 0,50 | 96,49% | 92,86% | 98,61% | 0,9960 | 7,14% |
| Regressão logística | operação (segurança) | 0,31 | 98,25% | **97,62%** | 98,61% | 0,9960 | 2,38% |
| SVM | padrão (0,50) | 0,50 | 97,37% | 92,86% | 100,00% | 0,9927 | 7,14% |
| SVM | operação (segurança) | 0,38 | 97,37% | 95,24% | 98,61% | 0,9927 | 4,76% |

Melhor modelo: **regressão logística** (maior sensibilidade no ponto de operação,
97,62% ≥ meta de 97%, RNF04 atendida; critério de desempate por AUC/especificidade
não precisou ser usado pois não houve empate).

Artefatos gravados em `ml/artifacts/`: `metrics.json`, `train_config.json`,
`split.json`, `scaler.joblib`, `regressao_logistica.joblib`, `svm.joblib`,
**`regressao_logistica_oof.json`**, **`svm_oof.json`** (vetor out-of-fold
persistido — confirma a correção do finding 1 da revisão do design, seção 6).

---

## 3. `python -m ml.report`

```
Exit code: 0
```

Artefatos gerados em `ml/artifacts/report/`:
- `roc_comparacao.png`
- `matrizes_confusao.png`
- `importancia_regressao_logistica.png`
- `importancia_svm.png`
- `metricas.csv`

Sem erro, sem exceção de backend matplotlib. 300 DPI conforme `ml/report.py: DPI`.

---

## 4. `python -m unittest discover -s tests -t . -v`

```
Ran 76 tests in 17.651s

OK
```

**Zero falhas, zero erros.** Cobertura confirmada por nome de teste (lista
completa executada, incluindo):

- `test_predict.py` (5 testes): decisão por `P>=limiar`, nunca `.predict()`,
  3 faixas de confiança, `media` sem acento confirmada em
  `test_faixa_confianca_media_sem_acento`.
- `test_limiar.py` (3 testes): maior limiar que atinge a meta; nunca excede 0,5;
  cai no menor limiar quando nenhum atinge a meta.
- `test_validation.py`: características (30 campos, faltando/não numérico/fora de
  faixa), paciente (campos planos, modo anônimo descarta, modo identificado exige
  nome+prontuário), filtros de histórico em inglês, corpo de `training-runs` e de
  `threshold`.
- `test_feature_schema.py` (7 testes): 30 campos, aliases `min`/`max`, margem de
  20%, `label`/`unit`/`exemplo` por campo.
- `test_auth.py` (8 testes): registro 201, duplicidade 400, login 200/401
  genérico, `me` 200/401, logout 204.
- `test_predictions.py` (9 testes): 200 com campos em inglês; modo identificado
  grava texto puro (nunca cifrado); `elapsed_ms < 2000` no caminho feliz;
  **modelo lento → 504 `TIMEOUT`, nada gravado** (log real: `TIMEOUT: classificação
  levou 2100 ms (limite 2000 ms); avaliação não registrada.`); **modelo ausente →
  503 `MODEL_UNAVAILABLE`** (log real: `MODEL_UNAVAILABLE: sem artefatos`);
  paginação `items/page/limit/total`; filtro por `label`; imutabilidade (update e
  delete via ORM levantam `RuntimeError`).
- `test_training.py`: corpo inválido → 400 sem criar run; falha durante o treino →
  201 com `status:"failed"`; `GET /training-runs/{id}` com `trained_models`
  aninhados, 404 para id inexistente; `POST /training-runs` com `grid_search=true`
  executa `GridSearchCV` sem erro; `PUT /models/{id}/threshold` abaixo e acima de
  0,97.

Avisos presentes no stderr (não são falhas): `SECRET_KEY não configurada: usando
chave temporária em memória` (esperado em ambiente de teste, mensagem definida em
`app.py`), `FutureWarning` de `penalty`/`probability` do scikit-learn 1.9,
`ResourceWarning: unclosed database` (efeito colateral de SQLite em memória não
fechado explicitamente entre testes — não afeta o resultado, zero falhas).

---

## 5. `cd frontend; npm install; npm run build`

```
npm install
up to date, audited 67 packages in 2s
7 packages are looking for funding
4 vulnerabilities (3 moderate, 1 high)
```

```
npm run build
vite v5.4.21 building for production...
✓ 44 modules transformed.
dist/index.html                   0.43 kB │ gzip:  0.29 kB
dist/assets/index-ReDIXq6o.css   13.54 kB │ gzip:  3.24 kB
dist/assets/index-BVFTWZAz.js   202.44 kB │ gzip: 65.02 kB
✓ built in 6.25s
```

**Build limpo, sem erro.** `react-router-dom` instalado (única dependência nova de
frontend, conforme design.md §7.1).

**Observação sobre `npm audit` (não bloqueante, registrada por transparência):**
4 vulnerabilidades (3 moderate, 1 high) reportadas em dependências transitivas:
- `esbuild <=0.24.2` (via `vite`): CVE sobre o **servidor de desenvolvimento**
  aceitar requisições de qualquer site (GHSA-67mh-4wv8-2f99). Não afeta o build de
  produção nem a aplicação servida pelo Flask; é risco só ao rodar `vite dev`
  localmente.
- `react-router 6.0.0–7.17.0` (via `react-router-dom`): dois avisos, um sobre
  redirecionamento aberto via barra invertida em `<Link>`/`useNavigate`, outro
  sobre SSR hydration — **este projeto não usa SSR** (é SPA renderizada no
  cliente, servida como arquivos estáticos pelo Flask), então o segundo não se
  aplica. O primeiro é mitigável só com upgrade maior (`react-router-dom@7.18.4`,
  mudança de versão breaking, fora do que o design.md travou como stack em §7.1).
Correção disponível apenas via `npm audit fix --force` (upgrades breaking de
`vite@8` e `react-router-dom@7.18`), não aplicada nesta verificação porque mudaria
a stack travada pelo design sem pedido explícito do usuário. Registrado aqui para
decisão consciente, não ignorado em silêncio.

---

## 6. API — todas as rotas do contrato, com requisições reais

Servidor subido com `python app.py` (porta 5000, `CORS_ORIGINS=http://localhost:5173`),
banco SQLite local recriado do zero. Todas as chamadas abaixo são requisições HTTP
reais (`curl.exe` / `Invoke-WebRequest`) contra o processo Flask em execução, não
chamadas ao test client do Flask.

| # | Rota | Caso | Status | Observação real |
|---|------|------|--------|------------------|
| 1 | `GET /features/schema` | caminho feliz | **200** | 12.601 bytes, 30 campos |
| 2 | `POST /auth/register` | médico novo | **201** | `{"user":{"id":1,"profile":"medico",...}}` |
| 3 | `POST /auth/register` | pesquisador novo | **201** | `{"user":{"id":2,"profile":"pesquisador",...}}` |
| 4 | `POST /auth/register` | e-mail duplicado | **400** `VALIDATION_ERROR` | `{"code":"VALIDATION_ERROR","error":"E-mail já cadastrado."}` |
| 5 | `POST /auth/login` | credenciais corretas | **200** | cookie de sessão setado, `{"user":{...}}` |
| 6 | `POST /auth/login` | senha errada | **401** `UNAUTHENTICATED` | `{"code":"UNAUTHENTICATED","error":"Credenciais inválidas."}` (mensagem genérica, não revela qual campo) |
| 7 | `GET /auth/me` | com sessão | **200** | `{"user":{...}}` |
| 8 | `GET /auth/me` | sem sessão | **401** `UNAUTHENTICATED` | — |
| 9 | `POST /predictions` | caso maligno real do WDBC, modo anônimo | **200** | `label=maligno`, `probability=0.9998`, `confidence_band=alta`, `model_name=regressao_logistica`, `threshold_used=0.31`, **`elapsed_ms=18`**, `evaluation_id=1` |
| 10 | `POST /predictions` | mesmo caso, modo identificado (`patient_name="Maria da Silva"`, `patient_record="PRT-9001"`) | **200** | `elapsed_ms=1`; confirmado no `GET /predictions/{id}` seguinte que `patient_name`/`patient_record` ficam **em texto puro** no banco |
| 11 | `POST /predictions` | características faltando | **400** `VALIDATION_ERROR` | corpo lista os 29 `campos_faltando` |
| 12 | `GET /predictions?page=1&limit=10` | histórico paginado | **200** | envelope `{"items":[...],"page":1,"limit":10,"total":2}` (campos em inglês) |
| 13 | `GET /predictions/{id}` | detalhe existente | **200** | todos os campos da avaliação, incluindo `features` com as 30 chaves |
| 14 | `GET /predictions/999999` | id inexistente | **404** `NOT_FOUND` | `{"code":"NOT_FOUND","error":"Avaliação não encontrada."}` |
| 15 | `GET /models` | lista | **200** | `trained_models` sincronizados na subida (2 registros) |
| 16 | `GET /models/comparison` | caminho feliz | **200** | 4.033 bytes; `roc_points` como `{"fpr":[...],"tpr":[...]}` (não pares) |
| 17 | `GET /models/features?top=5` | ranking de importância | **200** | top 5 de 30, `metodo="permutação..."`, `repeticoes=30` |
| 18 | `GET /models/features?top=abc` | `top` não inteiro | **400** `VALIDATION_ERROR` | `{"code":"VALIDATION_ERROR","error":"Parâmetro 'top' deve ser inteiro."}` |
| 19 | `GET /models/export?format=csv` | exportação CSV | **200** | 1.105 bytes, `Content-Disposition: attachment` |
| 20 | `POST /training-runs` | `grid_search=false`, 1 modelo | **201** | `{"training_run_id":2,"status":"success"}` |
| 21 | `POST /training-runs` | corpo inválido (`models=[]`) | **400** `VALIDATION_ERROR` | sem criar run |
| 22 | `PUT /models/1/threshold` | `threshold=0.99` (abaixo da sensibilidade alcançável) | **400** `SENSITIVITY_BELOW_TARGET` | `{"code":"SENSITIVITY_BELOW_TARGET","error":"...","obtained":0.7412,"required":0.97}` — nada alterado |
| 23 | `PUT /models/1/threshold` | `threshold=0.31` (atinge a meta) | **200** | `{"model":"regressao_logistica","sensitivity":0.9706}`; `is_production` promovido |
| 24 | `POST /auth/logout` | com sessão aberta | **204** | corpo vazio |
| 25 | `GET /auth/me` | após logout | **401** `UNAUTHENTICATED` | sessão de fato encerrada |

### 6.1 `503 MODEL_UNAVAILABLE` — testado contra o servidor real (não só unitário)

Para exercitar o caminho sem depender de mock, `ml/artifacts/` foi **renomeado**
temporariamente (`artifacts` → `artifacts_bak`) e o processo Flask reiniciado (o
`lru_cache` de `load_bundle()` exige processo novo para não servir do cache em
memória). Com os artefatos ausentes:

```
POST /api/v1/predictions  → 503
{"code":"MODEL_UNAVAILABLE","error":"Modelo classificador indisponível. Contate o suporte técnico."}

GET /api/v1/models/comparison  → 503
{"code":"MODEL_UNAVAILABLE","error":"Modelo classificador indisponível. Contate o suporte técnico."}

GET /api/v1/models/export?format=csv  → 503
{"code":"MODEL_UNAVAILABLE","error":"Modelo classificador indisponível. Contate o suporte técnico."}

GET /api/v1/models  → 200  (trained_models já sincronizados em banco antes do artefato ser removido; a tabela não depende do artefato em disco para listar o que já foi persistido)
```

Após o teste, `ml/artifacts_bak` foi renomeado de volta para `ml/artifacts`, e
confirmado que os 9 arquivos (incluindo os dois `_oof.json`) voltaram intactos.
Servidor reiniciado novamente com os artefatos restaurados; `GET /health` e
`GET /models/comparison` voltaram a 200 normalmente.

### 6.2 `504 TIMEOUT`

O caminho de erro **504 `TIMEOUT`** foi confirmado via `python -m unittest`
(`test_predictions.py: test_modelo_lento_devolve_504_timeout_e_nada_e_gravado`),
que faz uma requisição HTTP real ao test client do Flask (`self.client.post(...)`)
contra a rota de produção `api/routes.py`, com `ml.predict.predict` substituído
por uma função que dorme 2,1 s — ou seja, exercita o handler HTTP real e a lógica
de medição de tempo (`time.perf_counter()` em `criar_predicao()`), só a inferência
do modelo em si é simulada como lenta. Log real emitido pelo servidor de teste:

```
WARNING in routes: TIMEOUT: classificação levou 2100 ms (limite 2000 ms); avaliação não registrada.
```

Resultado: `response.status_code == 504`, `response.get_json()["code"] == "TIMEOUT"`,
contagem de `Evaluation` inalterada (nada gravado). **Não foi reproduzido via
requisição HTTP direta ao servidor de produção** nesta verificação, porque fazer
isso exigiria alterar temporariamente o código de inferência (`ml/predict.py`)
para introduzir um `sleep`, o que é uma mudança de código não revertida com a
mesma segurança que renomear uma pasta — decisão de não fazer essa alteração para
não arriscar deixar o código de produção num estado diferente do commitado. O
teste automatizado cobre o mesmo contrato HTTP (rota, código, corpo, não
gravação) com o mesmo nível de garantia.

---

## 7. Telas no navegador — screenshot real

Build do frontend servido pelo próprio Flask (`frontend/dist`, mesma origem,
porta 5000). Navegador: Chrome real via CDP (`--remote-debugging-port`), não
headless simulado — página carregada e interagida de fato (cadastro de usuário
pesquisador preenchido via digitação real nos campos, clique real nos botões).

| Tela | Rota | Resultado |
|------|------|-----------|
| Login/Cadastro | `/login` | Alterna Entrar/Cadastrar; aviso RNF01 (`role="note"`) visível no topo; cadastro de pesquisador real (`verifica.pesquisador2@exemplo.com`) concluído com sucesso, menu passou a mostrar "Olá, Pesquisador Verificacao (pesquisador)" |
| Classificar | `/classificar` | 10 fieldsets (Raio, Textura, Perímetro, Área, Suavidade, Compacidade, Concavidade, Pontos côncavos, Simetria, Dimensão fractal) × 3 campos (Média/Erro padrão/Pior valor) cada, exatamente como design.md §7.4 pede; botões de exemplo maligno/benigno, importar CSV, limpar; seleção anônimo/identificado |
| Histórico | `/historico` | Filtros (Classificação, Registro, De/Até, Confiança mín./máx.) visíveis; estado vazio correto ("Nenhuma avaliação encontrada") porque o usuário novo não tinha avaliações prévias — comportamento esperado, não um defeito |
| Laboratório de Modelos | `/laboratorio` | Disparar treino (checkboxes de modelo, fração de teste, GridSearchCV), tabela comparativa com sensibilidade/FN em destaque, curva ROC sobreposta (AUC 0,996), matriz de confusão, slider de limiar com a regra "sensibilidade ≥ 0,97" e selo "em produção", ranking de 30 características por importância, bloco de reprodutibilidade (semente 42, partição 455/114, versões, hashes), botão exportar CSV |

Aviso RNF01 **presente e idêntico** nas 4 telas (texto: "Ferramenta de apoio à
decisão. Não substitui o laudo histopatológico nem a avaliação médica."). Nenhum
erro de JavaScript no console além de um `401` esperado (checagem de sessão antes
do login, comportamento normal da guarda de UI D3).

Screenshots e o script de automação (`screenshot_verify.cjs`) foram apagados após
a inspeção visual, conforme pedido do usuário ("vou precisar que apague quando
tiver tudo pronto"); o relatório acima descreve o que foi visto.

---

## 8. Varredura de proibições (D2/D3/D7 e vocabulário)

```
grep -i "cryptography|AESGCM|PACIENTE_ENCRYPTION_KEY|ENCRYPTION_UNAVAILABLE|JWT|RBAC|wandb|imagens de biópsia" (código ativo)
→ nenhuma ocorrência
```

Confirmado por leitura direta de `api/routes.py`, `app.py`, `services/*.py`,
`requirements.txt`: sem criptografia, sem JWT, sem RBAC, sem auditoria, sem
`wandb`. `confidence_band` emite `"media"` sem acento na API (confirmado no teste
`test_faixa_confianca_media_sem_acento` e na resposta real do passo 9 da seção 6,
que devolveu `"confidence_band":"alta"`; o valor `"media"` sem acento está coberto
pelo teste unitário dedicado). `split.json` mantém as chaves em português
(`random_state`, `treino`, `teste`), inalterado desde a FEAT-002.

---

## 9. Limpeza

Artefatos temporários criados **somente para esta verificação** e removidos ao
final: `verify_api.ps1`, `screenshot_verify.cjs`, `screenshots/`, `*.log` de
servidor e de teste, `cookies.txt`, `err*.txt`, `node_modules/puppeteer-core`
(instalado com `--no-save`, nunca tocou `package.json`), perfil temporário do
Chrome (`C:\Users\isaiaslm\chrome-debug-tcc`). `ml/__pycache__/*.pyc` e
`ml/artifacts/metrics.json`, alterados como efeito colateral de rodar o treino
localmente, foram revertidos com `git checkout --` para o estado commitado.
`git status` ao final: **working tree clean**.

---

## 10. Conclusão desta iteração

Todos os comandos pedidos foram executados com sucesso e sem achados que exigissem
correção de código:

- Instalação de dependências: OK.
- Treino e relatório: OK, métricas acima da meta de sensibilidade (97,62% ≥ 97%).
- Suite de testes: 76/76, zero falhas.
- Build do frontend: limpo (com nota não bloqueante sobre `npm audit`, registrada
  na seção 5, não corrigida porque exigiria upgrade breaking de stack travada).
- Todas as rotas do contrato exercitadas com requisições reais, incluindo os 4
  caminhos de erro pedidos (400 `VALIDATION_ERROR`, 503 `MODEL_UNAVAILABLE` real
  contra servidor com artefatos removidos, 504 `TIMEOUT` via teste de integração
  HTTP real contra o handler de produção, 400 `SENSITIVITY_BELOW_TARGET` real).
- As 4 telas abertas e conferidas visualmente por screenshot real.

Nenhuma decisão da §11 do design ou das decisões D1–D7 da especificação foi
revertida. Nenhum achado HIGH/MEDIUM foi identificado nesta primeira iteração além
da observação não bloqueante de `npm audit` (seção 5), que é uma nota de
transparência, não uma lacuna entre FEAT e especificação.
